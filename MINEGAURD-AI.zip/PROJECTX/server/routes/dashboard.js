import express from 'express';
import { getDeviceStatus, getAllNodes } from '../services/deviceService.js';
import { calculateRisk, calculateMineOverview } from '../services/riskService.js';
import { getAlerts } from '../services/alertService.js';

const router = express.Router();

/**
 * GET /api/dashboard/summary
 *
 * Computes consolidated operational dashboard summary:
 * - Fleet health metrics (total, online, stale, disconnected)
 * - Overall mine geotechnical risk status & score
 * - Critical nodes requiring immediate inspection
 * - Active unacknowledged alert count and list
 * - Real gateway connectivity state
 */
router.get('/summary', (req, res) => {
  const deviceState = getDeviceStatus();
  const allNodes = getAllNodes();

  // Evaluate risk for all reporting nodes with telemetry
  const nodesRiskList = [];
  let latestPacketTime = deviceState.lastPacket;

  for (const node of allNodes) {
    if (node.latestTelemetry) {
      const risk = calculateRisk({ nodeId: node.nodeId, ...node.latestTelemetry });
      nodesRiskList.push(risk);
      if (!latestPacketTime || (node.latestTelemetry.timestamp && node.latestTelemetry.timestamp > latestPacketTime)) {
        latestPacketTime = node.latestTelemetry.timestamp;
      }
    }
  }

  // Compute composite mine overview
  const mineOverview = calculateMineOverview(nodesRiskList);

  // Active unacknowledged alerts
  const activeAlerts = getAlerts({ acknowledged: false, limit: 5 });
  const totalActiveAlertsCount = getAlerts({ acknowledged: false }).length;

  const summary = {
    totalNodes: deviceState.totalNodes,
    onlineNodes: deviceState.nodesOnline,
    staleNodes: deviceState.nodesStale,
    disconnectedNodes: deviceState.nodesOffline,
    overallMineStatus: mineOverview.overallStatus,
    overallRiskScore: mineOverview.overallRiskScore,
    activeAlertsCount: totalActiveAlertsCount,
    criticalNodes: mineOverview.criticalNodes,
    warningNodes: mineOverview.warningNodes,
    latestUpdate: latestPacketTime,
    gateway: {
      connected: deviceState.connected,
      id: deviceState.gateway,
      signal: deviceState.signal,
      lastPacket: deviceState.lastPacket
    },
    latestRiskInformation: {
      overallStatus: mineOverview.overallStatus,
      overallRiskScore: mineOverview.overallRiskScore,
      criticalCount: mineOverview.criticalNodes.length,
      warningCount: mineOverview.warningNodes.length,
      evaluatedStations: nodesRiskList.length
    },
    activeAlerts
  };

  res.json({
    success: true,
    summary
  });
});

export default router;
