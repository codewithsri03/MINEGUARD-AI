import express from 'express';
import { getAlerts, getAlertsByNode, acknowledgeAlert } from '../services/alertService.js';
import { broadcast } from '../websocket/telemetrySocket.js';

const router = express.Router();

/**
 * GET /api/alerts
 * Return all alerts with optional query filtering:
 * ?nodeId=N-07&severity=CRITICAL&acknowledged=false&limit=50
 */
router.get('/', (req, res) => {
  const { nodeId, severity, acknowledged, limit } = req.query;

  let ackFilter = null;
  if (acknowledged === 'true' || acknowledged === '1') ackFilter = true;
  if (acknowledged === 'false' || acknowledged === '0') ackFilter = false;

  const alerts = getAlerts({
    nodeId,
    severity,
    acknowledged: ackFilter,
    limit: limit ? Number(limit) : 100
  });

  res.json({
    success: true,
    count: alerts.length,
    alerts
  });
});

/**
 * GET /api/alerts/:nodeId
 * Return alerts for a specific node.
 */
router.get('/:nodeId', (req, res) => {
  const { nodeId } = req.params;
  const { limit } = req.query;
  const alerts = getAlertsByNode(nodeId, limit ? Number(limit) : 50);

  res.json({
    success: true,
    nodeId,
    count: alerts.length,
    alerts
  });
});

/**
 * Helper to handle acknowledgement for both PATCH and POST
 */
function handleAcknowledgement(req, res) {
  const alertId = req.params.alertId || req.params.id;
  const actor = req.body?.actor || req.body?.acknowledgedBy || 'Control Room Operator';

  const updated = acknowledgeAlert(alertId, actor);

  if (!updated) {
    return res.status(404).json({
      success: false,
      error: `Alert with ID "${alertId}" not found.`
    });
  }

  broadcast('alert_acknowledged', updated);

  res.json({
    success: true,
    alert: updated
  });
}

/**
 * PATCH /api/alerts/:alertId/acknowledge
 * Primary endpoint per specification
 */
router.patch('/:alertId/acknowledge', handleAcknowledgement);

/**
 * POST /api/alerts/:alertId/ack
 * Backward-compatible alias
 */
router.post(['/:alertId/ack', '/:id/ack'], handleAcknowledgement);

export default router;
