import express from 'express';
import {
  ingestTelemetry,
  getLatestTelemetry,
  getNodeHistory
} from '../services/telemetryService.js';

const router = express.Router();

/**
 * POST /api/telemetry
 * Ingests a telemetry packet from ESP32 over Wi-Fi.
 */
router.post('/', (req, res) => {
  const payload = req.body;
  const result = ingestTelemetry(payload);

  if (!result.success) {
    return res.status(400).json(result);
  }

  res.status(200).json(result);
});

/**
 * GET /api/telemetry/latest
 * Retrieve latest telemetry data for all nodes or a specific node.
 */
router.get('/latest', (req, res) => {
  const { nodeId } = req.query;
  const data = getLatestTelemetry(nodeId);
  const allNodes = nodeId ? null : data;
  const latestSingle = nodeId
    ? data
    : (allNodes && Object.keys(allNodes).length > 0 ? Object.values(allNodes)[Object.values(allNodes).length - 1] : null);

  res.json({
    success: true,
    data,
    telemetry: latestSingle,
    ...(allNodes && { nodes: allNodes })
  });
});

/**
 * GET /api/telemetry/history/:nodeId
 * Retrieve persistent historical points from SQLite with optional time bounds.
 * Query params: ?limit=100&since=2026-09-20&until=2026-09-22
 */
router.get('/history/:nodeId', (req, res) => {
  const { nodeId } = req.params;
  const { limit, since, until } = req.query;

  const history = getNodeHistory(nodeId, { limit, since, until });

  res.json({
    success: true,
    nodeId,
    count: history.length,
    history
  });
});

/**
 * Simulator Control Endpoints
 */
router.post('/simulator/stop', async (req, res) => {
  const { stopBackendDemoSimulator } = await import('../services/demoSimulatorService.js');
  stopBackendDemoSimulator();
  res.json({ success: true, running: false });
});

router.post('/simulator/start', async (req, res) => {
  const { startBackendDemoSimulator } = await import('../services/demoSimulatorService.js');
  const { intervalMs = 2000 } = req.body || {};
  startBackendDemoSimulator(intervalMs);
  res.json({ success: true, running: true });
});

router.get('/simulator/status', async (req, res) => {
  const { isSimulatorRunning } = await import('../services/demoSimulatorService.js');
  res.json({ success: true, running: isSimulatorRunning() });
});

export default router;
