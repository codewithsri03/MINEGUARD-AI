import express from 'express';
import {
  getDeviceStatus,
  getNode,
  getAllNodes,
  connectDevice,
  disconnectDevice
} from '../services/deviceService.js';
import { broadcast } from '../websocket/telemetrySocket.js';

const router = express.Router();

/**
 * GET /api/devices/status
 * Returns REAL backend device state, gateway status, and complete fleet node counts.
 */
router.get('/status', (req, res) => {
  const status = getDeviceStatus();
  res.json(status);
});

/**
 * GET /api/devices/nodes
 * GET /api/devices
 * Returns list of all known nodes.
 */
router.get(['/', '/nodes'], (req, res) => {
  const nodes = getAllNodes();
  res.json({ success: true, count: nodes.length, nodes });
});

/**
 * GET /api/devices/:nodeId
 * Retrieve detailed status and latest readings for a single node.
 */
router.get('/:nodeId', (req, res) => {
  const { nodeId } = req.params;
  const node = getNode(nodeId);

  if (!node) {
    return res.status(404).json({
      success: false,
      error: `Node with ID "${nodeId}" not found in fleet registry.`
    });
  }

  res.json({
    success: true,
    node
  });
});

/**
 * POST /api/devices/connect
 * Connect to ESP32 by IP address and verify reachability.
 */
router.post('/connect', async (req, res) => {
  const { host, port } = req.body || {};
  const result = await connectDevice(host, port);

  broadcast('device_status', result.state);

  if (!result.success) {
    return res.status(result.statusCode || 400).json(result);
  }

  res.status(200).json(result);
});

/**
 * POST /api/devices/disconnect
 * Disconnect physical gateway and mark nodes offline.
 */
router.post('/disconnect', (req, res) => {
  const result = disconnectDevice();

  broadcast('device_status', result.state);
  res.status(200).json(result);
});

export default router;
