import express from 'express';
import { getAllNodes } from '../services/deviceService.js';
import { calculateRisk } from '../services/riskService.js';

const router = express.Router();

/**
 * GET /api/digital-twin/nodes
 *
 * Provides real backend node state structured specifically for the 2D Underground Mine Map:
 * - Geotechnical depth & sector coordinates from metadata
 * - Live connection status (ONLINE / STALE / OFFLINE)
 * - Evaluated geotechnical risk score & severity
 * - Telemetry summary (temperature, distance, tilt, gas, rain)
 */
router.get('/nodes', (req, res) => {
  const allNodes = getAllNodes();

  const digitalTwinNodes = allNodes.map((node) => {
    let riskStatus = 'NORMAL';
    let riskScore = 0;
    let telemetrySummary = null;

    if (node.latestTelemetry) {
      const risk = calculateRisk(node.latestTelemetry);
      riskStatus = risk.status;
      riskScore = risk.riskScore;
      telemetrySummary = {
        temperature: node.latestTelemetry.temperature ?? null,
        humidity: node.latestTelemetry.humidity ?? null,
        pressure: node.latestTelemetry.pressure ?? null,
        distance: node.latestTelemetry.distance ?? null,
        tilt: node.latestTelemetry.tilt ?? null,
        gasAdc: node.latestTelemetry.gasAdc ?? null,
        rainAdc: node.latestTelemetry.rainAdc ?? null,
        timestamp: node.latestTelemetry.timestamp ?? null
      };
    }

    const coords = node.metadata?.coords || { x: 300, y: 300 };

    return {
      nodeId: node.nodeId,
      name: node.name,
      zoneId: node.zoneId,
      zoneName: node.zoneName,
      depth: node.depth,
      status: node.status,
      source: node.source,
      lastSeen: node.lastSeen,
      riskStatus,
      riskScore,
      coords,
      telemetry: telemetrySummary
    };
  });

  res.json({
    success: true,
    count: digitalTwinNodes.length,
    nodes: digitalTwinNodes
  });
});

export default router;
