import express from 'express';
import { getNode, getAllNodes } from '../services/deviceService.js';
import { calculateRisk, calculateMineOverview } from '../services/riskService.js';

const router = express.Router();

/**
 * GET /api/risk
 * Return composite mine risk overview and all evaluated station risk cards.
 */
router.get('/', (req, res) => {
  const allNodes = getAllNodes();
  const evaluatedNodes = [];

  for (const node of allNodes) {
    if (node.latestTelemetry) {
      const risk = calculateRisk(node.latestTelemetry);
      evaluatedNodes.push({
        nodeId: node.nodeId,
        name: node.name,
        zoneId: node.zoneId,
        zoneName: node.zoneName,
        depth: node.depth,
        status: risk.status,
        riskScore: risk.riskScore,
        factors: risk.factors,
        timestamp: risk.timestamp
      });
    } else {
      evaluatedNodes.push({
        nodeId: node.nodeId,
        name: node.name,
        zoneId: node.zoneId,
        zoneName: node.zoneName,
        depth: node.depth,
        status: 'NORMAL',
        riskScore: 0,
        factors: [],
        timestamp: null,
        note: 'Awaiting telemetry packet'
      });
    }
  }

  const mineOverview = calculateMineOverview(
    evaluatedNodes.filter((n) => n.timestamp !== null)
  );

  res.json({
    success: true,
    mineRisk: mineOverview,
    nodes: evaluatedNodes
  });
});

/**
 * GET /api/risk/:nodeId
 * Return current calculated risk breakdown for a specific node.
 */
router.get('/:nodeId', (req, res) => {
  const { nodeId } = req.params;
  const node = getNode(nodeId);

  if (!node) {
    return res.status(404).json({
      success: false,
      error: `Node "${nodeId}" not found.`
    });
  }

  if (!node.latestTelemetry) {
    return res.json({
      success: true,
      nodeId: node.nodeId,
      name: node.name,
      zoneId: node.zoneId,
      zoneName: node.zoneName,
      depth: node.depth,
      riskScore: 0,
      status: 'NORMAL',
      factors: [],
      timestamp: null,
      note: 'No telemetry received yet from hardware station'
    });
  }

  const risk = calculateRisk(node.latestTelemetry);

  res.json({
    success: true,
    nodeId: node.nodeId,
    name: node.name,
    zoneId: node.zoneId,
    zoneName: node.zoneName,
    depth: node.depth,
    riskScore: risk.riskScore,
    status: risk.status,
    factors: risk.factors,
    tiltDeg: risk.tiltDeg,
    timestamp: risk.timestamp
  });
});

export default router;
