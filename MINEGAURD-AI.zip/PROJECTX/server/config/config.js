import 'dotenv/config';
import path from 'path';

/**
 * MineGuard AI Backend Configuration
 *
 * Centralized settings, timeouts, operational thresholds, and geotechnical metadata.
 *
 * NOTE ON THRESHOLDS:
 * The thresholds below are prototype operational values configured for demonstration.
 * They are project-configurable and require physical calibration and geotechnical validation
 * based on specific mine ground-control guidelines (DGMS/MSHA) for live production deployment.
 */
function resolveDatabasePath() {
  const customPath = process.env.DATABASE_PATH || process.env.DB_PATH;
  if (!customPath) {
    return path.resolve(process.cwd(), 'server/data/mineguard.db');
  }
  return path.isAbsolute(customPath) ? customPath : path.resolve(process.cwd(), customPath);
}

export const config = {
  port: Number(process.env.PORT) || 3001,
  host: process.env.HOST || '0.0.0.0',
  frontendOrigin: process.env.FRONTEND_ORIGIN || process.env.FRONTEND_URL || '',
  frontendUrl: process.env.FRONTEND_ORIGIN || process.env.FRONTEND_URL || 'http://localhost:5173',
  nodeEnv: process.env.NODE_ENV || 'development',
  dbPath: resolveDatabasePath(),

  // Device & Node Life-Cycle Timeouts (milliseconds)
  timeouts: {
    nodeStaleMs: Number(process.env.NODE_STALE_TIMEOUT_MS) || 20000,
    nodeOfflineMs: Number(process.env.NODE_OFFLINE_TIMEOUT_MS) || 45000,
    gatewayDisconnectMs: Number(process.env.GATEWAY_DISCONNECT_TIMEOUT_MS) || 60000
  },

  // Alert Engine Settings
  alerts: {
    cooldownMs: Number(process.env.ALERT_COOLDOWN_MS) || 30000, // 30s alert deduplication window
    maxStored: 200
  },

  // Geotechnical & Environmental Prototype Thresholds
  // Clearly marked as operational defaults:
  thresholds: {
    tilt: {
      warning: 2.0,   // degrees of pitch/roll deviation
      critical: 3.0
    },
    distance: {
      warning: 17.0,  // cm (convergence roof clearance - lower = roof compression)
      critical: 15.0
    },
    gasAdc: {
      warning: 2200,  // raw ADC reading (elevated methane/CO/smoke)
      critical: 2600
    },
    temperature: {
      warning: 35.0,  // Celsius ambient mine air
      critical: 45.0
    },
    humidity: {
      warning: 85.0,  // % RH
      critical: 95.0
    },
    rainAdc: {
      warning: 350,   // water ingress ADC
      critical: 500
    }
  },

  // Pre-configured Mine Sector Metadata (used for Digital Twin & Node Registry)
  // Dynamic nodes reporting outside this list are automatically registered under General Fleet.
  defaultZones: [
    { id: 'z1', name: 'Zone 01 — Main Haulage', shortName: 'Main Haulage', depth: -320, nodes: ['N-01', 'N-02'] },
    { id: 'z2', name: 'Zone 02 — North Drift', shortName: 'North Drift', depth: -380, nodes: ['N-03', 'N-04'] },
    { id: 'z3', name: 'Zone 03 — Sub-Level 4', shortName: 'Sub-Level 4', depth: -460, nodes: ['N-06', 'N-07'] },
    { id: 'z4', name: 'Zone 04 — Ventilation', shortName: 'Ventilation', depth: -410, nodes: ['N-05', 'N-08'] }
  ],

  defaultNodes: {
    'N-01': { zoneId: 'z1', zoneName: 'Zone 01 — Main Haulage', name: 'Haulage Drift Entry', depth: -320, coords: { x: 220, y: 160 } },
    'N-02': { zoneId: 'z1', zoneName: 'Zone 01 — Main Haulage', name: 'Portal Cross-Cut A', depth: -320, coords: { x: 440, y: 160 } },
    'N-03': { zoneId: 'z2', zoneName: 'Zone 02 — North Drift', name: 'North Drift Heading', depth: -380, coords: { x: 240, y: 260 } },
    'N-04': { zoneId: 'z2', zoneName: 'Zone 02 — North Drift', name: 'Central Junction B', depth: -380, coords: { x: 480, y: 260 } },
    'N-05': { zoneId: 'z4', zoneName: 'Zone 04 — Ventilation', name: 'Ventilation Incline', depth: -410, coords: { x: 300, y: 360 } },
    'N-06': { zoneId: 'z3', zoneName: 'Zone 03 — Sub-Level 4', name: 'South Access Gallery', depth: -460, coords: { x: 200, y: 460 } },
    'N-07': { zoneId: 'z3', zoneName: 'Zone 03 — Sub-Level 4', name: 'Sub-Level 4 Stope', depth: -460, coords: { x: 500, y: 460 } },
    'N-08': { zoneId: 'z4', zoneName: 'Zone 04 — Ventilation', name: 'Drainage Cross-Cut', depth: -410, coords: { x: 540, y: 360 } }
  }
};

/**
 * Structured logger utility
 */
export const logger = {
  server: (msg, ...args) => console.log(`[SERVER] ${msg}`, ...args),
  telemetry: (msg, ...args) => console.log(`[TELEMETRY] ${msg}`, ...args),
  websocket: (msg, ...args) => console.log(`[WEBSOCKET] ${msg}`, ...args),
  device: (msg, ...args) => console.log(`[DEVICE] ${msg}`, ...args),
  alert: (msg, ...args) => console.warn(`[ALERT] ${msg}`, ...args),
  db: (msg, ...args) => console.log(`[DATABASE] ${msg}`, ...args),
  error: (msg, ...args) => console.error(`[ERROR] ${msg}`, ...args)
};
