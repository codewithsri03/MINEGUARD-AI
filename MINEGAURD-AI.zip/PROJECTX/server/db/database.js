import fs from 'fs';
import path from 'path';
import { DatabaseSync } from 'node:sqlite';
import { config, logger } from '../config/config.js';

let dbInstance = null;

/**
 * Initialize SQLite database connection and schema
 */
export function initDatabase(customPath = null) {
  if (dbInstance) return dbInstance;

  const dbPath = customPath || config.dbPath;
  const dbDir = path.dirname(dbPath);

  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  dbInstance = new DatabaseSync(dbPath);
  dbInstance.exec('PRAGMA journal_mode = WAL;');
  dbInstance.exec('PRAGMA synchronous = NORMAL;');

  // 1. Nodes Table
  dbInstance.exec(`
    CREATE TABLE IF NOT EXISTS nodes (
      node_id TEXT PRIMARY KEY,
      device_id TEXT,
      name TEXT,
      zone_id TEXT,
      zone_name TEXT,
      depth INTEGER,
      status TEXT DEFAULT 'OFFLINE',
      source TEXT DEFAULT 'hardware',
      last_seen INTEGER,
      latest_telemetry TEXT,
      metadata TEXT,
      created_at INTEGER,
      updated_at INTEGER
    );
  `);

  // 2. Telemetry History Table
  dbInstance.exec(`
    CREATE TABLE IF NOT EXISTS telemetry_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      node_id TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      timestamp_ms INTEGER NOT NULL,
      source TEXT NOT NULL,
      temperature REAL,
      humidity REAL,
      pressure REAL,
      distance REAL,
      tilt REAL,
      gas_adc INTEGER,
      rain_adc INTEGER,
      raw_data TEXT NOT NULL,
      derived_data TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_telemetry_node_time ON telemetry_history (node_id, timestamp_ms DESC);
  `);

  // 3. Alerts Table
  dbInstance.exec(`
    CREATE TABLE IF NOT EXISTS alerts (
      alert_id TEXT PRIMARY KEY,
      node_id TEXT NOT NULL,
      severity TEXT NOT NULL,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      source TEXT NOT NULL,
      acknowledged INTEGER DEFAULT 0,
      acknowledged_at TEXT,
      acknowledged_by TEXT,
      timestamp TEXT NOT NULL,
      timestamp_ms INTEGER NOT NULL,
      factors TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_alerts_node_status ON alerts (node_id, severity, acknowledged);
  `);

  // Seed default nodes if empty
  seedDefaultNodes();

  logger.db(`SQLite database initialized at ${dbPath}`);
  return dbInstance;
}

/**
 * Seed default metadata for initial fleet nodes (N-01 to N-08)
 */
function seedDefaultNodes() {
  const count = dbInstance.prepare('SELECT COUNT(*) as count FROM nodes').get().count;
  if (count > 0) return;

  const now = Date.now();
  const insertStmt = dbInstance.prepare(`
    INSERT INTO nodes (
      node_id, device_id, name, zone_id, zone_name, depth, status, source, last_seen, metadata, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  for (const [nodeId, meta] of Object.entries(config.defaultNodes)) {
    insertStmt.run(
      nodeId,
      'ESP32-GATEWAY-01',
      meta.name,
      meta.zoneId,
      meta.zoneName,
      meta.depth,
      'OFFLINE',
      'unassigned',
      null,
      JSON.stringify({ coords: meta.coords }),
      now,
      now
    );
  }
}

/**
 * Upsert node state upon telemetry arrival or connection probe
 */
export function dbUpsertNode(node) {
  const db = initDatabase();
  const now = Date.now();

  const existing = db.prepare('SELECT * FROM nodes WHERE node_id = ?').get(node.nodeId);
  const metadata = typeof node.metadata === 'object' ? JSON.stringify(node.metadata) : (node.metadata || '{}');
  const latestTelemetry = typeof node.latestTelemetry === 'object'
    ? JSON.stringify(node.latestTelemetry)
    : (node.latestTelemetry || null);

  if (existing) {
    db.prepare(`
      UPDATE nodes SET
        device_id = COALESCE(?, device_id),
        name = COALESCE(?, name),
        zone_id = COALESCE(?, zone_id),
        zone_name = COALESCE(?, zone_name),
        depth = COALESCE(?, depth),
        status = ?,
        source = ?,
        last_seen = ?,
        latest_telemetry = ?,
        metadata = COALESCE(?, metadata),
        updated_at = ?
      WHERE node_id = ?
    `).run(
      node.deviceId || null,
      node.name || null,
      node.zoneId || null,
      node.zoneName || null,
      node.depth ?? null,
      node.status || 'ONLINE',
      node.source || 'hardware',
      node.lastSeen ?? null,
      latestTelemetry,
      metadata,
      now,
      node.nodeId
    );
  } else {
    // Determine defaults if it's a dynamic new node (N-09, etc.)
    const defaultMeta = config.defaultNodes[node.nodeId] || {
      name: `Mine Station ${node.nodeId}`,
      zoneId: 'z_fleet',
      zoneName: 'Fleet Expansion',
      depth: -350,
      coords: { x: 300, y: 300 }
    };

    db.prepare(`
      INSERT INTO nodes (
        node_id, device_id, name, zone_id, zone_name, depth, status, source, last_seen, latest_telemetry, metadata, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      node.nodeId,
      node.deviceId || 'ESP32-GATEWAY-01',
      node.name || defaultMeta.name,
      node.zoneId || defaultMeta.zoneId,
      node.zoneName || defaultMeta.zoneName,
      node.depth ?? defaultMeta.depth,
      node.status || 'ONLINE',
      node.source || 'hardware',
      node.lastSeen || now,
      latestTelemetry,
      metadata,
      now,
      now
    );
  }
}

/**
 * Get all registered nodes from database
 */
export function dbGetAllNodes() {
  const db = initDatabase();
  const rows = db.prepare('SELECT * FROM nodes ORDER BY node_id ASC').all();
  return rows.map((r) => ({
    nodeId: r.node_id,
    deviceId: r.device_id,
    name: r.name,
    zoneId: r.zone_id,
    zoneName: r.zone_name,
    depth: r.depth,
    status: r.status,
    source: r.source,
    lastSeen: r.last_seen,
    latestTelemetry: r.latest_telemetry ? JSON.parse(r.latest_telemetry) : null,
    metadata: r.metadata ? JSON.parse(r.metadata) : {}
  }));
}

/**
 * Get a single node by ID
 */
export function dbGetNode(nodeId) {
  const db = initDatabase();
  const r = db.prepare('SELECT * FROM nodes WHERE node_id = ?').get(nodeId);
  if (!r) return null;
  return {
    nodeId: r.node_id,
    deviceId: r.device_id,
    name: r.name,
    zoneId: r.zone_id,
    zoneName: r.zone_name,
    depth: r.depth,
    status: r.status,
    source: r.source,
    lastSeen: r.last_seen,
    latestTelemetry: r.latest_telemetry ? JSON.parse(r.latest_telemetry) : null,
    metadata: r.metadata ? JSON.parse(r.metadata) : {}
  };
}

/**
 * Persist an immutable telemetry record into SQLite
 */
export function dbSaveTelemetry(record) {
  const db = initDatabase();
  const now = Date.now();
  const timestampMs = record.timestamp ? new Date(record.timestamp).getTime() : now;

  const rawJson = typeof record.raw === 'object' ? JSON.stringify(record.raw) : JSON.stringify(record);
  const derivedJson = typeof record.derived === 'object' ? JSON.stringify(record.derived) : '{}';

  db.prepare(`
    INSERT INTO telemetry_history (
      node_id, timestamp, timestamp_ms, source,
      temperature, humidity, pressure, distance, tilt, gas_adc, rain_adc,
      raw_data, derived_data, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    record.nodeId,
    record.timestamp || new Date(now).toISOString(),
    timestampMs,
    record.source || 'hardware',
    record.raw?.temperature ?? record.temperature ?? null,
    record.raw?.humidity ?? record.humidity ?? null,
    record.raw?.pressure ?? record.pressure ?? null,
    record.raw?.distance ?? record.distance ?? null,
    record.derived?.tiltDeg ?? record.tilt ?? null,
    record.raw?.gasAdc ?? record.gasAdc ?? null,
    record.raw?.rainAdc ?? record.rainAdc ?? null,
    rawJson,
    derivedJson,
    now
  );
}

/**
 * Get historical telemetry for a node with optional limits and time bounds
 */
export function dbGetTelemetryHistory(nodeId, { limit = 100, since = null, until = null } = {}) {
  const db = initDatabase();
  const safeLimit = Math.min(1000, Math.max(1, Number(limit) || 100));

  let query = 'SELECT * FROM telemetry_history WHERE node_id = ?';
  const params = [nodeId];

  if (since) {
    const sinceMs = new Date(since).getTime();
    if (!isNaN(sinceMs)) {
      query += ' AND timestamp_ms >= ?';
      params.push(sinceMs);
    }
  }

  if (until) {
    const untilMs = new Date(until).getTime();
    if (!isNaN(untilMs)) {
      query += ' AND timestamp_ms <= ?';
      params.push(untilMs);
    }
  }

  query += ' ORDER BY timestamp_ms DESC LIMIT ?';
  params.push(safeLimit);

  const rows = db.prepare(query).all(...params);
  return rows.map((r) => ({
    id: r.id,
    nodeId: r.node_id,
    timestamp: r.timestamp,
    timestampMs: r.timestamp_ms,
    source: r.source,
    temperature: r.temperature,
    humidity: r.humidity,
    pressure: r.pressure,
    distance: r.distance,
    tilt: r.tilt,
    gasAdc: r.gas_adc,
    rainAdc: r.rain_adc,
    raw: JSON.parse(r.raw_data),
    derived: JSON.parse(r.derived_data)
  }));
}

/**
 * Save an alert to SQLite
 */
export function dbSaveAlert(alert) {
  const db = initDatabase();
  const now = Date.now();
  const timestampMs = alert.timestamp ? new Date(alert.timestamp).getTime() : now;

  db.prepare(`
    INSERT OR REPLACE INTO alerts (
      alert_id, node_id, severity, type, message, source,
      acknowledged, acknowledged_at, acknowledged_by,
      timestamp, timestamp_ms, factors, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    alert.id,
    alert.nodeId,
    alert.severity,
    alert.type || 'HAZARD_WARNING',
    alert.message,
    alert.source || 'hardware',
    alert.acknowledged ? 1 : 0,
    alert.acknowledgedAt || null,
    alert.acknowledgedBy || null,
    alert.timestamp || new Date(now).toISOString(),
    timestampMs,
    alert.factors ? JSON.stringify(alert.factors) : '[]',
    now
  );
}

/**
 * Get alerts with optional filtering
 */
export function dbGetAlerts({ nodeId = null, severity = null, acknowledged = null, limit = 100 } = {}) {
  const db = initDatabase();
  let query = 'SELECT * FROM alerts WHERE 1=1';
  const params = [];

  if (nodeId) {
    query += ' AND node_id = ?';
    params.push(nodeId);
  }

  if (severity) {
    query += ' AND severity = ?';
    params.push(severity.toUpperCase());
  }

  if (acknowledged !== null && acknowledged !== undefined) {
    query += ' AND acknowledged = ?';
    params.push(acknowledged ? 1 : 0);
  }

  query += ' ORDER BY timestamp_ms DESC LIMIT ?';
  params.push(Math.min(500, Number(limit) || 100));

  const rows = db.prepare(query).all(...params);
  return rows.map((r) => ({
    id: r.alert_id,
    nodeId: r.node_id,
    severity: r.severity,
    type: r.type,
    message: r.message,
    source: r.source,
    acknowledged: Boolean(r.acknowledged),
    acknowledgedAt: r.acknowledged_at,
    acknowledgedBy: r.acknowledged_by,
    timestamp: r.timestamp,
    factors: r.factors ? JSON.parse(r.factors) : []
  }));
}

/**
 * Acknowledge an alert by ID
 */
export function dbAcknowledgeAlert(alertId, actor = 'Operator') {
  const db = initDatabase();
  const now = new Date().toISOString();

  const alert = db.prepare('SELECT * FROM alerts WHERE alert_id = ?').get(alertId);
  if (!alert) return null;

  db.prepare(`
    UPDATE alerts SET acknowledged = 1, acknowledged_at = ?, acknowledged_by = ? WHERE alert_id = ?
  `).run(now, actor, alertId);

  return {
    id: alert.alert_id,
    nodeId: alert.node_id,
    severity: alert.severity,
    type: alert.type,
    message: alert.message,
    source: alert.source,
    acknowledged: true,
    acknowledgedAt: now,
    acknowledgedBy: actor,
    timestamp: alert.timestamp,
    factors: alert.factors ? JSON.parse(alert.factors) : []
  };
}

/**
 * Close database connection
 */
export function closeDatabase() {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}
