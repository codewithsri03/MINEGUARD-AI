import http from 'http';
import express from 'express';
import cors from 'cors';
import { config, logger } from './config/config.js';
import { initTelemetrySocket } from './websocket/telemetrySocket.js';
import devicesRouter from './routes/devices.js';
import telemetryRouter from './routes/telemetry.js';
import alertsRouter from './routes/alerts.js';
import dashboardRouter from './routes/dashboard.js';
import riskRouter from './routes/risk.js';
import digitalTwinRouter from './routes/digitalTwin.js';
import { initNodeCache } from './services/deviceService.js';
import { startBackendDemoSimulator, stopBackendDemoSimulator, isBackendDemoEnabled } from './services/demoSimulatorService.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';

const app = express();

// Initialize database-backed node cache
initNodeCache();

// 1. CORS Configuration
// Dynamic allowed origins from FRONTEND_ORIGIN or FRONTEND_URL
const configuredOrigins = (process.env.FRONTEND_ORIGIN || process.env.FRONTEND_URL || config.frontendOrigin || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

// Local development origins
const devOrigins = [
  'http://localhost:5173',
  'http://127.0.0.1:5173',
  'http://localhost:3000',
  'http://localhost:4173'
];

app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (like mobile apps, curl, postman, ESP32 direct Wi-Fi HTTP)
    if (!origin) return callback(null, true);

    // Wildcard support
    if (configuredOrigins.includes('*')) {
      return callback(null, true);
    }

    // Configured production origins
    if (configuredOrigins.includes(origin)) {
      return callback(null, true);
    }

    // Local development origins
    if (config.nodeEnv !== 'production' || devOrigins.includes(origin)) {
      return callback(null, true);
    }

    return callback(new Error(`CORS blocked for origin: ${origin}`));
  },
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// 2. Request Parsing Middleware
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// 3. Health Check Endpoint
// GET /api/health
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'mineguard-backend',
    environment: config.nodeEnv,
    timestamp: new Date().toISOString()
  });
});

// 4. API Routes
app.use('/api/devices', devicesRouter);
app.use('/api/telemetry', telemetryRouter);
app.use('/api/alerts', alertsRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/risk', riskRouter);
app.use('/api/digital-twin', digitalTwinRouter);

// 5. Error & 404 Handlers
app.use(notFoundHandler);
app.use(errorHandler);

// 6. HTTP & WebSocket Server Setup
const server = http.createServer(app);

// Attach WebSocket server on /ws path
initTelemetrySocket(server);

// 7. Start Server
const PORT = Number(process.env.PORT) || config.port || 3001;
const HOST = '0.0.0.0';

server.listen(PORT, HOST, () => {
  logger.server(`MineGuard backend running on port ${PORT} (host: ${HOST})`);
  logger.server(`Health check: http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}/api/health`);
  logger.server(`WebSocket streaming available at ws://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}/ws`);

  // Start autonomous backend demo simulator if DEMO_MODE or VITE_DEMO_MODE is true
  if (isBackendDemoEnabled()) {
    logger.server('Explicit backend demo simulation stream enabled (DEMO_MODE=true). Starting autonomous simulator...');
    startBackendDemoSimulator(1000);
  }
});

// 8. Graceful Shutdown
function handleShutdown(signal) {
  logger.server(`Received ${signal}. Shutting down MineGuard backend gracefully...`);
  stopBackendDemoSimulator();
  server.close(() => {
    logger.server('HTTP and WebSocket servers closed.');
    process.exit(0);
  });
}

process.on('SIGINT', () => handleShutdown('SIGINT'));
process.on('SIGTERM', () => handleShutdown('SIGTERM'));

export { app, server };
