import { WebSocketServer, WebSocket } from 'ws';
import { logger } from '../config/config.js';
import { getDeviceStatus } from '../services/deviceService.js';

/**
 * MineGuard AI — WebSocket Telemetry Broadcast Manager
 *
 * Manages real-time WebSocket connections with React frontend clients.
 * Broadcasts:
 * - type: "telemetry"
 * - type: "device_status"
 * - type: "alert"
 */

let wssInstance = null;
const clients = new Set();

/**
 * Initialize WebSocket server bound to existing HTTP server instance
 * @param {import('http').Server} httpServer
 */
export function initTelemetrySocket(httpServer) {
  wssInstance = new WebSocketServer({
    noServer: true
  });

  // Handle HTTP Upgrade manually for resilient path resolution
  httpServer.on('upgrade', (req, socket, head) => {
    try {
      let pathname = req.url || '';
      try {
        const host = req.headers.host || 'localhost';
        const parsed = new URL(req.url, `http://${host}`);
        pathname = parsed.pathname;
      } catch {
        const qIdx = pathname.indexOf('?');
        if (qIdx !== -1) pathname = pathname.slice(0, qIdx);
      }

      // Normalize pathname: remove trailing slash if not root
      const normalizedPath = pathname.length > 1 && pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;

      // Accept /ws, /ws/, or root /
      if (normalizedPath === '/ws' || normalizedPath === '/' || normalizedPath === '') {
        wssInstance.handleUpgrade(req, socket, head, (ws) => {
          wssInstance.emit('connection', ws, req);
        });
      } else {
        logger.websocket(`Rejecting WebSocket upgrade for unrecognized path: "${req.url}"`);
        socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
        socket.destroy();
      }
    } catch (err) {
      logger.error('WebSocket upgrade error:', err.message);
      socket.destroy();
    }
  });

  wssInstance.on('connection', (ws, req) => {
    clients.add(ws);
    const ip = req.socket.remoteAddress || 'unknown';
    logger.websocket(`Frontend client connected from ${ip} (Active clients: ${clients.size})`);

    // Immediately send current real device status upon initial connection
    try {
      const initialStatus = getDeviceStatus();
      ws.send(JSON.stringify({
        type: 'device_status',
        data: initialStatus,
        timestamp: new Date().toISOString()
      }));
    } catch (err) {
      logger.error('Failed to send initial status to client:', err.message);
    }

    // Heartbeat ping-pong
    ws.isAlive = true;
    ws.on('pong', () => {
      ws.isAlive = true;
    });

    // Handle client messages if any
    ws.on('message', (messageRaw) => {
      try {
        const msg = JSON.parse(messageRaw.toString());
        if (msg.type === 'get_status') {
          ws.send(JSON.stringify({
            type: 'device_status',
            data: getDeviceStatus(),
            timestamp: new Date().toISOString()
          }));
        } else if (msg.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
        }
      } catch {
        // Ignore unparseable raw messages
      }
    });

    ws.on('close', () => {
      clients.delete(ws);
      logger.websocket(`Frontend client disconnected (Active clients: ${clients.size})`);
    });

    ws.on('error', (err) => {
      clients.delete(ws);
      logger.websocket(`Client connection error: ${err.message}`);
    });
  });

  // Heartbeat interval to drop unresponsive sockets
  const pingInterval = setInterval(() => {
    if (!wssInstance) return;
    for (const ws of clients) {
      if (ws.isAlive === false) {
        clients.delete(ws);
        ws.terminate();
        continue;
      }
      ws.isAlive = false;
      ws.ping();
    }
  }, 30000);

  wssInstance.on('close', () => {
    clearInterval(pingInterval);
  });

  logger.websocket('WebSocket telemetry server initialized on path /ws');
  return wssInstance;
}

/**
 * Broadcast structured payload to all connected frontend clients
 * @param {'telemetry' | 'device_status' | 'alert'} type
 * @param {Object} data
 */
export function broadcast(type, data) {
  if (!clients || clients.size === 0) {
    return;
  }

  const payload = JSON.stringify({
    type,
    data,
    timestamp: new Date().toISOString()
  });

  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(payload);
      } catch (err) {
        logger.error(`Broadcast failed for client: ${err.message}`);
      }
    }
  }
}

/**
 * Get count of active connected clients
 */
export function getConnectedClientCount() {
  return clients.size;
}
