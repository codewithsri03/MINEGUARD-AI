import { config, logger } from '../config/config.js';
import { dbSaveAlert, dbGetAlerts, dbAcknowledgeAlert } from '../db/database.js';

/**
 * MineGuard AI — Alert & Event Engine Service
 *
 * Evaluates risk assessments against configurable operational thresholds.
 * Automatically deduplicates alerts within configurable cooldown window.
 * Persists all events to SQLite database.
 */

// In-memory timestamp map for alert deduplication: `${nodeId}:${type}` -> lastTriggeredMs
const recentAlertTimestamps = new Map();

/**
 * Classify alert type from primary breached factor
 */
function classifyAlertType(primaryFactor) {
  if (!primaryFactor) return 'GEOTECHNICAL_ANOMALY';

  switch (primaryFactor.parameter) {
    case 'distance':
      return 'ROOF_CONVERGENCE_BREACH';
    case 'tilt':
      return 'STRUCTURAL_TILT_BREACH';
    case 'gasAdc':
      return 'HAZARDOUS_GAS_DETECTED';
    case 'temperature':
      return 'THERMAL_LIMIT_BREACH';
    case 'rainAdc':
      return 'WATER_INGRESS_DETECTED';
    default:
      return 'GEOTECHNICAL_ANOMALY';
  }
}

/**
 * Construct descriptive, operator-actionable alert message
 */
function buildAlertMessage(nodeId, factors) {
  if (!factors || factors.length === 0) {
    return `Anomalous readings detected on station ${nodeId}`;
  }

  const primary = factors[0];
  if (primary.parameter === 'distance') {
    return `Excessive roof convergence detected on ${nodeId} (${primary.value} cm < ${primary.threshold} cm)`;
  }
  if (primary.parameter === 'tilt') {
    return `Elevated structural roof tilt on ${nodeId} (${primary.value}° > ${primary.threshold}°)`;
  }
  if (primary.parameter === 'gasAdc') {
    return `Hazardous gas concentration detected on ${nodeId} (${primary.value} ADC > ${primary.threshold} ADC)`;
  }
  if (primary.parameter === 'temperature') {
    return `Stope ambient temperature exceeded safe limit on ${nodeId} (${primary.value}°C > ${primary.threshold}°C)`;
  }
  if (primary.parameter === 'rainAdc') {
    return `Water ingress detected in stope drainage on ${nodeId} (${primary.value} ADC)`;
  }
  return `${primary.label} breach on ${nodeId}: ${primary.value}`;
}

/**
 * Evaluate telemetry packet and generate alert if abnormal conditions exist
 * @param {Object} processedPacket - Canonical packet with { nodeId, raw, derived, source }
 * @param {Object} riskResult - Result from riskService.calculateRisk
 * @returns {Object|null}
 */
export function evaluateTelemetryAlerts(processedPacket, riskResult) {
  if (!riskResult || riskResult.status === 'NORMAL' || !riskResult.factors || riskResult.factors.length === 0) {
    return null;
  }

  const nowMs = Date.now();
  const nodeId = processedPacket.nodeId;
  const severity = riskResult.status; // 'WARNING' | 'CRITICAL'
  const primaryFactor = riskResult.factors[0];
  const type = classifyAlertType(primaryFactor);

  // Cooldown / Deduplication check: prevent flooding duplicate alerts for same node & hazard type in SQLite
  const dedupKey = `${nodeId}:${type}:${severity}`;
  const lastFired = recentAlertTimestamps.get(dedupKey) || 0;
  const cooldownMs = config.alerts.cooldownMs;
  const isWithinCooldown = (nowMs - lastFired) < cooldownMs;

  if (isWithinCooldown) {
    // Within cooldown window: return existing active alert to ensure WebSocket subscribers receive alert event
    // without flooding SQLite database with duplicate records
    const existing = dbGetAlerts({ nodeId, severity, limit: 1 });
    if (existing && existing.length > 0) {
      return existing[0];
    }
  }

  // Update cooldown record
  recentAlertTimestamps.set(dedupKey, nowMs);

  const alertId = `alt-${nowMs}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
  const newAlert = {
    id: alertId,
    alertId,
    nodeId,
    severity,
    type,
    message: buildAlertMessage(nodeId, riskResult.factors),
    source: processedPacket.source || 'hardware',
    acknowledged: false,
    acknowledgedAt: null,
    acknowledgedBy: null,
    timestamp: processedPacket.timestamp || new Date(nowMs).toISOString(),
    factors: riskResult.factors
  };

  // Persist into SQLite
  dbSaveAlert(newAlert);

  logger.alert(`${nodeId} ${severity} [${type}]: ${newAlert.message}`);
  return newAlert;
}

/**
 * Return all alerts matching optional criteria
 */
export function getAlerts(filter = {}) {
  return dbGetAlerts(filter);
}

/**
 * Return alerts for a specific node
 */
export function getAlertsByNode(nodeId, limit = 50) {
  return dbGetAlerts({ nodeId, limit });
}

/**
 * Acknowledge an alert by ID
 */
export function acknowledgeAlert(alertId, actor = 'System Operator') {
  return dbAcknowledgeAlert(alertId, actor);
}

/**
 * Clear alert cooldown cache (for testing and reset)
 */
export function clearAlertCooldowns() {
  recentAlertTimestamps.clear();
}
