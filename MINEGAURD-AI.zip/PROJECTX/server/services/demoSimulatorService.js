import { logger } from '../config/config.js';
import { ingestTelemetry } from './telemetryService.js';
import { onSimulatorStopped, getDeviceStatus } from './deviceService.js';
import { broadcast } from '../websocket/telemetrySocket.js';

/**
 * MineGuard AI — Autonomous Backend Demo/Simulation Stream Service
 *
 * Dedicated to software testing, verification, and presentation
 * before physical ESP32 hardware is connected.
 *
 * Requirements:
 * - Runs purely on the BACKEND, NOT inside React.
 * - Flow: Demo Simulator -> MineGuard Backend -> Ingestion/Risk/Alerts -> WebSocket -> Vercel Frontend
 * - Simulates ONLY actual hardware channels:
 *   ESP32, MPU9250, HC-SR04, Temperature, Humidity, Pressure, Gas, Rain
 * - Every packet has source: "simulator", isSimulated: true
 * - Never marks ESP32 as connected (strict hardware safety isolation)
 * - Demonstrates NORMAL, WARNING, CRITICAL scenarios naturally
 */

export const DEMO_NODES = ['N-01', 'N-02', 'N-03', 'N-04', 'N-05', 'N-06', 'N-07', 'N-08'];

let demoIntervalId = null;
let tickCounter = 0;

/**
 * Check if demo mode is enabled in the backend environment
 */
export function isBackendDemoEnabled() {
  const envVal = process.env.DEMO_MODE || process.env.VITE_DEMO_MODE;
  return envVal === 'true' || envVal === true;
}

/**
 * Generate authentic hardware-mirroring simulation packet for a MineGuard station
 */
export function generateBackendDemoPacket(nodeId = 'N-01', cycleTick = 0) {
  const timestamp = new Date().toISOString();

  // Baseline physics profiles per node
  let distance = 18.5; // cm (nominal > 17.0)
  let tilt = 0.5;      // deg (nominal < 2.0)
  let temp = 24.2;     // °C (nominal < 35.0)
  let hum = 64.0;      // % (nominal < 85.0)
  let press = 1012.8;  // hPa
  let gas = 380;       // ADC (nominal < 2200)
  let rain = 15;       // ADC (nominal < 350)
  let accelX = 0.02;
  let accelY = 0.01;
  let accelZ = 0.99;

  // Add smooth natural environmental micro-fluctuations
  const noise = (Math.sin(cycleTick * 0.7 + nodeId.charCodeAt(2)) + Math.random() * 0.4) * 0.2;

  switch (nodeId) {
    case 'N-01':
      // Main Haulage Entry: Nominal
      distance = Number((18.4 + noise * 0.3).toFixed(1));
      tilt = Number((0.45 + Math.abs(noise) * 0.15).toFixed(2));
      temp = Number((23.8 + noise * 0.4).toFixed(1));
      hum = Number((62.5 + noise * 0.8).toFixed(1));
      gas = Math.round(350 + Math.abs(noise) * 40);
      break;

    case 'N-02':
      // Portal Cross-Cut: Nominal
      distance = Number((19.1 + noise * 0.2).toFixed(1));
      tilt = Number((0.32 + Math.abs(noise) * 0.1).toFixed(2));
      temp = Number((24.0 + noise * 0.3).toFixed(1));
      hum = Number((61.8 + noise * 0.5).toFixed(1));
      gas = Math.round(320 + Math.abs(noise) * 30);
      break;

    case 'N-03':
      // North Drift Heading: Nominal
      distance = Number((18.2 + noise * 0.3).toFixed(1));
      tilt = Number((0.68 + Math.abs(noise) * 0.2).toFixed(2));
      temp = Number((25.1 + noise * 0.4).toFixed(1));
      hum = Number((66.2 + noise * 0.9).toFixed(1));
      gas = Math.round(410 + Math.abs(noise) * 50);
      break;

    case 'N-04':
      // Central Junction B: Nominal
      distance = Number((18.6 + noise * 0.3).toFixed(1));
      tilt = Number((0.95 + Math.abs(noise) * 0.2).toFixed(2));
      temp = Number((25.8 + noise * 0.5).toFixed(1));
      hum = Number((67.5 + noise * 1.0).toFixed(1));
      gas = Math.round(480 + Math.abs(noise) * 50);
      break;

    case 'N-05':
      // Ventilation Incline: Nominal
      distance = Number((18.8 + noise * 0.2).toFixed(1));
      tilt = Number((0.55 + Math.abs(noise) * 0.15).toFixed(2));
      temp = Number((22.6 + noise * 0.4).toFixed(1));
      hum = Number((70.4 + noise * 1.2).toFixed(1));
      press = Number((1014.2 + noise * 0.3).toFixed(1));
      gas = Math.round(360 + Math.abs(noise) * 30);
      break;

    case 'N-06':
      // South Access Gallery: Demonstrating WARNING threshold breach
      // Thresholds: distance warning <= 17.0 cm, tilt warning >= 2.0°
      distance = Number((16.4 + Math.sin(cycleTick * 0.5) * 0.4).toFixed(1));
      tilt = Number((2.25 + Math.sin(cycleTick * 0.4) * 0.2).toFixed(2));
      accelX = 0.14;
      accelY = 0.08;
      accelZ = 0.96;
      temp = Number((28.5 + noise * 0.5).toFixed(1));
      hum = Number((74.0 + noise * 1.0).toFixed(1));
      gas = Math.round(680 + Math.abs(noise) * 80);
      break;

    case 'N-07':
      // Sub-Level 4 Stope: Demonstrating CRITICAL strata convergence & hazardous gas breach
      // Thresholds: distance critical <= 15.0 cm, gas critical >= 2600 ADC
      distance = Number((14.1 + Math.sin(cycleTick * 0.3) * 0.3).toFixed(1));
      tilt = Number((3.35 + Math.sin(cycleTick * 0.3) * 0.25).toFixed(2));
      accelX = 0.22;
      accelY = 0.18;
      accelZ = 0.92;
      temp = Number((31.2 + noise * 0.6).toFixed(1));
      hum = Number((81.5 + noise * 1.5).toFixed(1));
      gas = Math.round(2720 + Math.abs(noise) * 120);
      break;

    case 'N-08':
      // Drainage Cross-Cut: Demonstrating Water Ingress / Rain sensor activity
      distance = Number((18.1 + noise * 0.3).toFixed(1));
      tilt = Number((0.85 + Math.abs(noise) * 0.2).toFixed(2));
      temp = Number((21.8 + noise * 0.4).toFixed(1));
      hum = Number((88.2 + noise * 1.5).toFixed(1));
      rain = Math.round(410 + Math.abs(noise) * 60); // warning threshold >= 350 ADC
      break;

    default:
      break;
  }

  return {
    nodeId,
    deviceId: 'ESP32-SIM-01',
    source: 'simulator',
    isSimulated: true,
    timestamp,
    sensors: {
      mpu9250: {
        accel: { x: accelX, y: accelY, z: accelZ },
        gyro: { x: 0.1, y: 0.0, z: 0.2 },
        mag: { x: 18.2, y: -4.5, z: 42.1 },
        x: accelX,
        y: accelY,
        z: accelZ
      },
      hcSr04: {
        distance
      },
      temperature: temp,
      humidity: hum,
      pressure: press,
      gas,
      rain,
      tilt
    },
    signal: 88
  };
}

/**
 * Start autonomous backend demo simulator
 */
export function startBackendDemoSimulator(intervalMs = 2000) {
  if (demoIntervalId) return;

  logger.server(`[DEMO SIMULATOR] Starting autonomous backend demo stream (${intervalMs}ms interval)...`);

  demoIntervalId = setInterval(() => {
    // If real physical hardware is connected, autonomous simulator pauses so real hardware has exclusive precedence
    const status = getDeviceStatus();
    if (status && status.connected) {
      return;
    }

    tickCounter++;
    // Cycle through nodes to keep all 8 stations updated
    const nodeIndex = (tickCounter - 1) % DEMO_NODES.length;
    const nodeId = DEMO_NODES[nodeIndex];
    const packet = generateBackendDemoPacket(nodeId, tickCounter);

    try {
      ingestTelemetry(packet);
    } catch (err) {
      logger.error(`[DEMO SIMULATOR] Error ingesting packet for ${nodeId}: ${err.message}`);
    }
  }, intervalMs);
}

/**
 * Stop backend demo simulator
 */
export function stopBackendDemoSimulator() {
  if (demoIntervalId) {
    clearInterval(demoIntervalId);
    demoIntervalId = null;
    logger.server('[DEMO SIMULATOR] Backend demo simulator stopped.');
  }
  onSimulatorStopped();
  try {
    broadcast('device_status', getDeviceStatus());
  } catch {
    // Ignore if websocket server is not initialized
  }
}

/**
 * Check if simulator is currently running
 */
export function isSimulatorRunning() {
  return Boolean(demoIntervalId);
}
