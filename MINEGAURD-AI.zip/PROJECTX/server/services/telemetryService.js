import { logger } from '../config/config.js';
import { dbSaveTelemetry, dbGetTelemetryHistory } from '../db/database.js';
import { processSensorPacket } from './sensorProcessing.js';
import { recordNodeTelemetry, getDeviceStatus, setTelemetryIngestCallback } from './deviceService.js';
import { calculateRisk } from './riskService.js';
import { evaluateTelemetryAlerts } from './alertService.js';
import { broadcast } from '../websocket/telemetrySocket.js';
import { isSimulatorRunning } from './demoSimulatorService.js';

/**
 * MineGuard AI — Telemetry Ingestion, Processing & Storage Service
 *
 * Coordinates:
 * Raw ingestion -> Sensor Processing -> Risk Analysis -> Alert Engine -> SQLite Persistence -> WebSocket Broadcast
 */

// In-memory latest snapshot per node for instant O(1) reads
const latestByNode = new Map();

/**
 * Telemetry Validator
 */
export function validateTelemetryPacket(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    return { valid: false, error: 'Telemetry payload must be a valid JSON object.' };
  }

  const nodeId = typeof payload.nodeId === 'string' ? payload.nodeId.trim() : null;
  if (!nodeId) {
    return { valid: false, error: 'Missing or empty required field: "nodeId" (string).' };
  }

  return { valid: true };
}

/**
 * Ingest, process, evaluate, persist, and broadcast telemetry
 */
export function ingestTelemetry(rawPacket) {
  const validation = validateTelemetryPacket(rawPacket);
  if (!validation.valid) {
    return {
      success: false,
      error: validation.error
    };
  }

  const receivedAt = new Date().toISOString();

  // 1. Separate Raw Hardware Data from Derived Application Data
  const processed = processSensorPacket(rawPacket);
  const { nodeId, raw, derived, source, isSimulated } = processed;

  // Simulator OFF safety: drop any simulated packets if simulator is inactive
  if ((isSimulated || source === 'simulator') && !isSimulatorRunning()) {
    logger.telemetry(`Dropped simulated packet for ${nodeId}: Simulator is OFF.`);
    return {
      success: false,
      ignored: true,
      error: 'Simulator is inactive. Simulated telemetry dropped.'
    };
  }

  // 2. Update Node & Gateway Lifecycle Status
  const recordResult = recordNodeTelemetry(processed);
  if (recordResult && recordResult.ignored) {
    logger.telemetry(`Ignoring simulated packet for ${nodeId}: physical hardware is active.`);
    return {
      success: true,
      ignored: true,
      nodeId,
      source: 'hardware_preserved'
    };
  }

  // 3. Calculate Geotechnical & Environmental Risk
  const riskResult = calculateRisk(processed);

  // 4. Evaluate Threshold Breaches & Generate Deduplicated Alerts
  const newAlert = evaluateTelemetryAlerts(processed, riskResult);

  // 5. Assemble Canonical Telemetry Record
  const telemetryRecord = {
    nodeId,
    timestamp: raw.timestamp || receivedAt,
    receivedAt,
    source,
    isSimulated,
    isTest: isSimulated,
    raw,
    derived,
    // Flat accessors for backward compatibility
    temperature: raw.temperature,
    humidity: raw.humidity,
    pressure: raw.pressure,
    distance: raw.distance,
    tilt: derived.tiltDeg ?? raw.tilt,
    gasAdc: raw.gasAdc,
    rainAdc: raw.rainAdc,
    imu: raw.imu,
    signal: raw.signal,
    gatewayId: raw.gatewayId,
    risk: {
      score: riskResult.riskScore,
      level: riskResult.status,
      factors: riskResult.factors
    }
  };

  // 6. Update in-memory latest cache
  latestByNode.set(nodeId, telemetryRecord);

  // 7. Persist to SQLite Database
  dbSaveTelemetry(telemetryRecord);

  // 8. WebSocket Broadcasts (Telemetry, Risk, Alerts, Device Status)
  // A. Broadcast telemetry
  broadcast('telemetry', {
    nodeId,
    timestamp: telemetryRecord.timestamp,
    receivedAt,
    source,
    isSimulated,
    temperature: raw.temperature,
    humidity: raw.humidity,
    pressure: raw.pressure,
    distance: raw.distance,
    tilt: derived.tiltDeg,
    gasAdc: raw.gasAdc,
    rainAdc: raw.rainAdc,
    imu: raw.imu,
    signal: raw.signal,
    risk: telemetryRecord.risk
  });

  // B. Broadcast dedicated risk update event
  broadcast('risk', {
    nodeId,
    riskScore: riskResult.riskScore,
    status: riskResult.status,
    factors: riskResult.factors,
    timestamp: telemetryRecord.timestamp
  });

  // C. Broadcast alert if triggered
  if (newAlert) {
    broadcast('alert', newAlert);
  }

  // D. Broadcast device connection status
  broadcast('device_status', getDeviceStatus());

  // 9. Structured logging
  logger.telemetry(`${nodeId} packet ingested [${source.toUpperCase()}] (Risk: ${riskResult.status} ${riskResult.riskScore}/100)`);

  return {
    success: true,
    nodeId,
    receivedAt,
    isSimulated,
    source
  };
}

// Register ingestion callback with deviceService for IP polling
setTelemetryIngestCallback(ingestTelemetry);

/**
 * Retrieve latest telemetry for all nodes or a specific node
 */
export function getLatestTelemetry(nodeId = null) {
  if (nodeId) {
    return latestByNode.get(nodeId) || null;
  }
  const all = {};
  for (const [id, record] of latestByNode.entries()) {
    all[id] = record;
  }
  return all;
}

/**
 * Retrieve historical telemetry from SQLite database
 */
export function getNodeHistory(nodeId, options = {}) {
  return dbGetTelemetryHistory(nodeId, options);
}

/**
 * Clear in-memory cache (for testing)
 */
export function clearTelemetryStore() {
  latestByNode.clear();
}
