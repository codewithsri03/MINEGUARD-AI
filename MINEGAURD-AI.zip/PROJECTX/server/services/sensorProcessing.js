import { config } from '../config/config.js';

/**
 * MineGuard AI — Sensor Data Processing Layer
 *
 * Strictly separates RAW HARDWARE DATA from DERIVED APPLICATION DATA.
 *
 * Supported Hardware:
 * - MPU9250: 9-DOF IMU (Accelerometer, Gyroscope, Magnetometer)
 * - HC-SR04: Ultrasonic roof convergence / displacement distance
 * - Ambient: Temperature, Humidity, Barometric Pressure
 * - Environmental: MQ Gas sensor ADC, Rain/Water-ingress sensor ADC
 *
 * CRITICAL RULE: Raw hardware data is stored verbatim and remains completely immutable.
 */

/**
 * Extract clean, immutable raw sensor readings from incoming packet
 */
export function extractRawSensorData(payload) {
  const numOrNull = (val) => {
    if (val === undefined || val === null || val === '') return null;
    const n = Number(val);
    return isFinite(n) ? n : null;
  };

  const sensors = payload.sensors && typeof payload.sensors === 'object' ? payload.sensors : {};

  // MPU9250 9-DOF IMU extraction (supports sensors.mpu9250, sensors.imu, payload.mpu9250, payload.imu)
  const imuSource = sensors.mpu9250 || sensors.imu || payload.mpu9250 || payload.imu;
  let imu = null;

  if (imuSource && typeof imuSource === 'object') {
    const rawX = numOrNull(imuSource.x ?? imuSource.accel?.x) ?? 0;
    const rawY = numOrNull(imuSource.y ?? imuSource.accel?.y) ?? 0;
    const rawZ = numOrNull(imuSource.z ?? imuSource.accel?.z) ?? 1;

    imu = {
      x: rawX,
      y: rawY,
      z: rawZ,
      accel: imuSource.accel || { x: rawX, y: rawY, z: rawZ },
      gyro: imuSource.gyro || null,
      mag: imuSource.mag || null
    };
  }

  // Signal extraction: Never invent signal strength if missing
  let signal = numOrNull(sensors.signal ?? payload.signal);
  const rssiSource = sensors.rssi !== undefined ? sensors.rssi : payload.rssi;
  if (signal === null && rssiSource !== undefined && rssiSource !== null) {
    const rssi = Number(rssiSource);
    if (!isNaN(rssi)) {
      signal = Math.min(100, Math.max(0, 100 + rssi));
    }
  }

  // HC-SR04 distance extraction
  const distance = numOrNull(
    sensors.hcSr04?.distance ??
    sensors.distance ??
    payload.distance
  );

  // Environmental & hazard sensors
  const temperature = numOrNull(sensors.temperature ?? payload.temperature);
  const humidity = numOrNull(sensors.humidity ?? payload.humidity);
  const pressure = numOrNull(sensors.pressure ?? payload.pressure);
  const gasAdc = numOrNull(sensors.gas ?? sensors.gasAdc ?? payload.gas ?? payload.gasAdc);
  const rainAdc = numOrNull(sensors.rain ?? sensors.rainAdc ?? payload.rain ?? payload.rainAdc);
  const tilt = numOrNull(sensors.tilt ?? payload.tilt);

  const deviceId = payload.deviceId || payload.gatewayId || sensors.deviceId || 'ESP32-01';

  return {
    nodeId: payload.nodeId || sensors.nodeId || 'N-01',
    timestamp: payload.timestamp || sensors.timestamp,
    temperature,
    humidity,
    pressure,
    gasAdc,
    rainAdc,
    distance,
    tilt,
    imu,
    signal,
    gatewayId: deviceId,
    deviceId,
    isSimulated: Boolean(payload.isSimulated || payload.isSimulator || payload.isTest || payload.source === 'simulator'),
    source: payload.source || ((payload.isSimulated || payload.isSimulator || payload.isTest) ? 'simulator' : 'hardware')
  };
}

/**
 * Compute derived geotechnical & ambient application metrics from raw readings
 * without modifying the raw readings.
 */
export function computeDerivedMetrics(raw) {
  const { thresholds } = config;

  // 1. MPU9250 Structural Roof Tilt Angle (Degrees)
  let tiltDeg = null;
  if (raw.tilt !== null && !isNaN(raw.tilt)) {
    tiltDeg = Number(raw.tilt.toFixed(2));
  } else if (raw.imu) {
    const x = raw.imu.x ?? 0;
    const y = raw.imu.y ?? 0;
    const z = raw.imu.z ?? 1;
    const horizontalMag = Math.sqrt(x * x + y * y);
    const rad = Math.atan2(horizontalMag, Math.abs(z));
    tiltDeg = Number((rad * (180 / Math.PI)).toFixed(2));
  }

  // 2. MPU9250 Dynamic Vibration Indicator (deviation from static 1g gravity)
  let vibrationIndex = null;
  if (raw.imu) {
    const x = raw.imu.x ?? 0;
    const y = raw.imu.y ?? 0;
    const z = raw.imu.z ?? 1;
    const totalG = Math.sqrt(x * x + y * y + z * z);
    vibrationIndex = Number(Math.abs(totalG - 1.0).toFixed(3));
  }

  // 3. HC-SR04 Roof Convergence Clearance (cm)
  const convergenceCm = raw.distance !== null ? Number(raw.distance.toFixed(1)) : null;

  // 4. Hazardous Gas Status
  let gasStatus = 'nominal';
  if (raw.gasAdc !== null) {
    if (raw.gasAdc >= thresholds.gasAdc.critical) gasStatus = 'critical';
    else if (raw.gasAdc >= thresholds.gasAdc.warning) gasStatus = 'warning';
  }

  // 5. Thermal Environment Status
  let thermalStatus = 'nominal';
  if (raw.temperature !== null) {
    if (raw.temperature >= thresholds.temperature.critical) thermalStatus = 'critical';
    else if (raw.temperature >= thresholds.temperature.warning) thermalStatus = 'warning';
  }

  // 6. Water Ingress / Rain Status
  let waterIngressStatus = 'dry';
  if (raw.rainAdc !== null) {
    if (raw.rainAdc >= thresholds.rainAdc.critical) waterIngressStatus = 'inflow';
    else if (raw.rainAdc >= thresholds.rainAdc.warning) waterIngressStatus = 'damp';
  }

  return {
    tiltDeg,
    vibrationIndex,
    convergenceCm,
    gasStatus,
    thermalStatus,
    waterIngressStatus,
    computedAt: new Date().toISOString()
  };
}

/**
 * Full Pipeline: Parse raw, isolate derived, assemble canonical packet
 */
export function processSensorPacket(payload) {
  const raw = extractRawSensorData(payload);
  const derived = computeDerivedMetrics(raw);

  return {
    nodeId: raw.nodeId,
    timestamp: raw.timestamp || new Date().toISOString(),
    source: raw.source,
    isSimulated: raw.isSimulated,
    raw,
    derived
  };
}
