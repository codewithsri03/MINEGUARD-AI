import { config } from '../config/config.js';

/**
 * MineGuard AI — Geotechnical & Environmental Risk Engine
 *
 * Evaluates multi-factor sensor data from physical MPU9250, HC-SR04, and environmental sensors.
 *
 * IMPORTANT GEOTECHNICAL DISCLAIMER:
 * The thresholds and formulas used herein represent project-configurable operational parameters
 * for software evaluation. They are NOT scientifically validated for life-critical strata control
 * and must undergo formal geotechnical calibration and regulatory validation (e.g. DGMS/MSHA)
 * before physical deployment in active mining operations.
 */

/**
 * Calculate multi-factor risk assessment for a single node packet
 * @param {Object} processedPacket - Object containing { nodeId, raw, derived }
 * @returns {{ nodeId: string, riskScore: number, status: 'NORMAL'|'WARNING'|'CRITICAL', factors: Array, timestamp: string }}
 */
export function calculateRisk(processedPacket) {
  const { thresholds } = config;
  const raw = processedPacket.raw || processedPacket;
  const derived = processedPacket.derived || {};
  const nodeId = processedPacket.nodeId || raw.nodeId || 'UNKNOWN';

  const factors = [];
  let highestFactorSeverity = 'NORMAL';
  let scoreAccumulator = 15; // baseline nominal underground ambient risk

  // 1. Structural Roof Convergence / Distance Closure (HC-SR04)
  const distance = raw.distance ?? derived.convergenceCm;
  if (distance !== null && distance !== undefined && !isNaN(distance)) {
    if (distance <= thresholds.distance.critical) {
      factors.push({
        parameter: 'distance',
        label: 'Roof Convergence Compression',
        value: distance,
        unit: 'cm',
        threshold: thresholds.distance.critical,
        severity: 'CRITICAL',
        description: `Roof clearance has compressed to ${distance} cm (critical threshold: ${thresholds.distance.critical} cm)`
      });
      highestFactorSeverity = 'CRITICAL';
      scoreAccumulator += 42;
    } else if (distance <= thresholds.distance.warning) {
      factors.push({
        parameter: 'distance',
        label: 'Roof Convergence Clearance',
        value: distance,
        unit: 'cm',
        threshold: thresholds.distance.warning,
        severity: 'WARNING',
        description: `Roof clearance is approaching warning limit at ${distance} cm (threshold: ${thresholds.distance.warning} cm)`
      });
      if (highestFactorSeverity !== 'CRITICAL') highestFactorSeverity = 'WARNING';
      scoreAccumulator += 25;
    }
  }

  // 2. Structural Roof Tilt Angle (MPU9250)
  const tilt = derived.tiltDeg ?? raw.tilt;
  if (tilt !== null && tilt !== undefined && !isNaN(tilt)) {
    if (tilt >= thresholds.tilt.critical) {
      factors.push({
        parameter: 'tilt',
        label: 'Structural Roof Tilt',
        value: tilt,
        unit: '°',
        threshold: thresholds.tilt.critical,
        severity: 'CRITICAL',
        description: `Roof support angle deviated by ${tilt}° (critical threshold: ${thresholds.tilt.critical}°)`
      });
      highestFactorSeverity = 'CRITICAL';
      scoreAccumulator += 38;
    } else if (tilt >= thresholds.tilt.warning) {
      factors.push({
        parameter: 'tilt',
        label: 'Structural Roof Tilt',
        value: tilt,
        unit: '°',
        threshold: thresholds.tilt.warning,
        severity: 'WARNING',
        description: `Elevated roof tilt detected at ${tilt}° (warning threshold: ${thresholds.tilt.warning}°)`
      });
      if (highestFactorSeverity !== 'CRITICAL') highestFactorSeverity = 'WARNING';
      scoreAccumulator += 20;
    }
  }

  // 3. Explosive / Toxic Gas Concentration (MQ Sensor)
  const gasAdc = raw.gasAdc;
  if (gasAdc !== null && gasAdc !== undefined && !isNaN(gasAdc)) {
    if (gasAdc >= thresholds.gasAdc.critical) {
      factors.push({
        parameter: 'gasAdc',
        label: 'Hazardous Gas Concentration',
        value: gasAdc,
        unit: 'ADC',
        threshold: thresholds.gasAdc.critical,
        severity: 'CRITICAL',
        description: `Hazardous gas ADC reading (${gasAdc}) exceeded critical threshold (${thresholds.gasAdc.critical})`
      });
      highestFactorSeverity = 'CRITICAL';
      scoreAccumulator += 35;
    } else if (gasAdc >= thresholds.gasAdc.warning) {
      factors.push({
        parameter: 'gasAdc',
        label: 'Elevated Gas Concentration',
        value: gasAdc,
        unit: 'ADC',
        threshold: thresholds.gasAdc.warning,
        severity: 'WARNING',
        description: `Elevated gas concentration detected at ${gasAdc} ADC (threshold: ${thresholds.gasAdc.warning})`
      });
      if (highestFactorSeverity !== 'CRITICAL') highestFactorSeverity = 'WARNING';
      scoreAccumulator += 18;
    }
  }

  // 4. Ambient Temperature
  const temperature = raw.temperature;
  if (temperature !== null && temperature !== undefined && !isNaN(temperature)) {
    if (temperature >= thresholds.temperature.critical) {
      factors.push({
        parameter: 'temperature',
        label: 'Ambient Mine Overheating',
        value: temperature,
        unit: '°C',
        threshold: thresholds.temperature.critical,
        severity: 'CRITICAL',
        description: `Ambient stope air temperature (${temperature}°C) breached critical limit (${thresholds.temperature.critical}°C)`
      });
      highestFactorSeverity = 'CRITICAL';
      scoreAccumulator += 25;
    } else if (temperature >= thresholds.temperature.warning) {
      factors.push({
        parameter: 'temperature',
        label: 'Elevated Ambient Temperature',
        value: temperature,
        unit: '°C',
        threshold: thresholds.temperature.warning,
        severity: 'WARNING',
        description: `Stope air temperature elevated to ${temperature}°C (threshold: ${thresholds.temperature.warning}°C)`
      });
      if (highestFactorSeverity !== 'CRITICAL') highestFactorSeverity = 'WARNING';
      scoreAccumulator += 12;
    }
  }

  // 5. Water Ingress / Inflow (Rain ADC)
  const rainAdc = raw.rainAdc;
  if (rainAdc !== null && rainAdc !== undefined && !isNaN(rainAdc)) {
    if (rainAdc >= thresholds.rainAdc.critical) {
      factors.push({
        parameter: 'rainAdc',
        label: 'Water Inflow / Ingress',
        value: rainAdc,
        unit: 'ADC',
        threshold: thresholds.rainAdc.critical,
        severity: 'CRITICAL',
        description: `Significant water inflow detected on station drainage (${rainAdc} ADC)`
      });
      highestFactorSeverity = 'CRITICAL';
      scoreAccumulator += 20;
    } else if (rainAdc >= thresholds.rainAdc.warning) {
      factors.push({
        parameter: 'rainAdc',
        label: 'Damp Water Sensor Detection',
        value: rainAdc,
        unit: 'ADC',
        threshold: thresholds.rainAdc.warning,
        severity: 'WARNING',
        description: `Moisture detected on station drainage (${rainAdc} ADC)`
      });
      if (highestFactorSeverity !== 'CRITICAL') highestFactorSeverity = 'WARNING';
      scoreAccumulator += 10;
    }
  }

  // Calculate normalized score (0 - 100)
  let riskScore = Math.min(100, Math.max(0, scoreAccumulator));

  let status = 'NORMAL';
  if (highestFactorSeverity === 'CRITICAL' || riskScore >= 70) {
    status = 'CRITICAL';
    if (riskScore < 72) riskScore = 78;
  } else if (highestFactorSeverity === 'WARNING' || riskScore >= 40) {
    status = 'WARNING';
    if (riskScore < 48) riskScore = 52;
  } else {
    status = 'NORMAL';
    if (riskScore > 35) riskScore = 24;
  }

  return {
    nodeId,
    riskScore,
    status,
    level: status, // alias for backwards compatibility
    score: riskScore, // alias for backwards compatibility
    factors,
    tiltDeg: tilt,
    timestamp: processedPacket.timestamp || new Date().toISOString()
  };
}

/**
 * Compute overall mine composite risk overview across all reporting nodes
 */
export function calculateMineOverview(nodesRiskList) {
  if (!nodesRiskList || nodesRiskList.length === 0) {
    return {
      overallStatus: 'NORMAL',
      overallRiskScore: 0,
      criticalNodes: [],
      warningNodes: [],
      totalEvaluated: 0
    };
  }

  const criticalNodes = [];
  const warningNodes = [];
  let maxRisk = 0;
  let sumRisk = 0;

  for (const item of nodesRiskList) {
    const score = item.riskScore ?? item.score ?? 0;
    sumRisk += score;
    if (score > maxRisk) maxRisk = score;

    if (item.status === 'CRITICAL' || item.level === 'CRITICAL') {
      criticalNodes.push(item.nodeId);
    } else if (item.status === 'WARNING' || item.level === 'WARNING') {
      warningNodes.push(item.nodeId);
    }
  }

  const avgRisk = Math.round(sumRisk / nodesRiskList.length);
  // Occupancy/safety weighting: Peak zone carries 70% weight, average carries 30%
  const overallRiskScore = Math.min(100, Math.round(maxRisk * 0.7 + avgRisk * 0.3));

  let overallStatus = 'NORMAL';
  if (criticalNodes.length > 0 || overallRiskScore >= 70) {
    overallStatus = 'CRITICAL';
  } else if (warningNodes.length > 0 || overallRiskScore >= 40) {
    overallStatus = 'WARNING';
  }

  return {
    overallStatus,
    overallRiskScore,
    criticalNodes,
    warningNodes,
    totalEvaluated: nodesRiskList.length,
    timestamp: new Date().toISOString()
  };
}
