import { config, logger } from '../config/config.js';
import { dbUpsertNode, dbGetAllNodes, dbGetNode } from '../db/database.js';

/**
 * MineGuard AI — Device & Node Life-Cycle Service
 *
 * Supports dynamic multi-node fleets (N-01 to N-N) backed by SQLite:
 * - Dynamic Node Status: ONLINE -> STALE -> OFFLINE based on configurable timeouts.
 * - Source Priority: Real hardware takes precedence over simulator packets.
 * - Real Gateway Connection State: connected is ONLY true when real telemetry is streaming.
 */

const gatewayState = {
  connected: false,
  gatewayId: null,
  lastPacket: null,
  lastPacketMs: null,
  signal: null,
  targetHost: null,
  targetPort: 80
};

// In-memory cache for fast lookup & timeout evaluation: nodeId -> nodeObject
const nodeCache = new Map();

/**
 * Initialize node cache from database on startup
 */
export function initNodeCache() {
  const dbNodes = dbGetAllNodes();
  for (const n of dbNodes) {
    nodeCache.set(n.nodeId, n);
  }
}

/**
 * Evaluate and refresh the status of all tracked nodes and gateway
 */
export function refreshConnectionStates() {
  const now = Date.now();
  const { nodeStaleMs, nodeOfflineMs, gatewayDisconnectMs } = config.timeouts;

  let onlineCount = 0;
  let staleCount = 0;
  let offlineCount = 0;

  for (const [nodeId, node] of nodeCache.entries()) {
    if (!node.lastSeen) {
      node.status = 'OFFLINE';
      offlineCount++;
      continue;
    }

    const elapsed = now - node.lastSeen;
    let nextStatus = 'ONLINE';

    if (elapsed >= nodeOfflineMs) {
      nextStatus = 'OFFLINE';
      offlineCount++;
    } else if (elapsed >= nodeStaleMs) {
      nextStatus = 'STALE';
      staleCount++;
    } else {
      nextStatus = 'ONLINE';
      onlineCount++;
    }

    if (node.status !== nextStatus) {
      node.status = nextStatus;
      dbUpsertNode(node);
      logger.device(`Node ${nodeId} transitioned to ${nextStatus} (${Math.round(elapsed / 1000)}s since last packet)`);
    }
  }

  // Check if gateway has timed out
  if (gatewayState.connected && gatewayState.lastPacketMs) {
    const gatewayElapsed = now - gatewayState.lastPacketMs;
    if (gatewayElapsed >= gatewayDisconnectMs) {
      gatewayState.connected = false;
      logger.device(`ESP32 gateway disconnected: No telemetry packets for ${Math.round(gatewayElapsed / 1000)}s`);
    }
  }

  return { onlineCount, staleCount, offlineCount, totalCount: nodeCache.size };
}

/**
 * Record telemetry packet for a node
 * @param {Object} processedPacket - Ingested packet with raw and derived data
 */
export function recordNodeTelemetry(processedPacket) {
  const now = Date.now();
  const raw = processedPacket.raw || processedPacket;
  const derived = processedPacket.derived || {};
  const nodeId = processedPacket.nodeId;
  const wasConnected = gatewayState.connected;

  const packetTimestamp = raw.timestamp
    ? new Date(raw.timestamp).toISOString()
    : new Date(now).toISOString();

  // Retrieve or create node record
  let node = nodeCache.get(nodeId);
  const defaultMeta = config.defaultNodes[nodeId] || {
    name: `Mine Station ${nodeId}`,
    zoneId: 'z_fleet',
    zoneName: 'Fleet Expansion',
    depth: -350,
    coords: { x: 300, y: 300 }
  };

  if (!node) {
    node = {
      nodeId,
      deviceId: raw.gatewayId || 'ESP32-GATEWAY-01',
      name: defaultMeta.name,
      zoneId: defaultMeta.zoneId,
      zoneName: defaultMeta.zoneName,
      depth: defaultMeta.depth,
      status: 'ONLINE',
      source: raw.source || 'hardware',
      lastSeen: now,
      latestTelemetry: null,
      metadata: { coords: defaultMeta.coords }
    };
  }

  // Source priority and strict hardware isolation:
  // If this node has active physical hardware telemetry, simulator packets must NEVER overwrite it!
  const hasActiveHardware = Boolean(
    (node.hasRealHardware && (now - (node.lastHardwareSeen || 0) < 30000)) ||
    (node.source === 'hardware' && gatewayState.connected)
  );

  if (raw.source === 'hardware') {
    node.source = 'hardware';
    node.hasRealHardware = true;
    node.lastHardwareSeen = now;
    node.lastSeen = now;
    node.status = 'ONLINE';
    node.deviceId = raw.gatewayId || node.deviceId;
    node.latestTelemetry = {
      nodeId,
      timestamp: packetTimestamp,
      temperature: raw.temperature,
      humidity: raw.humidity,
      pressure: raw.pressure,
      distance: raw.distance,
      gasAdc: raw.gasAdc,
      rainAdc: raw.rainAdc,
      tilt: derived.tiltDeg ?? raw.tilt,
      signal: raw.signal,
      source: 'hardware',
      isSimulated: false
    };
  } else if (!hasActiveHardware) {
    node.source = 'simulator';
    node.lastSeen = now;
    node.status = 'ONLINE';
    node.deviceId = raw.gatewayId || node.deviceId;
    node.latestTelemetry = {
      nodeId,
      timestamp: packetTimestamp,
      temperature: raw.temperature,
      humidity: raw.humidity,
      pressure: raw.pressure,
      distance: raw.distance,
      gasAdc: raw.gasAdc,
      rainAdc: raw.rainAdc,
      tilt: derived.tiltDeg ?? raw.tilt,
      signal: raw.signal,
      source: 'simulator',
      isSimulated: true
    };
  } else {
    // Simulator telemetry ignored: node is currently running real physical hardware
    return {
      gateway: gatewayState,
      nodesOnline: refreshConnectionStates().onlineCount,
      node,
      ignored: true
    };
  }

  // Update memory cache and SQLite
  nodeCache.set(nodeId, node);
  dbUpsertNode(node);

  // Update gateway state: ONLY physical hardware packets mark the physical ESP32 as connected
  if (raw.source === 'hardware') {
    gatewayState.connected = true;
    gatewayState.gatewayId = raw.gatewayId || 'ESP32-GATEWAY-01';
    gatewayState.lastPacket = packetTimestamp;
    gatewayState.lastPacketMs = now;
    gatewayState.signal = raw.signal;
    gatewayState.latestSource = 'hardware';
    gatewayState.latestNodeId = nodeId;
    gatewayState.latestDeviceId = raw.deviceId || raw.gatewayId || 'ESP32-01';

    if (!wasConnected) {
      logger.device(`ESP32 gateway connected via Wi-Fi [${gatewayState.gatewayId}]`);
    }
  } else {
    // Simulator telemetry: strictly preserves hardware safety (simulator active != ESP32 connected)
    gatewayState.lastSimPacket = packetTimestamp;
    gatewayState.lastSimPacketMs = now;
    if (!gatewayState.connected) {
      gatewayState.latestSource = 'simulator';
    }
  }

  const counts = refreshConnectionStates();
  return {
    gateway: gatewayState,
    nodesOnline: counts.onlineCount,
    node
  };
}

/**
 * Clean up simulator tracking when simulator is stopped
 */
export function onSimulatorStopped() {
  gatewayState.lastSimPacket = null;
  gatewayState.lastSimPacketMs = null;
  if (!gatewayState.connected) {
    gatewayState.latestSource = null;
  }
  for (const node of nodeCache.values()) {
    if (node.source === 'simulator') {
      node.status = 'OFFLINE';
      node.lastSeen = null;
      node.latestTelemetry = null;
      dbUpsertNode(node);
    }
  }
}

/**
 * Return current real device state and complete node list
 */
let pollingIntervalId = null;
let telemetryIngestFn = null;

/**
 * Register telemetry ingestion callback from telemetryService
 */
export function setTelemetryIngestCallback(fn) {
  telemetryIngestFn = fn;
}

/**
 * Validate IPv4 format or standard hostname
 */
export function isValidIpOrHostname(str) {
  if (!str || typeof str !== 'string') return false;
  const trimmed = str.trim();
  if (trimmed === 'localhost') return true;

  // IPv4 format validation
  const ipv4Regex = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const match = trimmed.match(ipv4Regex);
  if (match) {
    const octets = match.slice(1, 5).map(Number);
    return octets.every((o) => o >= 0 && o <= 255);
  }

  // Standard mDNS / local network domain (e.g. esp32.local, mineguard-esp.lan)
  const localDomainRegex = /^[a-zA-Z0-9-]+\.(local|internal|lan)$/i;
  return localDomainRegex.test(trimmed);
}

/**
 * Probe actual ESP32 HTTP endpoint with timeout
 */
export async function probeEsp32(host, port = 80, timeoutMs = 2500) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  const baseUrl = `http://${host}:${port}`;

  try {
    // 1. Try GET /api/telemetry
    let res = await fetch(`${baseUrl}/api/telemetry`, {
      signal: controller.signal,
      headers: { Accept: 'application/json' }
    }).catch(() => null);

    // 2. Fallback to GET /status
    if (!res || !res.ok) {
      res = await fetch(`${baseUrl}/status`, {
        signal: controller.signal,
        headers: { Accept: 'application/json' }
      }).catch(() => null);
    }

    clearTimeout(timeoutId);

    if (res && res.ok) {
      let telemetryData = null;
      try {
        telemetryData = await res.json();
      } catch {
        telemetryData = null;
      }
      return { reachable: true, telemetry: telemetryData };
    }

    return { reachable: false, error: 'Endpoint responded with error or non-200 status.' };
  } catch (err) {
    clearTimeout(timeoutId);
    return { reachable: false, error: err.message };
  }
}

/**
 * Start continuous background polling of ESP32 telemetry endpoint
 */
export function startDevicePolling(host, port, intervalMs = 2000) {
  stopDevicePolling();
  pollingIntervalId = setInterval(async () => {
    if (!gatewayState.connected) {
      stopDevicePolling();
      return;
    }
    try {
      const probeRes = await probeEsp32(host, port, 1800);
      if (probeRes.reachable && probeRes.telemetry && telemetryIngestFn) {
        telemetryIngestFn(probeRes.telemetry);
      } else if (!probeRes.reachable) {
        logger.device(`ESP32 periodic poll failed at ${host}:${port}: ${probeRes.error}`);
      }
    } catch (err) {
      logger.device(`ESP32 polling error: ${err.message}`);
    }
  }, intervalMs);
}

/**
 * Stop background polling
 */
export function stopDevicePolling() {
  if (pollingIntervalId) {
    clearInterval(pollingIntervalId);
    pollingIntervalId = null;
  }
}

/**
 * Return current real device state and complete node list
 */
export function getDeviceStatus() {
  const counts = refreshConnectionStates();
  const allNodes = Array.from(nodeCache.values()).map((n) => ({
    nodeId: n.nodeId,
    deviceId: n.deviceId,
    name: n.name,
    zoneId: n.zoneId,
    zoneName: n.zoneName,
    depth: n.depth,
    status: n.status,
    source: n.source,
    lastSeen: n.lastSeen,
    signal: n.latestTelemetry?.signal ?? null,
    latestTelemetry: n.latestTelemetry
  }));

  return {
    connected: gatewayState.connected,
    gateway: gatewayState.connected ? gatewayState.gatewayId : null,
    targetHost: gatewayState.targetHost,
    targetPort: gatewayState.targetPort,
    nodesOnline: counts.onlineCount,
    nodesStale: counts.staleCount,
    nodesOffline: counts.offlineCount,
    totalNodes: counts.totalCount,
    lastPacket: gatewayState.lastPacket,
    signal: gatewayState.connected ? gatewayState.signal : null,
    status: gatewayState.connected ? (counts.onlineCount > 0 ? 'connected' : 'stale') : 'disconnected',
    latestSource: gatewayState.latestSource || null,
    latestNodeId: gatewayState.latestNodeId || null,
    latestDeviceId: gatewayState.latestDeviceId || null,
    simulatorActive: Boolean(gatewayState.lastSimPacketMs && (Date.now() - gatewayState.lastSimPacketMs < 10000)),
    nodesCount: counts.totalCount,
    nodes: allNodes
  };
}

/**
 * Get details for a single node
 */
export function getNode(nodeId) {
  refreshConnectionStates();
  const cached = nodeCache.get(nodeId);
  if (cached) return cached;
  return dbGetNode(nodeId);
}

/**
 * Get all registered nodes
 */
export function getAllNodes() {
  refreshConnectionStates();
  return Array.from(nodeCache.values());
}

/**
 * Connect device (probes actual ESP32 IP, checks reachability, ingests telemetry, starts polling)
 */
export async function connectDevice(host, port = 80) {
  if (!host || !isValidIpOrHostname(host)) {
    return {
      success: false,
      statusCode: 400,
      error: 'Invalid IP address format. Expected format: 192.168.1.100',
      state: getDeviceStatus()
    };
  }

  const targetHost = host.trim();
  const targetPort = Number(port) || 80;

  // Active reachability probe against the actual device
  const probe = await probeEsp32(targetHost, targetPort, 2500);

  if (!probe.reachable) {
    // NEVER mark connected if unreachable
    gatewayState.connected = false;
    gatewayState.targetHost = targetHost;
    gatewayState.targetPort = targetPort;
    stopDevicePolling();

    logger.device(`ESP32 unreachable at ${targetHost}:${targetPort} (${probe.error})`);

    return {
      success: false,
      statusCode: 502,
      error: 'Unable to reach ESP32 at the supplied address.',
      state: getDeviceStatus()
    };
  }

  // Reachable!
  gatewayState.connected = true;
  gatewayState.targetHost = targetHost;
  gatewayState.targetPort = targetPort;

  // Ingest initial telemetry if returned from probe
  if (probe.telemetry && telemetryIngestFn) {
    telemetryIngestFn(probe.telemetry);
  }

  // Start continuous background polling
  startDevicePolling(targetHost, targetPort, 2000);

  logger.device(`ESP32 connected successfully at ${targetHost}:${targetPort}`);

  return {
    success: true,
    statusCode: 200,
    message: 'ESP32 connected successfully.',
    state: getDeviceStatus()
  };
}

/**
 * Disconnect physical device
 */
export function disconnectDevice() {
  stopDevicePolling();
  gatewayState.connected = false;
  gatewayState.lastPacket = null;
  gatewayState.lastPacketMs = null;
  gatewayState.signal = null;
  gatewayState.latestNodeId = null;
  gatewayState.latestDeviceId = null;

  for (const node of nodeCache.values()) {
    node.status = 'OFFLINE';
    node.hasRealHardware = false;
    dbUpsertNode(node);
  }

  logger.device('ESP32 gateway disconnected by operator command.');
  return {
    success: true,
    statusCode: 200,
    message: 'Disconnected from ESP32 gateway.',
    state: getDeviceStatus()
  };
}

/**
 * Reset memory state (useful for test isolation)
 */
export function resetDeviceState() {
  stopDevicePolling();
  gatewayState.connected = false;
  gatewayState.gatewayId = null;
  gatewayState.lastPacket = null;
  gatewayState.lastPacketMs = null;
  gatewayState.lastSimPacket = null;
  gatewayState.lastSimPacketMs = null;
  gatewayState.latestSource = null;
  gatewayState.latestNodeId = null;
  gatewayState.latestDeviceId = null;
  gatewayState.signal = null;
  gatewayState.targetHost = null;
  nodeCache.clear();
  initNodeCache();
  try {
    import('./alertService.js').then(m => m.clearAlertCooldowns()).catch(() => {});
  } catch {}
}
