#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <Wire.h>
#include <ArduinoJson.h>
#include "config.h"
#include "sensors/MPU9250.h"
#include "sensors/BME280.h"
#include "sensors/HCSR04.h"
#include "sensors/AnalogSensors.h"

/*
 * TelemetryHub owns every sensor driver, samples them on demand, and
 * serializes a reading into the exact "Nested Sensor Schema" JSON
 * documented in docs/hardware-integration.md — the same schema
 * server/services/sensorProcessing.js already parses on the backend.
 *
 * Design rule mirrored from the backend: never invent a value for a
 * sensor that isn't present/working. A field is simply omitted from
 * the JSON rather than sent as 0 — the backend's numOrNull() treats a
 * missing field as "no data", but would treat a literal 0 as a real
 * (and possibly alarming) reading.
 */
class TelemetryHub {
public:
  void begin() {
    pinMode(STATUS_LED_PIN, OUTPUT);

#if ENABLE_MPU9250 || ENABLE_BME280
    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
#endif

#if ENABLE_MPU9250
    _mpuOk = _mpu.begin();
    Serial.println(_mpuOk ? "[SENSOR] MPU9250 ready" : "[SENSOR] MPU9250 NOT FOUND (check wiring/address)");
#endif

#if ENABLE_BME280
    _bmeOk = _bme.begin();
    Serial.println(_bmeOk ? "[SENSOR] BME280 ready" : "[SENSOR] BME280 NOT FOUND (check wiring/address)");
#endif

#if ENABLE_HCSR04
    _hcsr04.begin();
    Serial.println("[SENSOR] HC-SR04 initialized");
#endif

#if ENABLE_GAS || ENABLE_RAIN
    analogSensorsBegin(GAS_ADC_PIN, RAIN_ADC_PIN);
#endif
  }

  // Samples all enabled sensors and serializes them into `doc`.
  // Returns the number of sensors that produced a valid reading.
  int sample(JsonDocument &doc) {
    int okCount = 0;
    doc.clear();

    doc["nodeId"] = NODE_ID;
    doc["deviceId"] = DEVICE_ID;
    doc["source"] = "hardware";
    doc["signal"] = wifiSignalPercent();

    JsonObject sensors = doc["sensors"].to<JsonObject>();

#if ENABLE_MPU9250
    if (_mpuOk) {
      float ax, ay, az, gx, gy, gz;
      if (_mpu.read(ax, ay, az, gx, gy, gz)) {
        JsonObject imu = sensors["mpu9250"].to<JsonObject>();
        imu["x"] = round3(ax);
        imu["y"] = round3(ay);
        imu["z"] = round3(az);
        JsonObject accel = imu["accel"].to<JsonObject>();
        accel["x"] = round3(ax);
        accel["y"] = round3(ay);
        accel["z"] = round3(az);
        JsonObject gyro = imu["gyro"].to<JsonObject>();
        gyro["x"] = round3(gx);
        gyro["y"] = round3(gy);
        gyro["z"] = round3(gz);
        okCount++;
      }
    }
#endif

#if ENABLE_BME280
    if (_bmeOk) {
      float t, h, p;
      if (_bme.read(t, h, p)) {
        sensors["temperature"] = round2(t);
        sensors["humidity"] = round2(h);
        sensors["pressure"] = round2(p);
        okCount++;
      }
    }
#endif

#if ENABLE_HCSR04
    {
      float d = _hcsr04.readDistanceCm();
      if (!isnan(d)) {
        JsonObject hc = sensors["hcSr04"].to<JsonObject>();
        hc["distance"] = round2(d);
        okCount++;
      }
    }
#endif

#if ENABLE_GAS
    sensors["gas"] = readGasAdc(GAS_ADC_PIN);
    okCount++;
#endif

#if ENABLE_RAIN
    sensors["rain"] = readRainAdc(RAIN_ADC_PIN);
    okCount++;
#endif

    return okCount;
  }

private:
#if ENABLE_MPU9250
  MPU9250 _mpu{MPU9250_ADDR};
  bool _mpuOk = false;
#endif
#if ENABLE_BME280
  BME280 _bme{BME280_ADDR};
  bool _bmeOk = false;
#endif
#if ENABLE_HCSR04
  HCSR04 _hcsr04{HCSR04_TRIG_PIN, HCSR04_ECHO_PIN};
#endif

  static float round2(float v) { return roundf(v * 100.0f) / 100.0f; }
  static float round3(float v) { return roundf(v * 1000.0f) / 1000.0f; }

  // Converts Wi-Fi RSSI (dBm, typically -30..-90) into an approximate
  // 0-100% signal figure — the same mapping the backend falls back to
  // (100 + rssi, clamped) if it ever receives a raw rssi field instead.
  static int wifiSignalPercent() {
    long rssi = WiFi.RSSI();
    long pct = 100 + rssi;
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    return (int)pct;
  }
};
