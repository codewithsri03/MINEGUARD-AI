#pragma once
#include <WebServer.h>
#include <ArduinoJson.h>
#include "config.h"
#include "Telemetry.h"

/*
 * Mode A — the ESP32 runs a small HTTP server and the MineGuard
 * backend polls it. This matches server/services/deviceService.js
 * probeEsp32(): the backend tries GET /api/telemetry first, then
 * falls back to GET /status.
 *
 * This is the mode used when the operator clicks "Connect ESP32" in
 * the dashboard and types this device's local IP address.
 */
class ModeALocalServer {
public:
  explicit ModeALocalServer(TelemetryHub &hub) : _hub(hub), _server(LOCAL_SERVER_PORT) {}

  void begin() {
    _server.on("/api/telemetry", HTTP_GET, [this]() { handleTelemetry(); });
    _server.on("/status", HTTP_GET, [this]() { handleStatus(); });
    _server.onNotFound([this]() {
      _server.send(404, "application/json", "{\"error\":\"not found\"}");
    });
    _server.begin();
    Serial.printf("[MODE A] HTTP server listening on port %d\n", LOCAL_SERVER_PORT);
    Serial.println("[MODE A] Enter this device's IP address in the dashboard's");
    Serial.println("[MODE A] \"Connect ESP32\" dialog to start streaming.");
  }

  // Call every loop() iteration — non-blocking.
  void handleClient() { _server.handleClient(); }

private:
  TelemetryHub &_hub;
  WebServer _server;

  void handleTelemetry() {
    JsonDocument doc;
    _hub.sample(doc);
    // No "timestamp" field is set here on purpose: without NTP sync (see
    // README "Optional: accurate timestamps") the ESP32 has no reliable
    // wall-clock. Omitting the field lets the backend fall back to its
    // own receivedAt server time, which is always correct — sending a
    // wrong/epoch timestamp would be worse than sending none.

    String out;
    serializeJson(doc, out);
    _server.send(200, "application/json", out);
  }

  void handleStatus() {
    JsonDocument doc;
    doc["status"] = "ok";
    doc["deviceId"] = DEVICE_ID;
    doc["nodeId"] = NODE_ID;
    String out;
    serializeJson(doc, out);
    _server.send(200, "application/json", out);
  }
};
