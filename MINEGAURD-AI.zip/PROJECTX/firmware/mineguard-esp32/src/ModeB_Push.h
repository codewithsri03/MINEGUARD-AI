#pragma once
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "config.h"
#include "Telemetry.h"

/*
 * Mode B — the ESP32 actively POSTs telemetry to a known MineGuard
 * backend URL on a fixed interval, matching:
 *   POST http://<MINEGUARD_BACKEND_IP>:<port>/api/telemetry
 * documented in docs/hardware-integration.md, section 4 "Mode B".
 *
 * Use this when the backend cannot reach this ESP32 directly (e.g.
 * different Wi-Fi segment / behind NAT), so the ESP32 must be the one
 * to initiate the connection.
 */
class ModeBPush {
public:
  explicit ModeBPush(TelemetryHub &hub) : _hub(hub) {}

  void begin() {
    _url = String("http://") + BACKEND_HOST + ":" + String(BACKEND_PORT) + "/api/telemetry";
    Serial.printf("[MODE B] Will push telemetry to %s every %dms\n", _url.c_str(), PUSH_INTERVAL_MS);
  }

  // Call every loop() iteration — internally rate-limited to
  // PUSH_INTERVAL_MS, non-blocking between sends.
  void tick() {
    unsigned long now = millis();
    if (now - _lastSend < PUSH_INTERVAL_MS) return;
    _lastSend = now;
    sendOnce();
  }

private:
  TelemetryHub &_hub;
  String _url;
  unsigned long _lastSend = 0;

  void sendOnce() {
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("[MODE B] Skipped push: Wi-Fi not connected");
      return;
    }

    JsonDocument doc;
    int okCount = _hub.sample(doc);
    if (okCount == 0) {
      Serial.println("[MODE B] Skipped push: no sensors returned a valid reading");
      return;
    }

    String payload;
    serializeJson(doc, payload);

    HTTPClient http;
    http.begin(_url);
    http.addHeader("Content-Type", "application/json");
    http.setTimeout(3000);

    int code = http.POST(payload);
    if (code > 0) {
      Serial.printf("[MODE B] POST %s -> HTTP %d\n", _url.c_str(), code);
    } else {
      Serial.printf("[MODE B] POST failed: %s\n", http.errorToString(code).c_str());
    }
    http.end();
  }
};
