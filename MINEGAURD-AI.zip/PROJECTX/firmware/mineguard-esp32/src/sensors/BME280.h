#pragma once
#include <Arduino.h>

/*
 * Minimal register-level driver for the Bosch BME280 temperature /
 * humidity / pressure sensor, using the manufacturer's standard
 * compensation formulas (32-bit integer math, as specified in the
 * Bosch datasheet). No external library dependency.
 */
class BME280 {
public:
  explicit BME280(uint8_t address = 0x76) : _addr(address) {}

  bool begin();
  bool read(float &temperatureC, float &humidityPct, float &pressureHpa);

private:
  uint8_t _addr;
  bool _ok = false;
  int32_t _tFine = 0;

  // Calibration coefficients (read from sensor NVM at begin())
  uint16_t dig_T1; int16_t dig_T2, dig_T3;
  uint16_t dig_P1; int16_t dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;
  uint8_t  dig_H1; int16_t dig_H2; uint8_t dig_H3; int16_t dig_H4, dig_H5; int8_t dig_H6;

  void writeReg(uint8_t reg, uint8_t val);
  bool readBytes(uint8_t reg, uint8_t *buf, uint8_t len);
  void readCalibration();

  float compensateTemperature(int32_t adcT);
  float compensatePressure(int32_t adcP);
  float compensateHumidity(int32_t adcH);
};
