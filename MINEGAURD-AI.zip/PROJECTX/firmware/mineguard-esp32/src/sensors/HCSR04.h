#pragma once
#include <Arduino.h>

/*
 * HC-SR04 ultrasonic distance sensor — used here for roof-convergence
 * clearance measurement (distance from sensor to roof/rock face).
 */
class HCSR04 {
public:
  HCSR04(uint8_t trigPin, uint8_t echoPin) : _trig(trigPin), _echo(echoPin) {}

  void begin() {
    pinMode(_trig, OUTPUT);
    pinMode(_echo, INPUT);
    digitalWrite(_trig, LOW);
  }

  // Returns distance in centimetres, or NAN if no echo was received
  // (out of range / sensor disconnected / rock face beyond 400cm).
  float readDistanceCm() {
    digitalWrite(_trig, LOW);
    delayMicroseconds(2);
    digitalWrite(_trig, HIGH);
    delayMicroseconds(10);
    digitalWrite(_trig, LOW);

    // 30ms timeout ~= round trip for ~500cm, safely above the 400cm max range
    unsigned long durationUs = pulseIn(_echo, HIGH, 30000UL);
    if (durationUs == 0) return NAN;

    // Speed of sound ~343 m/s at 20C -> 0.0343 cm/us, round trip so /2
    float cm = (durationUs * 0.0343f) / 2.0f;
    if (cm < 2.0f || cm > 400.0f) return NAN; // outside HC-SR04's rated range
    return cm;
  }

private:
  uint8_t _trig, _echo;
};
