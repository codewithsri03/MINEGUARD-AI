#pragma once
#include <Arduino.h>

/*
 * Minimal register-level driver for the MPU9250 9-DOF IMU.
 * Talks directly to the accelerometer/gyroscope registers over I2C —
 * no external IMU library required, so there's nothing version-specific
 * to fight with in the Arduino Library Manager.
 *
 * Accelerometer is read in the default ±2g range (16384 LSB/g) and
 * gyroscope in the default ±250 dps range (131 LSB/(deg/s)), matching
 * the scaling MineGuard's backend risk engine expects (accel values
 * expressed as multiples of g, e.g. z ≈ 1.0 when level).
 */
class MPU9250 {
public:
  explicit MPU9250(uint8_t address = 0x68) : _addr(address) {}

  // Returns true if the sensor responded and was configured successfully.
  bool begin();

  // Reads the latest accel/gyro sample. Returns false on I2C failure
  // (caller should then omit the imu field from the outgoing packet).
  bool read(float &ax, float &ay, float &az,
            float &gx, float &gy, float &gz);

private:
  uint8_t _addr;
  bool _ok = false;

  void writeReg(uint8_t reg, uint8_t val);
  bool readBytes(uint8_t reg, uint8_t *buf, uint8_t len);
};
