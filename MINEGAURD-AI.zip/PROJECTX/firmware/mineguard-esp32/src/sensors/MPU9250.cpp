#include "MPU9250.h"
#include <Wire.h>

// MPU9250 / MPU6500-compatible register map (subset we need)
static const uint8_t REG_PWR_MGMT_1   = 0x6B;
static const uint8_t REG_SMPLRT_DIV   = 0x19;
static const uint8_t REG_CONFIG       = 0x1A;
static const uint8_t REG_GYRO_CONFIG  = 0x1B;
static const uint8_t REG_ACCEL_CONFIG = 0x1C;
static const uint8_t REG_WHO_AM_I     = 0x75;
static const uint8_t REG_ACCEL_XOUT_H = 0x3B; // accel(6) + temp(2) + gyro(6) read as one burst

void MPU9250::writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(_addr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool MPU9250::readBytes(uint8_t reg, uint8_t *buf, uint8_t len) {
  Wire.beginTransmission(_addr);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;

  uint8_t got = Wire.requestFrom((int)_addr, (int)len, (int)true);
  if (got != len) return false;

  for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
  return true;
}

bool MPU9250::begin() {
  uint8_t who = 0;
  if (!readBytes(REG_WHO_AM_I, &who, 1)) {
    _ok = false;
    return false;
  }
  // MPU9250 -> 0x71, MPU6500 -> 0x70, MPU9255 -> 0x73. Accept any known ID.
  if (who != 0x71 && who != 0x70 && who != 0x73) {
    _ok = false;
    return false;
  }

  writeReg(REG_PWR_MGMT_1, 0x00);     // wake from sleep, internal 8MHz oscillator
  delay(50);
  writeReg(REG_SMPLRT_DIV, 0x04);     // sample rate divider
  writeReg(REG_CONFIG, 0x03);         // DLPF ~44Hz, reduces vibration/aliasing noise
  writeReg(REG_GYRO_CONFIG, 0x00);    // ±250 dps
  writeReg(REG_ACCEL_CONFIG, 0x00);   // ±2g

  _ok = true;
  return true;
}

bool MPU9250::read(float &ax, float &ay, float &az,
                    float &gx, float &gy, float &gz) {
  if (!_ok) return false;

  uint8_t raw[14];
  if (!readBytes(REG_ACCEL_XOUT_H, raw, 14)) return false;

  int16_t rawAx = (raw[0] << 8) | raw[1];
  int16_t rawAy = (raw[2] << 8) | raw[3];
  int16_t rawAz = (raw[4] << 8) | raw[5];
  // raw[6],raw[7] = internal temperature — unused, ambient temp comes from BME280
  int16_t rawGx = (raw[8] << 8) | raw[9];
  int16_t rawGy = (raw[10] << 8) | raw[11];
  int16_t rawGz = (raw[12] << 8) | raw[13];

  const float ACCEL_SCALE = 16384.0f; // LSB/g @ ±2g
  const float GYRO_SCALE  = 131.0f;   // LSB/(deg/s) @ ±250dps

  ax = rawAx / ACCEL_SCALE;
  ay = rawAy / ACCEL_SCALE;
  az = rawAz / ACCEL_SCALE;
  gx = rawGx / GYRO_SCALE;
  gy = rawGy / GYRO_SCALE;
  gz = rawGz / GYRO_SCALE;

  return true;
}
