#include "BME280.h"
#include <Wire.h>

static const uint8_t REG_CHIP_ID   = 0xD0;
static const uint8_t REG_RESET     = 0xE0;
static const uint8_t REG_CTRL_HUM  = 0xF2;
static const uint8_t REG_STATUS    = 0xF3;
static const uint8_t REG_CTRL_MEAS = 0xF4;
static const uint8_t REG_CONFIG    = 0xF5;
static const uint8_t REG_PRESS_MSB = 0xF7; // press(3) + temp(3) + hum(2) burst read
static const uint8_t REG_CALIB00   = 0x88; // T/P calibration block, 26 bytes
static const uint8_t REG_CALIB_H1  = 0xA1; // dig_H1
static const uint8_t REG_CALIB_H2  = 0xE1; // dig_H2..dig_H6 block, 7 bytes

void BME280::writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(_addr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool BME280::readBytes(uint8_t reg, uint8_t *buf, uint8_t len) {
  Wire.beginTransmission(_addr);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;

  uint8_t got = Wire.requestFrom((int)_addr, (int)len, (int)true);
  if (got != len) return false;

  for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
  return true;
}

void BME280::readCalibration() {
  uint8_t c[24]; // dig_T1..dig_P9, 12 x 16-bit values, registers 0x88-0x9F
  readBytes(REG_CALIB00, c, 24);

  dig_T1 = (uint16_t)(c[1] << 8 | c[0]);
  dig_T2 = (int16_t)(c[3] << 8 | c[2]);
  dig_T3 = (int16_t)(c[5] << 8 | c[4]);

  dig_P1 = (uint16_t)(c[7] << 8 | c[6]);
  dig_P2 = (int16_t)(c[9] << 8 | c[8]);
  dig_P3 = (int16_t)(c[11] << 8 | c[10]);
  dig_P4 = (int16_t)(c[13] << 8 | c[12]);
  dig_P5 = (int16_t)(c[15] << 8 | c[14]);
  dig_P6 = (int16_t)(c[17] << 8 | c[16]);
  dig_P7 = (int16_t)(c[19] << 8 | c[18]);
  dig_P8 = (int16_t)(c[21] << 8 | c[20]);
  dig_P9 = (int16_t)(c[23] << 8 | c[22]);

  uint8_t h1;
  readBytes(REG_CALIB_H1, &h1, 1);
  dig_H1 = h1;

  uint8_t h[7];
  readBytes(REG_CALIB_H2, h, 7);
  dig_H2 = (int16_t)(h[1] << 8 | h[0]);
  dig_H3 = h[2];
  dig_H4 = (int16_t)((h[3] << 4) | (h[4] & 0x0F));
  dig_H5 = (int16_t)((h[5] << 4) | (h[4] >> 4));
  dig_H6 = (int8_t)h[6];
}

bool BME280::begin() {
  uint8_t chipId = 0;
  if (!readBytes(REG_CHIP_ID, &chipId, 1)) {
    _ok = false;
    return false;
  }
  // 0x60 = BME280. (0x58 = BMP280, no humidity — still accepted here so a
  // BMP280-only board degrades gracefully to temp+pressure only.)
  if (chipId != 0x60 && chipId != 0x58) {
    _ok = false;
    return false;
  }

  writeReg(REG_RESET, 0xB6);
  delay(10);

  readCalibration();

  writeReg(REG_CTRL_HUM, 0x01);           // humidity oversampling x1
  writeReg(REG_CTRL_MEAS, 0x27);          // temp x1, pressure x1, normal mode
  writeReg(REG_CONFIG, 0xA0);             // standby 1000ms, filter off

  _ok = true;
  return true;
}

float BME280::compensateTemperature(int32_t adcT) {
  int32_t var1 = ((((adcT >> 3) - ((int32_t)dig_T1 << 1))) * ((int32_t)dig_T2)) >> 11;
  int32_t var2 = (((((adcT >> 4) - ((int32_t)dig_T1)) * ((adcT >> 4) - ((int32_t)dig_T1))) >> 12) *
                  ((int32_t)dig_T3)) >> 14;
  _tFine = var1 + var2;
  float t = (_tFine * 5 + 128) >> 8;
  return t / 100.0f;
}

float BME280::compensatePressure(int32_t adcP) {
  int64_t var1, var2, p;
  var1 = ((int64_t)_tFine) - 128000;
  var2 = var1 * var1 * (int64_t)dig_P6;
  var2 = var2 + ((var1 * (int64_t)dig_P5) << 17);
  var2 = var2 + (((int64_t)dig_P4) << 35);
  var1 = ((var1 * var1 * (int64_t)dig_P3) >> 8) + ((var1 * (int64_t)dig_P2) << 12);
  var1 = (((((int64_t)1) << 47) + var1)) * ((int64_t)dig_P1) >> 33;
  if (var1 == 0) return 0; // avoid divide-by-zero
  p = 1048576 - adcP;
  p = (((p << 31) - var2) * 3125) / var1;
  var1 = (((int64_t)dig_P9) * (p >> 13) * (p >> 13)) >> 25;
  var2 = (((int64_t)dig_P8) * p) >> 19;
  p = ((p + var1 + var2) >> 8) + (((int64_t)dig_P7) << 4);
  return (float)p / 256.0f / 100.0f; // Pa -> hPa
}

float BME280::compensateHumidity(int32_t adcH) {
  int32_t v = (_tFine - ((int32_t)76800));
  v = (((((adcH << 14) - (((int32_t)dig_H4) << 20) - (((int32_t)dig_H5) * v)) +
         ((int32_t)16384)) >> 15) *
       (((((((v * ((int32_t)dig_H6)) >> 10) *
            (((v * ((int32_t)dig_H3)) >> 11) + ((int32_t)32768))) >> 10) +
          ((int32_t)2097152)) *
             ((int32_t)dig_H2) + 8192) >> 14));
  v = (v - (((((v >> 15) * (v >> 15)) >> 7) * ((int32_t)dig_H1)) >> 4));
  v = (v < 0) ? 0 : v;
  v = (v > 419430400) ? 419430400 : v;
  return (v >> 12) / 1024.0f;
}

bool BME280::read(float &temperatureC, float &humidityPct, float &pressureHpa) {
  if (!_ok) return false;

  uint8_t d[8];
  if (!readBytes(REG_PRESS_MSB, d, 8)) return false;

  int32_t adcP = ((int32_t)d[0] << 12) | ((int32_t)d[1] << 4) | (d[2] >> 4);
  int32_t adcT = ((int32_t)d[3] << 12) | ((int32_t)d[4] << 4) | (d[5] >> 4);
  int32_t adcH = ((int32_t)d[6] << 8) | d[7];

  temperatureC = compensateTemperature(adcT);
  pressureHpa  = compensatePressure(adcP);
  humidityPct  = compensateHumidity(adcH);

  return true;
}
