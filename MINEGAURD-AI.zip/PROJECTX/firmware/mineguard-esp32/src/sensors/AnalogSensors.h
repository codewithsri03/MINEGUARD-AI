#pragma once
#include <Arduino.h>

/*
 * MQ-series gas sensor and rain/water-ingress sensor — both are simple
 * analog voltage-divider sensors read directly off the ESP32's 12-bit
 * ADC (0-4095), matching the raw ADC contract in
 * docs/hardware-integration.md (gasAdc / rainAdc fields — the backend
 * applies its own warning/critical thresholds to these raw values, so
 * no on-device calibration/scaling is required here).
 */

inline void analogSensorsBegin(uint8_t gasPin, uint8_t rainPin) {
  analogReadResolution(12);        // 0-4095
  analogSetPinAttenuation(gasPin, ADC_11db);   // full 0-3.3V range
  analogSetPinAttenuation(rainPin, ADC_11db);
}

inline int readGasAdc(uint8_t pin) {
  return analogRead(pin);
}

inline int readRainAdc(uint8_t pin) {
  return analogRead(pin);
}
