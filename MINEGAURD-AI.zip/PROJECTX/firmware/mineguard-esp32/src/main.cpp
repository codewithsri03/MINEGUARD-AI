/*
 * MineGuard AI — ESP32 Sensor Node Firmware
 * ==========================================
 * Reads MPU9250 (IMU), BME280 (temp/humidity/pressure), HC-SR04
 * (roof-convergence distance), an MQ gas sensor, and a rain/water
 * sensor, then delivers readings to the MineGuard backend using the
 * exact JSON contract in docs/hardware-integration.md.
 *
 * Edit src/config.h before flashing: Wi-Fi credentials, node ID,
 * pin mapping, and which communication mode to use.
 *
 * See README.md for wiring, library installation, and setup.
 */
#include <Arduino.h>
#include <WiFi.h>
#include "config.h"
#include "Telemetry.h"

#if COMM_MODE == MODE_A_LOCAL_SERVER
  #include "ModeA_LocalServer.h"
#else
  #include "ModeB_Push.h"
#endif

TelemetryHub telemetry;

#if COMM_MODE == MODE_A_LOCAL_SERVER
  ModeALocalServer modeA(telemetry);
#else
  ModeBPush modeB(telemetry);
#endif

unsigned long lastBlink = 0;
bool ledState = false;

void connectWiFi() {
  Serial.printf("[WIFI] Connecting to \"%s\"", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < WIFI_CONNECT_TIMEOUT_MS) {
    delay(400);
    Serial.print(".");
  }
  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("[WIFI] Connected. IP address: %s\n", WiFi.localIP().toString().c_str());
    Serial.println("[WIFI] --------------------------------------------------------");
    Serial.println("[WIFI] Use this IP address in the MineGuard dashboard's");
    Serial.println("[WIFI] \"Connect ESP32\" dialog if you are using Mode A.");
    Serial.println("[WIFI] --------------------------------------------------------");
  } else {
    Serial.println("[WIFI] FAILED to connect within timeout. Check SSID/password in config.h.");
    Serial.println("[WIFI] The device will keep retrying in the background.");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n\n=== MineGuard AI — ESP32 Sensor Node ===");
  Serial.printf("Node ID: %s   Device ID: %s\n", NODE_ID, DEVICE_ID);

  connectWiFi();
  telemetry.begin();

#if COMM_MODE == MODE_A_LOCAL_SERVER
  modeA.begin();
#else
  modeB.begin();
#endif

  Serial.println("[BOOT] Setup complete. Streaming telemetry...\n");
}

void loop() {
  // Keep Wi-Fi alive; ESP32 auto-reconnect can drop under sustained
  // interference underground, so we force a manual reconnect attempt.
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastRetry = 0;
    if (millis() - lastRetry > 5000) {
      lastRetry = millis();
      Serial.println("[WIFI] Disconnected — retrying...");
      WiFi.reconnect();
    }
  }

#if COMM_MODE == MODE_A_LOCAL_SERVER
  modeA.handleClient();   // non-blocking, must be called frequently
#else
  modeB.tick();           // internally rate-limited to PUSH_INTERVAL_MS
#endif

  // Status LED: solid-ish heartbeat blink while Wi-Fi is connected,
  // fast blink while disconnected — a quick visual health check
  // underground without needing a serial monitor attached.
  unsigned long now = millis();
  unsigned long blinkInterval = (WiFi.status() == WL_CONNECTED) ? 1500 : 150;
  if (now - lastBlink >= blinkInterval) {
    lastBlink = now;
    ledState = !ledState;
    digitalWrite(STATUS_LED_PIN, ledState ? HIGH : LOW);
  }
}
