#pragma once

/*
 * MineGuard AI — ESP32 Sensor Node Configuration
 * ------------------------------------------------
 * Edit the values in this file for your deployment, then reflash.
 * Nothing outside this file needs to change for a normal deployment.
 */

// ---------------------------------------------------------------------
// 1. Wi-Fi Credentials
// ---------------------------------------------------------------------
#define WIFI_SSID        "YOUR_WIFI_SSID"
#define WIFI_PASSWORD    "YOUR_WIFI_PASSWORD"
#define WIFI_CONNECT_TIMEOUT_MS   15000

// ---------------------------------------------------------------------
// 2. Node & Device Identity
//    NODE_ID must match one of the backend's known nodes (N-01..N-08)
//    or any new ID — unknown nodes auto-register under "General Fleet".
// ---------------------------------------------------------------------
#define NODE_ID          "N-01"
#define DEVICE_ID         "ESP32-01"

// ---------------------------------------------------------------------
// 3. Communication Mode
//    MODE_A_LOCAL_SERVER : ESP32 runs a small HTTP server and waits for
//                           the MineGuard backend to poll
//                           GET /api/telemetry (operator enters this
//                           ESP32's IP in the dashboard "Connect ESP32"
//                           dialog). Works with zero backend config.
//
//    MODE_B_PUSH_TO_BACKEND : ESP32 actively POSTs telemetry to a known
//                              backend URL on an interval. Use this when
//                              the ESP32 cannot be reached from the
//                              backend network (e.g. it's on a separate
//                              mine Wi-Fi segment / cellular gateway).
//
//    Both modes speak the exact same JSON schema, so you can switch
//    between them without touching the backend.
// ---------------------------------------------------------------------
#define MODE_A_LOCAL_SERVER      1
#define MODE_B_PUSH_TO_BACKEND   2

#define COMM_MODE  MODE_A_LOCAL_SERVER

// Only used when COMM_MODE == MODE_B_PUSH_TO_BACKEND
#define BACKEND_HOST     "192.168.1.50"   // MineGuard backend machine IP
#define BACKEND_PORT     3001
#define PUSH_INTERVAL_MS 2000

// Local HTTP server port for Mode A (must match the port the operator
// enters in the dashboard "Connect ESP32" dialog — default 80).
#define LOCAL_SERVER_PORT 80

// ---------------------------------------------------------------------
// 4. Sensor Pin Mapping — matches docs/hardware-integration.md exactly
// ---------------------------------------------------------------------
// MPU9250 9-DOF IMU (I2C)
#define I2C_SDA_PIN       21
#define I2C_SCL_PIN       22
#define MPU9250_ADDR      0x68

// BME280 Temperature / Humidity / Pressure (shared I2C bus)
#define BME280_ADDR       0x76   // try 0x77 if your breakout uses that address

// HC-SR04 Ultrasonic roof-convergence distance sensor
#define HCSR04_TRIG_PIN   5
#define HCSR04_ECHO_PIN   18

// MQ Gas Sensor (analog, methane/CO/smoke proxy)
#define GAS_ADC_PIN       34   // ADC1_CH6

// Rain / Water-ingress sensor (analog)
#define RAIN_ADC_PIN      35   // ADC1_CH7

// ---------------------------------------------------------------------
// 5. Sampling & Status LED
// ---------------------------------------------------------------------
#define SAMPLE_INTERVAL_MS   2000   // how often sensors are re-read
#define STATUS_LED_PIN       2      // most ESP32 dev boards: onboard LED

// ---------------------------------------------------------------------
// 6. Optional: run without one or more physical sensors attached
//    Set to 0 to disable a sensor at compile time (its JSON field will
//    simply be omitted rather than sending a fabricated value — the
//    backend already treats missing fields as "no data", never as 0).
// ---------------------------------------------------------------------
#define ENABLE_MPU9250   1
#define ENABLE_BME280    1
#define ENABLE_HCSR04    1
#define ENABLE_GAS       1
#define ENABLE_RAIN      1
