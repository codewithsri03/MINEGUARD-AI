# MineGuard AI — ESP32 Sensor Node Firmware

Real firmware for the physical sensor node: reads the MPU9250, BME280,
HC‑SR04, MQ gas sensor and rain sensor, and sends readings to the
MineGuard backend using the exact JSON contract already documented in
`docs/hardware-integration.md` and implemented by
`server/services/sensorProcessing.js`. Nothing on the backend needs to
change — this firmware was written to match it exactly.

## 1. Wiring

| Sensor | Interface | ESP32 Pins |
|---|---|---|
| MPU9250 (IMU) | I2C | SDA → GPIO 21, SCL → GPIO 22 |
| BME280 (temp/humidity/pressure) | I2C (same bus) | SDA → GPIO 21, SCL → GPIO 22 |
| HC‑SR04 (distance) | Digital | TRIG → GPIO 5, ECHO → GPIO 18 (via voltage divider — see note below) |
| MQ Gas sensor | Analog | AOUT → GPIO 34 |
| Rain / water sensor | Analog | AOUT → GPIO 35 |
| Status LED | Digital | GPIO 2 (most dev boards' onboard LED) |

All sensor VCC/GND go to the ESP32's 3.3V and GND **except** the
HC‑SR04, which is a 5V part:

> **HC‑SR04 is 5V logic.** Power it from 5V/VIN, but its ECHO pin
> outputs 5V — the ESP32's GPIOs are not 5V tolerant. Put a simple
> resistor divider (e.g. 1kΩ + 2kΩ) between ECHO and GPIO 18 to drop it
> to ~3.3V, or use a 5V‑tolerant level shifter. Skipping this can
> damage the GPIO pin.

If your BME280 breakout uses I2C address `0x77` instead of `0x76`,
change `BME280_ADDR` in `src/config.h`.

## 2. Install PlatformIO (recommended)

1. Install the [PlatformIO extension](https://platformio.org/) for VS Code.
2. Open this `mineguard-esp32/` folder in VS Code — PlatformIO will
   detect `platformio.ini` automatically.
3. Edit `src/config.h` (see step 3 below).
4. Connect the ESP32 via USB, then click **Upload** (or run `pio run -t upload`).
5. Open the Serial Monitor at **115200 baud** to watch boot logs, IP
   address, and live telemetry send status.

The only external library dependency is **ArduinoJson** (declared in
`platformio.ini` and installed automatically — no manual step needed).

### Using the plain Arduino IDE instead
1. Copy this whole `mineguard-esp32/` folder, then rename
   `src/main.cpp` to `mineguard-esp32.ino` and move it (together with
   every other file in `src/`) into a folder also named
   `mineguard-esp32` — the Arduino IDE requires the sketch's `.ino`
   file to share its parent folder's name, but happily compiles the
   `.h`/`.cpp` files alongside it as extra tabs.
2. In **Tools → Board**, install "esp32 by Espressif Systems" via
   Boards Manager if you haven't already, then select your ESP32 board.
3. In **Tools → Manage Libraries**, install **ArduinoJson** (by
   Benoit Blanchon, v7.x).
4. Edit `config.h`, then Upload as usual.

## 3. Configure `src/config.h`

At minimum, set:
```cpp
#define WIFI_SSID        "YOUR_WIFI_SSID"
#define WIFI_PASSWORD    "YOUR_WIFI_PASSWORD"
#define NODE_ID          "N-01"        // must match a node the dashboard expects,
                                        // or any new ID — unknown nodes auto-register
```

Then choose a communication mode:

- **Mode A — Local Server (default, zero backend config)**
  The ESP32 runs its own tiny web server. In the MineGuard dashboard,
  click **Connect ESP32** and type in the IP address printed on the
  ESP32's Serial Monitor after boot. The backend polls the ESP32 every
  2 seconds — this exactly matches `probeEsp32()` /
  `startDevicePolling()` in `server/services/deviceService.js`.

- **Mode B — Push to Backend**
  Set `COMM_MODE` to `MODE_B_PUSH_TO_BACKEND` and fill in
  `BACKEND_HOST` / `BACKEND_PORT` (the machine running
  `npm run server`). Use this if the backend can't reach the ESP32
  directly (separate Wi‑Fi segment, no port-forwarding, etc.) — the
  ESP32 pushes to `POST /api/telemetry` on its own schedule instead.

Both modes send **identical JSON** — you can switch between them at
any time without touching the backend or the dashboard.

## 4. What "ready" looks like on first boot

```
=== MineGuard AI — ESP32 Sensor Node ===
Node ID: N-01   Device ID: ESP32-01
[WIFI] Connecting to "YourNetwork".....
[WIFI] Connected. IP address: 192.168.1.114
[SENSOR] MPU9250 ready
[SENSOR] BME280 ready
[SENSOR] HC-SR04 initialized
[MODE A] HTTP server listening on port 80
[BOOT] Setup complete. Streaming telemetry...
```

If a sensor prints "NOT FOUND", double-check its wiring and I2C
address — the firmware still boots and streams telemetry from every
other working sensor (a missing sensor's field is simply left out of
the JSON, never faked as zero).

## 5. Bench-test without a full mine deployment

You don't need real geology to prove the pipeline end-to-end:

1. Wire up on a breadboard at your desk.
2. Run the backend: `npm run server` (from the project root).
3. Flash this firmware and open its Serial Monitor for the IP address.
4. In the dashboard, **Connect ESP32** with that IP (Mode A) — or just
   wait a few seconds if using Mode B.
5. Tilt the MPU9250 by hand and wave something in front of the
   HC‑SR04 — you should see live values change on the **Monitoring**
   page and in the browser's WebSocket traffic immediately.
6. Breathe near the MQ gas sensor or dampen the rain sensor to trigger
   a **WARNING/CRITICAL** alert and confirm it appears on the
   **Alerts** page.

This is genuinely "real hardware test" coverage — it exercises every
line from sensor read → JSON → ingestion → risk engine → alert →
WebSocket → UI — the only thing a full underground trial adds on top
is confirming the enclosure/cabling survives the actual site.

## 6. Optional: accurate timestamps

The ESP32 has no battery-backed real-time clock, so this firmware
intentionally omits the `timestamp` field — the backend already
timestamps every packet on arrival (`receivedAt`), which is accurate
and requires nothing extra from the device. If you want the device's
own clock for offline logging, sync NTP in `setup()` with
`configTime()` and add a formatted `timestamp` field in
`Telemetry.h` — the backend already supports it should you choose to send one.
