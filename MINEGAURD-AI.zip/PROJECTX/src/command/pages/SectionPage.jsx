import React, { useState } from 'react';
import { CommandLayout } from '../components/CommandLayout';
import { SectionView } from '../viz/SectionView';
import { useSim, ZONES_METADATA } from '../sim/engine';
import { useRouter } from '../../router/Router';

/**
 * MineGuard AI — Underground Digital Twin Page
 * Clean, operator-friendly spatial representation of the subterranean mine.
 *
 * Layout:
 * ┌─────────────┬─────────────────────────────────────┬─────────────┐
 * │ MINE LEVELS │        DIGITAL TWIN HERO            │ SELECTED    │
 * │  Surface    │  (Underground structural section,   │ NODE        │
 * │  Level 1-4  │   sensor nodes, risk halos, pan/zoom)│ Metrics &   │
 * │             │                                     │ Actions     │
 * └─────────────┴─────────────────────────────────────┴─────────────┘
 */
export function SectionPage() {
  const {
    nodes,
    selectedNodeId,
    setSelectedNode,
    gatewayState,
    backendConnected,
    mineRisk
  } = useSim();

  const { navigate } = useRouter();
  const [selectedLevel, setSelectedLevel] = useState('all');

  // Active selected node & zone lookup
  const activeNode = nodes[selectedNodeId] || nodes['N-01'] || Object.values(nodes)[0];
  const zoneMeta = ZONES_METADATA.find((z) => z.id === activeNode?.zoneId);

  const isCrit = activeNode?.status === 'critical' || activeNode?.status === 'CRITICAL';
  const isWarn = (activeNode?.status === 'warning' || activeNode?.status === 'WARNING') && !isCrit;
  const isStale = (activeNode?.status === 'stale' || activeNode?.status === 'STALE') && !isCrit && !isWarn;
  const isOffline = !activeNode?.isOnline && activeNode?.status !== 'ONLINE' && !isCrit && !isWarn && !isStale;

  const statusLabel = isCrit ? 'CRITICAL' : isWarn ? 'WARNING' : isStale ? 'STALE' : isOffline ? 'OFFLINE' : 'NORMAL';
  const statusColor = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : isStale ? '#FF8800' : isOffline ? '#717888' : '#00D6A3';

  // Strata risk & health values
  const strataRisk = activeNode?.strataRisk != null ? activeNode.strataRisk : (activeNode?.isOnline ? 18 : (mineRisk || 0));
  const strataRiskColor = strataRisk >= 75 ? '#FF4D4D' : strataRisk >= 40 ? '#FFB020' : '#00D6A3';

  const sensorHealth = activeNode?.sensorHealth != null ? activeNode.sensorHealth : (activeNode?.battery != null ? activeNode.battery : (isOffline ? 0 : 94));
  const sensorHealthColor = sensorHealth >= 85 ? '#00D6A3' : sensorHealth >= 70 ? '#FFB020' : '#FF4D4D';

  const displacementVal = activeNode?.displacement != null
    ? activeNode.displacement.toFixed(1)
    : activeNode?.distance != null
    ? (activeNode.distance * 10).toFixed(1)
    : 'N/A';

  const vibrationVal = activeNode?.vibration != null
    ? activeNode.vibration.toFixed(2)
    : activeNode?.imuMotion != null
    ? activeNode.imuMotion.toFixed(2)
    : 'N/A';

  // Mine Levels metadata list - dynamically compute status for each level
  const getLevelStatus = (lvlId) => {
    let levelNodes = [];
    if (lvlId === 'all') levelNodes = Object.values(nodes);
    else if (lvlId === 'surface') levelNodes = [];
    else if (lvlId === 'level-1') levelNodes = [nodes['N-01'], nodes['N-02']].filter(Boolean);
    else if (lvlId === 'level-2') levelNodes = [nodes['N-03'], nodes['N-04']].filter(Boolean);
    else if (lvlId === 'level-3') levelNodes = [nodes['N-05'], nodes['N-08']].filter(Boolean);
    else if (lvlId === 'level-4') levelNodes = [nodes['N-06'], nodes['N-07']].filter(Boolean);

    const hasCrit = levelNodes.some((n) => n.status === 'critical' || n.status === 'CRITICAL');
    if (hasCrit) return 'critical';
    const hasWarn = levelNodes.some((n) => n.status === 'warning' || n.status === 'WARNING');
    if (hasWarn) return 'warning';
    return 'nominal';
  };

  const mineLevels = [
    { id: 'all', name: 'ALL LEVELS', depth: '0 → −500 m', status: getLevelStatus('all') },
    { id: 'surface', name: 'SURFACE', depth: '0 m', status: 'nominal' },
    { id: 'level-1', name: 'LEVEL 1', depth: '−100 m', status: getLevelStatus('level-1') },
    { id: 'level-2', name: 'LEVEL 2', depth: '−200 m', status: getLevelStatus('level-2') },
    { id: 'level-3', name: 'LEVEL 3', depth: '−300 m', status: getLevelStatus('level-3') },
    { id: 'level-4', name: 'LEVEL 4', depth: '−400 m', status: getLevelStatus('level-4') }
  ];

  return (
    <CommandLayout>
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '18px 24px 14px',
          display: 'flex',
          flexDirection: 'column',
          gap: '14px',
          boxSizing: 'border-box'
        }}
      >
        <style>{`
          @media (max-width: 1100px) {
            .digital-twin-grid {
              grid-template-columns: 1fr !important;
            }
            .dt-levels-container {
              flex-direction: row !important;
              overflow-x: auto;
              width: 100% !important;
            }
            .dt-inspector-container {
              width: 100% !important;
            }
          }
          @keyframes dtLivePulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.4; transform: scale(0.92); }
          }
        `}</style>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 1. PAGE HEADER (Requirement 2)                             */}
        {/* ════════════════════════════════════════════════════════════ */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '12px'
          }}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: '#00D9FF',
                  boxShadow: '0 0 8px #00D9FF'
                }}
              />
              <span
                className="t-micro"
                style={{
                  color: '#00D9FF',
                  letterSpacing: '0.12em',
                  fontSize: '0.625rem',
                  fontWeight: 600
                }}
              >
                03 — DIGITAL TWIN
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '14px', flexWrap: 'wrap' }}>
              <h1
                style={{
                  margin: 0,
                  fontFamily: 'var(--font-ui)',
                  fontSize: '1.6rem',
                  fontWeight: 600,
                  letterSpacing: '-0.01em',
                  color: '#FFFFFF',
                  lineHeight: 1.15
                }}
              >
                DIGITAL TWIN
              </h1>
              <span
                style={{
                  fontFamily: 'var(--font-ui)',
                  fontSize: '0.8125rem',
                  color: 'var(--dust)',
                  letterSpacing: '0.01em'
                }}
              >
                Interactive underground structural view
              </span>
            </div>
          </div>

          {/* Right Status Indicator: MINE ONLINE / STANDBY · X / Y NODES */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              backgroundColor: 'rgba(7, 9, 13, 0.75)',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              padding: '6px 14px',
              borderRadius: '4px'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: !backendConnected ? '#FF4D4D' : (gatewayState?.connected || gatewayState?.nodesOnline > 0) ? '#00D6A3' : '#00D9FF',
                  boxShadow: !backendConnected ? '0 0 6px #FF4D4D' : (gatewayState?.connected || gatewayState?.nodesOnline > 0) ? '0 0 6px #00D6A3' : '0 0 6px #00D9FF',
                  animation: 'dtLivePulse 2s ease-in-out infinite'
                }}
              />
              <span
                className="t-micro"
                style={{
                  color: !backendConnected ? '#FF4D4D' : (gatewayState?.connected || gatewayState?.nodesOnline > 0) ? '#00D6A3' : '#00D9FF',
                  fontSize: '0.6875rem',
                  fontWeight: 600,
                  letterSpacing: '0.06em'
                }}
              >
                {!backendConnected ? 'BACKEND OFFLINE' : (gatewayState?.connected || gatewayState?.nodesOnline > 0) ? 'MINE ONLINE' : 'MINE STANDBY'}
              </span>
            </div>
            <span style={{ color: 'rgba(255, 255, 255, 0.15)' }}>|</span>
            <span
              className="t-mono"
              style={{
                color: '#FFFFFF',
                fontSize: '0.75rem',
                fontWeight: 600,
                letterSpacing: '0.04em'
              }}
            >
              {gatewayState?.nodesOnline ?? 0} / {gatewayState?.totalNodes ?? 8} NODES
            </span>
          </div>
        </div>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 2. MAIN 3-COLUMN LAYOUT (Requirements 4, 3, 6, 15)          */}
        {/* ════════════════════════════════════════════════════════════ */}
        <div
          className="digital-twin-grid"
          style={{
            display: 'grid',
            gridTemplateColumns: '190px minmax(0, 1fr) 300px',
            gap: '14px',
            alignItems: 'start'
          }}
        >
          {/* ── LEFT COLUMN: MINE LEVELS PANEL (Requirement 4) ── */}
          <div
            className="panel dt-levels-container"
            style={{
              backgroundColor: 'rgba(7, 9, 13, 0.85)',
              border: '1px solid rgba(22, 136, 181, 0.22)',
              borderRadius: '6px',
              padding: '14px 12px',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px',
              boxSizing: 'border-box'
            }}
          >
            <span
              className="t-micro"
              style={{
                color: '#00D9FF',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em',
                marginBottom: '4px',
                paddingLeft: '4px'
              }}
            >
              MINE LEVELS
            </span>

            {mineLevels.map((lvl) => {
              const isActive = selectedLevel === lvl.id;
              const hasCrit = lvl.status === 'critical';

              return (
                <button
                  key={lvl.id}
                  onClick={() => setSelectedLevel(lvl.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 10px',
                    borderRadius: '4px',
                    border: isActive
                      ? '1px solid #00D9FF'
                      : '1px solid rgba(22, 136, 181, 0.18)',
                    backgroundColor: isActive
                      ? 'rgba(0, 217, 255, 0.12)'
                      : 'rgba(14, 18, 24, 0.75)',
                    color: isActive ? '#FFFFFF' : 'var(--dust)',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    boxShadow: isActive ? '0 0 10px rgba(0, 217, 255, 0.18)' : 'none',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.borderColor = 'rgba(0, 217, 255, 0.4)';
                      e.currentTarget.style.color = '#FFFFFF';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.borderColor = 'rgba(22, 136, 181, 0.18)';
                      e.currentTarget.style.color = 'var(--dust)';
                    }
                  }}
                  title={`Focus Digital Twin on ${lvl.name}`}
                >
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                    <span
                      style={{
                        fontFamily: 'var(--font-ui)',
                        fontSize: '0.75rem',
                        fontWeight: isActive ? 600 : 500,
                        letterSpacing: '0.04em'
                      }}
                    >
                      {lvl.name}
                    </span>
                    <span
                      className="t-mono"
                      style={{
                        fontSize: '0.625rem',
                        color: isActive ? '#00D9FF' : 'var(--ash)'
                      }}
                    >
                      {lvl.depth}
                    </span>
                  </div>

                  {/* Level status indicator dot */}
                  <span
                    style={{
                      width: '6px',
                      height: '6px',
                      borderRadius: '50%',
                      backgroundColor: hasCrit ? '#FF4D4D' : '#00D6A3',
                      boxShadow: `0 0 6px ${hasCrit ? '#FF4D4D' : '#00D6A3'}`
                    }}
                  />
                </button>
              );
            })}
          </div>

          {/* ── CENTER COLUMN: DIGITAL TWIN HERO VISUALIZATION (Requirement 3) ── */}
          <div
            className="panel"
            style={{
              backgroundColor: 'rgba(6, 8, 11, 0.9)',
              border: '1px solid rgba(22, 136, 181, 0.22)',
              borderRadius: '6px',
              padding: '12px',
              minHeight: '560px',
              display: 'flex',
              flexDirection: 'column',
              boxSizing: 'border-box',
              position: 'relative'
            }}
          >
            <SectionView
              selectedLevel={selectedLevel}
              onSelectNode={(nodeId) => setSelectedNode(nodeId)}
            />
          </div>

          {/* ── RIGHT COLUMN: SELECTED NODE INSPECTOR (Requirement 6, 7) ── */}
          <div
            className="panel dt-inspector-container"
            style={{
              backgroundColor: 'rgba(7, 9, 13, 0.85)',
              border: '1px solid rgba(22, 136, 181, 0.22)',
              borderRadius: '6px',
              padding: '16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              boxSizing: 'border-box'
            }}
          >
            <span
              className="t-micro"
              style={{
                color: '#00D9FF',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em'
              }}
            >
              NODE INSPECTOR
            </span>

            {!activeNode ? (
              <div
                style={{
                  padding: '24px 12px',
                  textAlign: 'center',
                  color: 'var(--dust)',
                  fontSize: '0.8125rem'
                }}
              >
                Select a sensor node to view its condition.
              </div>
            ) : (
              <>
                {/* Node Header: ID + Status */}
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    borderBottom: '1px solid rgba(22, 136, 181, 0.15)',
                    paddingBottom: '10px'
                  }}
                >
                  <span
                    style={{
                      fontFamily: 'var(--font-mono)',
                      fontSize: '1.25rem',
                      fontWeight: 700,
                      color: '#FFFFFF'
                    }}
                  >
                    {activeNode.id}
                  </span>

                  <span
                    style={{
                      color: statusColor,
                      backgroundColor: `${statusColor}18`,
                      border: `1px solid ${statusColor}40`,
                      borderRadius: '3px',
                      padding: '2px 8px',
                      fontSize: '0.6875rem',
                      fontWeight: 600,
                      fontFamily: 'var(--font-mono)',
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '5px'
                    }}
                  >
                    <span
                      style={{
                        width: '5px',
                        height: '5px',
                        borderRadius: '50%',
                        backgroundColor: statusColor,
                        boxShadow: `0 0 6px ${statusColor}`
                      }}
                    />
                    {statusLabel}
                  </span>
                </div>

                {/* Node Zone & Depth */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '0.8125rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--dust)' }}>Zone:</span>
                    <span style={{ color: 'var(--chalk)', fontWeight: 500 }}>
                      {zoneMeta?.shortName || 'Sub-Level 4'}
                    </span>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--dust)' }}>Depth:</span>
                    <span className="t-mono" style={{ color: 'var(--chalk)' }}>
                      {zoneMeta?.depth !== undefined ? `${zoneMeta.depth} m` : '-460 m'}
                    </span>
                  </div>
                </div>

                {/* Subheader: CURRENT READINGS */}
                <span
                  className="t-micro"
                  style={{
                    color: 'var(--dust)',
                    fontSize: '0.625rem',
                    fontWeight: 600,
                    letterSpacing: '0.08em',
                    marginTop: '2px'
                  }}
                >
                  CURRENT READINGS
                </span>

                {/* Four Prominent Metrics (Requirement 6: Displacement, Vibration, Strata Risk, Health) */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  {/* DISPLACEMENT */}
                  <div
                    style={{
                      backgroundColor: 'rgba(14, 18, 24, 0.75)',
                      border: '1px solid rgba(22, 136, 181, 0.18)',
                      borderRadius: '4px',
                      padding: '8px 10px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '2px'
                    }}
                  >
                    <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.5625rem' }}>
                      DISPLACEMENT
                    </span>
                    <span className="t-mono" style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#FFFFFF' }}>
                      {displacementVal !== 'N/A' ? `${displacementVal} mm` : 'N/A'}
                    </span>
                  </div>

                  {/* VIBRATION */}
                  <div
                    style={{
                      backgroundColor: 'rgba(14, 18, 24, 0.75)',
                      border: '1px solid rgba(22, 136, 181, 0.18)',
                      borderRadius: '4px',
                      padding: '8px 10px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '2px'
                    }}
                  >
                    <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.5625rem' }}>
                      VIBRATION
                    </span>
                    <span className="t-mono" style={{ fontSize: '0.9375rem', fontWeight: 600, color: '#FFFFFF' }}>
                      {vibrationVal !== 'N/A' ? `${vibrationVal} mm/s` : 'N/A'}
                    </span>
                  </div>

                  {/* STRATA RISK */}
                  <div
                    style={{
                      backgroundColor: 'rgba(14, 18, 24, 0.75)',
                      border: '1px solid rgba(22, 136, 181, 0.18)',
                      borderRadius: '4px',
                      padding: '8px 10px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '2px'
                    }}
                  >
                    <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.5625rem' }}>
                      STRATA RISK
                    </span>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: '3px' }}>
                      <span className="t-mono" style={{ fontSize: '0.9375rem', fontWeight: 600, color: strataRiskColor }}>
                        {strataRisk}
                      </span>
                      <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
                        / 100
                      </span>
                    </div>
                  </div>

                  {/* SENSOR HEALTH */}
                  <div
                    style={{
                      backgroundColor: 'rgba(14, 18, 24, 0.75)',
                      border: '1px solid rgba(22, 136, 181, 0.18)',
                      borderRadius: '4px',
                      padding: '8px 10px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '2px'
                    }}
                  >
                    <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.5625rem' }}>
                      SENSOR HEALTH
                    </span>
                    <span className="t-mono" style={{ fontSize: '0.9375rem', fontWeight: 600, color: sensorHealthColor }}>
                      {sensorHealth}%
                    </span>
                  </div>
                </div>

                {/* ── Action Buttons (Requirement 7) ── */}
                <div
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                    borderTop: '1px solid rgba(22, 136, 181, 0.15)',
                    paddingTop: '12px',
                    marginTop: '4px'
                  }}
                >
                  <button
                    onClick={() => navigate('/monitoring')}
                    className="cmd-btn"
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      fontFamily: 'var(--font-ui)',
                      letterSpacing: '0.06em',
                      background: 'rgba(0, 217, 255, 0.1)',
                      border: '1px solid rgba(0, 217, 255, 0.4)',
                      color: '#00D9FF',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      boxShadow: '0 0 10px rgba(0, 217, 255, 0.15)'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(0, 217, 255, 0.2)';
                      e.currentTarget.style.color = '#FFFFFF';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(0, 217, 255, 0.1)';
                      e.currentTarget.style.color = '#00D9FF';
                    }}
                    title="Open Live Oscilloscope Monitoring for this node"
                  >
                    VIEW LIVE MONITORING
                  </button>

                  <button
                    onClick={() => navigate('/risk')}
                    className="cmd-btn"
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      fontFamily: 'var(--font-ui)',
                      letterSpacing: '0.06em',
                      background: 'rgba(20, 23, 27, 0.8)',
                      border: '1px solid rgba(22, 136, 181, 0.3)',
                      color: 'var(--chalk)',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = '#00D9FF';
                      e.currentTarget.style.color = '#00D9FF';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'rgba(22, 136, 181, 0.3)';
                      e.currentTarget.style.color = 'var(--chalk)';
                    }}
                    title="Inspect Bayesian Risk Model for this zone"
                  >
                    VIEW RISK ANALYSIS
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </CommandLayout>
  );
}

export default SectionPage;
