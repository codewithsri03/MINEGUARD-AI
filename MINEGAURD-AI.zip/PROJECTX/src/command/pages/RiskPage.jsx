import React, { useState, useEffect } from 'react';
import { CommandLayout } from '../components/CommandLayout';
import { useSim } from '../sim/engine';

export function RiskPage() {
  const { mineRisk, mineRiskTrend, mineRiskStatus, nodes, zones } = useSim();
  const [animProgress, setAnimProgress] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setAnimProgress(1), 100);
    return () => clearTimeout(timer);
  }, []);

  const reportingNodes = Object.values(nodes).filter((n) => n.isOnline && (n.currentConvergence !== null || n.currentTilt !== null));

  // Dynamically assemble factors from reporting nodes evaluated by backend Risk Engine
  const dynamicFactors = [];
  reportingNodes.forEach((n) => {
    if (n.currentConvergence !== null) {
      const conv = n.currentConvergence;
      const isBreach = conv <= 15.0;
      const isWarn = conv <= 17.0;
      if (isBreach || isWarn) {
        dynamicFactors.push({
          label: `${n.id} Roof Convergence`,
          weight: 35,
          raw: `${conv.toFixed(1)} cm (${isBreach ? 'Crit ≤ 15.0' : 'Warn ≤ 17.0'})`,
          contribution: isBreach ? 35 : 20,
          color: isBreach ? '#FF4D4D' : '#FFB020',
          desc: `Roof closure detected on ${n.name || n.id}`
        });
      }
    }
    if (n.currentTilt !== null) {
      const tilt = n.currentTilt;
      const isBreach = tilt >= 3.0;
      const isWarn = tilt >= 2.0;
      if (isBreach || isWarn) {
        dynamicFactors.push({
          label: `${n.id} Angular Tilt`,
          weight: 25,
          raw: `${tilt.toFixed(2)}° (${isBreach ? 'Crit ≥ 3.0°' : 'Warn ≥ 2.0°'})`,
          contribution: isBreach ? 25 : 15,
          color: isBreach ? '#FF4D4D' : '#FFB020',
          desc: `Shear tilt angle threshold breach on ${n.id}`
        });
      }
    }
  });

  const factorItems = dynamicFactors.length > 0 ? dynamicFactors : [
    {
      label: 'Geotechnical Convergence Envelope',
      weight: 35,
      raw: reportingNodes.length > 0 ? 'Within safe limits' : 'Awaiting sensor data',
      contribution: 5,
      color: reportingNodes.length > 0 ? '#00D6A3' : 'var(--dust)',
      desc: 'HC-SR04 continuous strata displacement verification'
    },
    {
      label: 'Angular Shear Envelope',
      weight: 25,
      raw: reportingNodes.length > 0 ? 'Within safe limits' : 'Awaiting sensor data',
      contribution: 5,
      color: reportingNodes.length > 0 ? '#00D6A3' : 'var(--dust)',
      desc: 'MPU9250 orientation and motion verification'
    },
    {
      label: 'Fleet Sensor Correlation',
      weight: 20,
      raw: reportingNodes.length > 0 ? `${reportingNodes.length} reporting stations` : '0 stations',
      contribution: 4,
      color: '#00D9FF',
      desc: 'Cross-sensor spatial agreement'
    },
    {
      label: 'Environmental Hazard Baseline',
      weight: 20,
      raw: 'Nominal readings',
      contribution: 2,
      color: '#00D9FF',
      desc: 'Multi-gas and hydraulic drainage indicators'
    }
  ];

  // Per-zone risk indices derived from current fleet
  const zoneTrends = {
    z1: [20, 21, 22, 21, 23, 22, 22],
    z2: [40, 42, 45, 46, 48, 50, 52],
    z4: [16, 16, 17, 17, 18, 17, 18],
    z3: [55, 58, 62, 66, 70, 74, 78]
  };

  const renderMiniSparkline = (vals, strokeCol) => {
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const range = max - min || 1;
    const width = 120;
    const height = 28;

    const points = vals
      .map((v, idx) => {
        const x = (idx / (vals.length - 1)) * width;
        const y = height - 3 - ((v - min) / range) * (height - 6);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');

    return (
      <svg width={width} height={height} style={{ overflow: 'visible' }}>
        <polyline
          points={points}
          fill="none"
          stroke={strokeCol}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* End pulse marker */}
        {vals.length > 0 && (
          <circle
            cx={width}
            cy={height - 3 - ((vals[vals.length - 1] - min) / range) * (height - 6)}
            r="3"
            fill={strokeCol}
          />
        )}
      </svg>
    );
  };

  // Circular gauge calculations
  const gaugeRadius = 88;
  const circumference = 2 * Math.PI * gaugeRadius;
  const arcLength = circumference * 0.75; // 270 degree sweep
  const strokeDashoffset = arcLength * (1 - (mineRisk / 100) * animProgress);
  const gaugeColor = mineRisk >= 75 ? '#FF4D4D' : mineRisk >= 50 ? '#FFB020' : '#00D6A3';

  return (
    <CommandLayout>
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '20px 28px',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
          boxSizing: 'border-box'
        }}
      >
        {/* Page Header: Eyebrow + Title + Subtitle */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                backgroundColor: '#00D9FF',
                boxShadow: '0 0 8px #00D9FF'
              }}
            />
            <span
              className="t-micro"
              style={{
                color: '#00D9FF',
                letterSpacing: '0.12em',
                fontSize: '0.6875rem',
                fontWeight: 600
              }}
            >
              02 — RISK ANALYSIS
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'baseline', gap: '14px', flexWrap: 'wrap' }}>
            <h1
              style={{
                margin: 0,
                fontFamily: 'var(--font-ui)',
                fontSize: '1.65rem',
                fontWeight: 600,
                letterSpacing: '-0.01em',
                color: '#FFFFFF',
                lineHeight: 1.15
              }}
            >
              Risk Model Explainability
            </h1>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.8125rem',
                color: 'var(--dust)',
                letterSpacing: '0.01em'
              }}
            >
              Multi-variable Bayesian fusion decomposition & 6-hour forecast
            </span>
          </div>
        </div>

        {/* Top Area: Risk Intelligence Instrument (Left) + Factor Contribution Breakdown (Right) */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '360px minmax(0, 1fr)',
            gap: '16px',
            alignItems: 'stretch'
          }}
        >
          {/* Left: Circular Risk Instrument */}
          <div
            className="panel"
            style={{
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              alignItems: 'center',
              backgroundColor: 'rgba(7, 8, 11, 0.85)',
              border: '1px solid rgba(22, 136, 181, 0.22)',
              borderRadius: '6px'
            }}
          >
            <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span
                className="t-micro"
                style={{ color: 'var(--dust)', letterSpacing: '0.08em', fontSize: '0.6875rem' }}
              >
                CURRENT MINE-WIDE RISK
              </span>
              <span
                style={{
                  fontSize: '0.6875rem',
                  fontFamily: 'var(--font-mono)',
                  color: gaugeColor,
                  backgroundColor: `${gaugeColor}18`,
                  padding: '2px 7px',
                  borderRadius: '3px',
                  border: `1px solid ${gaugeColor}40`
                }}
              >
                {mineRiskStatus ? mineRiskStatus.toUpperCase() : (mineRisk >= 75 ? 'CRITICAL' : mineRisk >= 50 ? 'HIGH ADVISORY' : mineRisk > 0 ? 'NOMINAL' : 'STANDBY')}
              </span>
            </div>

            {/* SVG Circular Gauge */}
            <div style={{ position: 'relative', width: '220px', height: '200px', margin: '12px 0' }}>
              <svg width="220" height="200" viewBox="0 0 220 200">
                {/* Background Arc */}
                <circle
                  cx="110"
                  cy="110"
                  r={gaugeRadius}
                  fill="none"
                  stroke="rgba(255, 255, 255, 0.08)"
                  strokeWidth="8"
                  strokeDasharray={`${arcLength} ${circumference}`}
                  strokeLinecap="round"
                  transform="rotate(135 110 110)"
                />

                {/* Animated Value Arc */}
                <circle
                  cx="110"
                  cy="110"
                  r={gaugeRadius}
                  fill="none"
                  stroke={gaugeColor}
                  strokeWidth="8"
                  strokeDasharray={`${arcLength} ${circumference}`}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  transform="rotate(135 110 110)"
                  style={{
                    transition: 'stroke-dashoffset 1.2s cubic-bezier(0.16, 1, 0.3, 1)',
                    filter: `drop-shadow(0 0 8px ${gaugeColor}66)`
                  }}
                />

                {/* 100 Tick Marks */}
                {Array.from({ length: 41 }, (_, i) => {
                  const angle = 135 + (i / 40) * 270;
                  const rad = (angle * Math.PI) / 180;
                  const x1 = 110 + (gaugeRadius - 12) * Math.cos(rad);
                  const y1 = 110 + (gaugeRadius - 12) * Math.sin(rad);
                  const x2 = 110 + (gaugeRadius - 17) * Math.cos(rad);
                  const y2 = 110 + (gaugeRadius - 17) * Math.sin(rad);
                  const isMajor = i % 10 === 0;

                  return (
                    <line
                      key={i}
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke={isMajor ? 'rgba(255,255,255,0.4)' : 'rgba(255,255,255,0.12)'}
                      strokeWidth={isMajor ? 1.5 : 0.8}
                    />
                  );
                })}
              </svg>

              {/* Center Score Readout */}
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginTop: '10px'
                }}
              >
                <span
                  className="t-mono"
                  style={{
                    fontSize: '3.2rem',
                    fontWeight: 700,
                    color: '#FFFFFF',
                    lineHeight: 1,
                    letterSpacing: '-0.03em'
                  }}
                >
                  {mineRisk}
                </span>
                <span
                  style={{
                    fontSize: '0.6875rem',
                    fontFamily: 'var(--font-mono)',
                    color: 'var(--dust)',
                    letterSpacing: '0.08em',
                    marginTop: '2px'
                  }}
                >
                  RISK INDEX / 100
                </span>
              </div>
            </div>

            {/* Bottom Metadata Split */}
            <div
              style={{
                width: '100%',
                display: 'flex',
                justifyContent: 'space-between',
                borderTop: '1px solid rgba(22, 136, 181, 0.15)',
                paddingTop: '12px'
              }}
            >
              <div>
                <span className="t-micro" style={{ color: 'var(--dust)', display: 'block' }}>
                  Primary Driver:
                </span>
                <span
                  className="t-mono"
                  style={{
                    color: dynamicFactors.length > 0 ? dynamicFactors[0].color : (reportingNodes.length > 0 ? '#00D6A3' : 'var(--dust)'),
                    fontSize: '0.8125rem',
                    fontWeight: 600
                  }}
                >
                  {dynamicFactors.length > 0 ? dynamicFactors[0].label : (reportingNodes.length > 0 ? 'Fleet Stable' : 'Standby')}
                </span>
              </div>
              <div style={{ textAlign: 'right' }}>
                <span className="t-micro" style={{ color: 'var(--dust)', display: 'block' }}>
                  Projection:
                </span>
                <span
                  className="t-mono"
                  style={{ color: '#FFB020', fontSize: '0.8125rem', fontWeight: 600 }}
                >
                  {mineRiskTrend.toUpperCase()}
                </span>
              </div>
            </div>
          </div>

          {/* Right: Factor Contribution Breakdown */}
          <div
            className="panel"
            style={{
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              backgroundColor: 'rgba(7, 8, 11, 0.85)',
              border: '1px solid rgba(22, 136, 181, 0.22)',
              borderRadius: '6px'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span
                style={{
                  fontFamily: 'var(--font-ui)',
                  fontSize: '0.9375rem',
                  fontWeight: 600,
                  color: '#FFFFFF'
                }}
              >
                FACTOR CONTRIBUTION BREAKDOWN
              </span>
              <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
                Weights sum to 100% · Bayesian Decomposition
              </span>
            </div>

            {/* Factor Bar Stack */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '4px' }}>
              {factorItems.map((item, idx) => (
                <div key={idx} style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span
                        style={{
                          width: '6px',
                          height: '6px',
                          borderRadius: '50%',
                          backgroundColor: item.color
                        }}
                      />
                      <span style={{ fontSize: '0.8125rem', color: '#FFFFFF', fontWeight: 500 }}>
                        {item.label}
                      </span>
                      <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
                        ({item.weight}%)
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'baseline', gap: '10px' }}>
                      <span className="t-mono" style={{ fontSize: '0.75rem', color: 'var(--ash)' }}>
                        {item.raw}
                      </span>
                      <span
                        className="t-mono"
                        style={{ fontSize: '0.8125rem', fontWeight: 600, color: item.color }}
                      >
                        +{item.contribution}%
                      </span>
                    </div>
                  </div>

                  {/* Horizontal Bar Track */}
                  <div
                    style={{
                      height: '7px',
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      borderRadius: '3px',
                      overflow: 'hidden',
                      position: 'relative'
                    }}
                  >
                    <div
                      style={{
                        height: '100%',
                        width: `${item.contribution * 2.4 * animProgress}%`,
                        backgroundColor: item.color,
                        borderRadius: '3px',
                        transition: 'width 1s cubic-bezier(0.16, 1, 0.3, 1)',
                        boxShadow: `0 0 8px ${item.color}88`
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Middle Area: Per-Zone Comparison (4 Cards) */}
        <div
          className="panel"
          style={{
            padding: '18px 20px',
            backgroundColor: 'rgba(7, 8, 11, 0.85)',
            border: '1px solid rgba(22, 136, 181, 0.22)',
            borderRadius: '6px',
            display: 'flex',
            flexDirection: 'column',
            gap: '14px'
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.875rem',
                fontWeight: 600,
                letterSpacing: '0.04em',
                color: '#FFFFFF'
              }}
            >
              PER-ZONE COMPARISON (7-DAY STRUCTURAL RISK PROFILES)
            </span>
            <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
              Cross-Heading Telemetry Indices
            </span>
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
              gap: '12px'
            }}
          >
            {zones.map((zone) => {
              const isCrit = zone.status === 'critical';
              const isWarn = zone.status === 'warning';
              const statusCol = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : '#00D6A3';
              const trendData = zoneTrends[zone.id] || [20, 22, 21, 24];

              return (
                <div
                  key={zone.id}
                  style={{
                    backgroundColor: 'rgba(12, 14, 18, 0.7)',
                    border: `1px solid ${statusCol}40`,
                    borderRadius: '5px',
                    padding: '12px 14px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '10px'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <span
                        style={{
                          fontFamily: 'var(--font-ui)',
                          fontSize: '0.8125rem',
                          fontWeight: 600,
                          color: '#FFFFFF',
                          display: 'block'
                        }}
                      >
                        {zone.shortName}
                      </span>
                      <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
                        {zone.depth} m
                      </span>
                    </div>

                    <span
                      style={{
                        color: statusCol,
                        backgroundColor: `${statusCol}18`,
                        padding: '2px 6px',
                        borderRadius: '3px',
                        fontSize: '0.6875rem',
                        fontWeight: 600,
                        fontFamily: 'var(--font-mono)'
                      }}
                    >
                      {zone.status.toUpperCase()}
                    </span>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
                    <div>
                      <span className="t-micro" style={{ color: 'var(--dust)', display: 'block' }}>
                        Risk Index:
                      </span>
                      <span
                        className="t-mono"
                        style={{ fontSize: '1.25rem', fontWeight: 700, color: statusCol }}
                      >
                        {zone.baseRisk}
                        <span style={{ fontSize: '0.6875rem', color: 'var(--ash)', fontWeight: 400 }}>
                          /100
                        </span>
                      </span>
                    </div>

                    {renderMiniSparkline(trendData, statusCol)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Area: Model Forecast Trajectory (+6 Hours) */}
        <div
          className="panel"
          style={{
            padding: '20px',
            backgroundColor: 'rgba(7, 8, 11, 0.85)',
            border: '1px solid rgba(22, 136, 181, 0.22)',
            borderRadius: '6px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px'
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.875rem',
                fontWeight: 600,
                letterSpacing: '0.04em',
                color: '#FFFFFF'
              }}
            >
              MODEL FORECAST TRAJECTORY (+6 HOURS PROJECTION)
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ width: '12px', height: '2px', backgroundColor: '#00D9FF' }} />
                <span style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>Historical Trajectory</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ width: '12px', height: '2px', borderTop: '2px dashed #FFB020' }} />
                <span style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>Projected Mean</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ width: '12px', height: '8px', backgroundColor: 'rgba(255, 176, 32, 0.15)' }} />
                <span style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>±2σ Confidence Envelope</span>
              </div>
            </div>
          </div>

          {/* 2D SVG Forecast Chart */}
          <div style={{ position: 'relative', width: '100%', height: '170px', marginTop: '4px' }}>
            <svg width="100%" height="100%" viewBox="0 0 960 160" preserveAspectRatio="none">
              <defs>
                <linearGradient id="envelopeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#FFB020" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#FFB020" stopOpacity="0.02" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              <line x1="40" y1="20" x2="920" y2="20" stroke="rgba(255, 77, 77, 0.3)" strokeDasharray="4 4" />
              <text x="925" y="24" fill="#FF4D4D" fontSize="10" fontFamily="monospace">75 CRIT</text>

              <line x1="40" y1="65" x2="920" y2="65" stroke="rgba(255, 176, 32, 0.3)" strokeDasharray="4 4" />
              <text x="925" y="69" fill="#FFB020" fontSize="10" fontFamily="monospace">50 WARN</text>

              <line x1="40" y1="120" x2="920" y2="120" stroke="rgba(255, 255, 255, 0.06)" />

              {/* Vertical Time Division: T-0 Live line */}
              <line x1="420" y1="10" x2="420" y2="135" stroke="rgba(255, 255, 255, 0.25)" strokeDasharray="2 2" />
              <text x="420" y="152" fill="#00D9FF" fontSize="10" fontFamily="monospace" textAnchor="middle">
                T-0 (LIVE)
              </text>

              {/* Historical Curve (x: 40 to 420) */}
              <path
                d="M 40 100 Q 140 92 240 86 T 420 62"
                fill="none"
                stroke="#00D9FF"
                strokeWidth="2.4"
              />

              {/* Confidence Region Envelope (+2σ / -2σ) from x: 420 to 900 */}
              <path
                d="M 420 62 Q 540 45 680 32 T 900 16 L 900 55 Q 680 68 540 76 T 420 62 Z"
                fill="url(#envelopeGrad)"
              />

              {/* Projected Mean Curve (x: 420 to 900) */}
              <path
                d="M 420 62 Q 540 54 680 44 T 900 28"
                fill="none"
                stroke="#FFB020"
                strokeWidth="2.2"
                strokeDasharray="5 4"
              />

              {/* Live Point Marker at T-0 */}
              <circle cx="420" cy="62" r="5" fill="#FFB020" />
              <circle cx="420" cy="62" r="8" fill="none" stroke="#FFB020" strokeWidth="1.5" opacity="0.6" />

              {/* Timeline Axis Labels */}
              <text x="40" y="152" fill="var(--ash)" fontSize="10" fontFamily="monospace">T−60m</text>
              <text x="230" y="152" fill="var(--ash)" fontSize="10" fontFamily="monospace">T−30m</text>
              <text x="540" y="152" fill="var(--ash)" fontSize="10" fontFamily="monospace">T+2h</text>
              <text x="680" y="152" fill="var(--ash)" fontSize="10" fontFamily="monospace">T+4h</text>
              <text x="900" y="152" fill="var(--ash)" fontSize="10" fontFamily="monospace">T+6h</text>
            </svg>
          </div>

          {/* Forecast Summary Alert Bar */}
          <div
            style={{
              padding: '8px 12px',
              backgroundColor: 'rgba(255, 176, 32, 0.1)',
              border: '1px solid rgba(255, 176, 32, 0.3)',
              borderRadius: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ color: '#FFB020', fontSize: '0.8125rem' }}>⚠</span>
              <span style={{ fontSize: '0.75rem', color: '#FFFFFF' }}>
                Predicted Critical Threshold Breach (+75) in approximately <strong style={{ color: '#FFB020' }}>2h 45m</strong> unless active heading reinforcement is engaged in Zone 03.
              </span>
            </div>
            <span className="t-mono" style={{ fontSize: '0.6875rem', color: '#FFB020' }}>
              Bayesian Confidence: 89.4%
            </span>
          </div>
        </div>
      </div>
    </CommandLayout>
  );
}

export default RiskPage;
