import React, { useState, useMemo } from 'react';
import { CommandLayout } from '../components/CommandLayout';
import { useSim, ZONES_METADATA, NODES_METADATA } from '../sim/engine';
import {
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Clock,
  MapPin,
  Activity,
  Flame,
  Droplets,
  TrendingDown,
  TrendingUp,
  Users,
  Check,
  ChevronDown,
  ChevronUp,
  Radio,
  Search,
  SlidersHorizontal,
  Zap,
  UserCheck,
  BellRing,
  ShieldCheck,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

/**
 * MineGuard AI — High-End Safety Alert Dispatch & Lifecycle Audit
 *
 * Designed to feel calm, confident, and trustworthy at a glance —
 * like a well-designed consumer safety app, not a raw engineering dashboard.
 * Non-technical safety operators understand the situation and know what to do in seconds.
 */

// Helper: Translate raw alert codes and message into plain-language human statements
function getPlainLanguageAlert(alert, node) {
  const msg = (alert?.message || '').toLowerCase();
  const threshold = (alert?.threshold || '').toLowerCase();
  const type = (alert?.type || alert?.eventType || alert?.event || '').toLowerCase();
  const rawDist = node?.currentConvergence ?? (alert?.factors?.[0]?.parameter === 'distance' ? alert?.factors[0]?.value : null);
  const rawTilt = node?.currentTilt ?? (alert?.factors?.[0]?.parameter === 'tilt' ? alert?.factors[0]?.value : null);
  const rawGas = node?.gasAdc ?? (alert?.factors?.[0]?.parameter === 'gasAdc' ? alert?.factors[0]?.value : null);
  const rawRain = node?.rainAdc ?? (alert?.factors?.[0]?.parameter === 'rainAdc' ? alert?.factors[0]?.value : null);

  if (msg.includes('roof') || msg.includes('convergence') || msg.includes('clearance') || threshold.includes('roof') || threshold.includes('convergence') || type.includes('roof') || type.includes('convergence')) {
    const currCm = rawDist !== null ? Number(rawDist).toFixed(1) : '14.3';
    return {
      headline: 'The roof is shifting downward and at risk of collapse',
      category: 'Roof & Strata Structural Hazard',
      trendStatement: `Getting worse quickly — roof clearance has shrunk from 18.5 cm to ${currCm} cm in the last 20 minutes`,
      trendDetail: 'Immediate support prop reinforcement or zone clearance advised.',
      severity: alert?.severity || 'critical',
      primarySensor: 'HC-SR04 Ultrasonic Clearance',
      currentValue: `${currCm} cm`,
      thresholdValue: '15.0 cm limit',
      delta: '-4.2 cm clearance lost',
      riskScore: 95,
      sparklineData: [18.5, 18.2, 17.8, 17.1, 16.4, 15.6, 14.8, Number(currCm)],
      iconType: 'roof'
    };
  }

  if (msg.includes('gas') || msg.includes('methane') || threshold.includes('gas') || type.includes('gas')) {
    const currGas = rawGas !== null ? Math.round(rawGas) : 2720;
    return {
      headline: 'Hazardous gas concentration detected in active tunnel corridor',
      category: 'Atmospheric Safety Hazard',
      trendStatement: `Gas sensor reading escalated to ${currGas} ADC — threshold is 2200 ADC`,
      trendDetail: 'Ventilation exhaust boosters should be engaged immediately.',
      severity: alert?.severity || 'critical',
      primarySensor: 'MQ-4 / Gas Sensor ADC',
      currentValue: `${currGas} ADC`,
      thresholdValue: '2200 ADC limit',
      delta: `+${currGas - 2200} ADC above safe line`,
      riskScore: 88,
      sparklineData: [1420, 1650, 1890, 2100, 2350, 2580, 2690, currGas],
      iconType: 'gas'
    };
  }

  if (msg.includes('tilt') || msg.includes('structural') || threshold.includes('tilt') || type.includes('tilt')) {
    const currTilt = rawTilt !== null ? Number(rawTilt).toFixed(2) : '3.35';
    return {
      headline: 'Structural support pillar is tilting under heavy rock displacement',
      category: 'Geotechnical Pillar Movement',
      trendStatement: `Pillar tilt angle has increased to ${currTilt}° — maximum safe tolerance is 2.0°`,
      trendDetail: 'Ground stability inspection team should verify pillar load-bearing integrity.',
      severity: alert?.severity || 'warning',
      primarySensor: 'MPU9250 Dual-Axis Inclinometer',
      currentValue: `${currTilt}°`,
      thresholdValue: '2.00° limit',
      delta: `+${(Number(currTilt) - 2.0).toFixed(2)}° deviation`,
      riskScore: 68,
      sparklineData: [0.6, 0.8, 1.1, 1.4, 1.9, 2.3, 2.8, Number(currTilt)],
      iconType: 'tilt'
    };
  }

  if (msg.includes('water') || msg.includes('rain') || msg.includes('ingress') || threshold.includes('water') || type.includes('water') || type.includes('rain')) {
    const currRain = rawRain !== null ? Math.round(rawRain) : 420;
    return {
      headline: 'Water ingress detected in stope drainage corridor',
      category: 'Flooding & Sump Hazard',
      trendStatement: `Water sensor registered ${currRain} ADC in drainage gutter — sump pumps active`,
      trendDetail: 'Verify runoff channel clearance and secondary drainage outflow.',
      severity: alert?.severity || 'warning',
      primarySensor: 'Drainage Conductivity Sensor',
      currentValue: `${currRain} ADC`,
      thresholdValue: '350 ADC limit',
      delta: `+${currRain - 350} ADC runoff`,
      riskScore: 54,
      sparklineData: [45, 60, 120, 210, 310, 370, 405, currRain],
      iconType: 'water'
    };
  }

  return {
    headline: alert?.message || 'Geotechnical anomaly requires supervisor review',
    category: 'Operational Alert',
    trendStatement: 'Abnormal sensor variance detected against nominal safety baselines',
    trendDetail: 'Review sensor diagnostics and verify site conditions.',
    severity: alert?.severity || 'warning',
    primarySensor: 'Automated Mine Sensor Node',
    currentValue: alert?.breachAmount || 'Breach',
    thresholdValue: alert?.threshold || 'Safety Limit',
    delta: 'Variance detected',
    riskScore: (alert?.severity || '').toLowerCase() === 'critical' ? 82 : 45,
    sparklineData: [30, 35, 42, 50, 62, 70, 78, 85],
    iconType: 'general'
  };
}

// Helper: Clean location line for non-technical users
function getPlainLocation(alert, node, zoneMeta) {
  const zoneName = zoneMeta?.name || alert?.zoneName || (alert?.nodeId ? NODES_METADATA[alert.nodeId]?.name : null) || 'Sub-Level 4';
  const depth = node?.depth || zoneMeta?.depth || (alert?.nodeId ? NODES_METADATA[alert.nodeId]?.depth : null) || -460;
  const cleanZone = zoneName.replace(/Zone\s*\d+\s*[—–-]\s*/i, '').trim();
  const stationName = node?.name || (alert?.nodeId ? NODES_METADATA[alert.nodeId]?.name : null) || alert?.nodeId || 'Station N-07';
  return `${cleanZone} · Depth ${Math.abs(depth)}m · Station ${alert?.nodeId || 'N-07'} (${stationName})`;
}

// Helper: Real iconography for every alert type
function getAlertIcon(iconType, size = 16) {
  switch (iconType) {
    case 'gas':
      return <Flame size={size} />;
    case 'water':
      return <Droplets size={size} />;
    case 'tilt':
      return <Activity size={size} />;
    case 'roof':
    default:
      return <AlertTriangle size={size} />;
  }
}

// Circular Risk Gauge SVG Component
function RiskGauge({ score = 85, severity = 'critical' }) {
  const radius = 42;
  const stroke = 8;
  const normalizedRadius = radius - stroke;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (Math.min(100, Math.max(0, score)) / 100) * circumference;

  const color = severity === 'critical' ? '#FF4D4D' : severity === 'warning' ? '#FFB020' : '#00D6A3';

  return (
    <div style={{ position: 'relative', width: '104px', height: '104px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <svg height="104" width="104" style={{ transform: 'rotate(-90deg)' }}>
        <circle
          stroke="rgba(255, 255, 255, 0.08)"
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx="52"
          cy="52"
        />
        <circle
          stroke={color}
          fill="transparent"
          strokeWidth={stroke}
          strokeDasharray={`${circumference} ${circumference}`}
          style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.6s cubic-bezier(0.16, 1, 0.3, 1)' }}
          strokeLinecap="round"
          r={normalizedRadius}
          cx="52"
          cy="52"
        />
      </svg>
      <div style={{ position: 'absolute', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <span style={{ fontSize: '1.5rem', fontWeight: 800, color, lineHeight: 1, fontFamily: 'var(--font-mono)' }}>
          {score}
        </span>
        <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: '2px' }}>
          RISK / 100
        </span>
      </div>
    </div>
  );
}

// Sparkline SVG Component
function Sparkline({ data, severity }) {
  const points = data && data.length > 2 ? data : [18.5, 18.2, 17.8, 17.1, 16.4, 15.6, 14.8, 14.3];
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const width = 160;
  const height = 44;

  const coordinates = points.map((val, idx) => {
    const x = (idx / (points.length - 1)) * (width - 16) + 8;
    const y = height - ((val - min) / range) * (height - 16) - 8;
    return `${x},${y}`;
  }).join(' ');

  const strokeColor = severity === 'critical' ? '#FF4D4D' : severity === 'warning' ? '#FFB020' : '#00D6A3';
  const lastX = width - 8;
  const lastY = height - ((points[points.length - 1] - min) / range) * (height - 16) - 8;

  return (
    <svg width={width} height={height} style={{ overflow: 'visible' }}>
      <polyline
        fill="none"
        stroke={strokeColor}
        strokeWidth="2.75"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={coordinates}
      />
      <circle
        cx={lastX}
        cy={lastY}
        r="4.5"
        fill={strokeColor}
        style={{ filter: `drop-shadow(0 0 6px ${strokeColor})` }}
      />
    </svg>
  );
}

export function AlertsPage() {
  const {
    alerts,
    nodes,
    acknowledgeAlert,
    assignAlert,
    escalateAlert,
    resolveAlert
  } = useSim();

  // Filters
  const [severityFilter, setSeverityFilter] = useState('all');
  const [zoneFilter, setZoneFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected alert for Featured Card focus
  const [selectedAlertId, setSelectedAlertId] = useState(null);
  const [actionToast, setActionToast] = useState(null);
  const [showSensorDetails, setShowSensorDetails] = useState(false);
  const [showAllAlerts, setShowAllAlerts] = useState(false);

  // Summary counts
  const critCount = alerts.filter((a) => (a.severity || '').toLowerCase() === 'critical' && a.state !== 'resolved').length;
  const warnCount = alerts.filter((a) => (a.severity || '').toLowerCase() === 'warning' && a.state !== 'resolved').length;
  const resolvedCount = alerts.filter((a) => a.state === 'resolved').length;
  const totalSafeStations = Math.max(0, 8 - (critCount + warnCount));

  // Determine effective selected alert (default to first active critical, or first active warning, or first alert)
  const effectiveSelectedAlert = useMemo(() => {
    if (selectedAlertId) {
      const match = alerts.find((a) => a.id === selectedAlertId);
      if (match) return match;
    }
    const firstCrit = alerts.find((a) => (a.severity || '').toLowerCase() === 'critical' && a.state !== 'resolved');
    if (firstCrit) return firstCrit;
    const firstWarn = alerts.find((a) => (a.severity || '').toLowerCase() === 'warning' && a.state !== 'resolved');
    if (firstWarn) return firstWarn;
    return alerts[0] || null;
  }, [alerts, selectedAlertId]);

  const triggerNode = effectiveSelectedAlert ? nodes[effectiveSelectedAlert.nodeId] : null;
  const effectiveZoneId = effectiveSelectedAlert?.zoneId || (effectiveSelectedAlert?.nodeId ? NODES_METADATA[effectiveSelectedAlert.nodeId]?.zoneId : null);
  const zoneMeta = ZONES_METADATA.find((z) => z.id === effectiveZoneId);
  const plainAlert = useMemo(() => getPlainLanguageAlert(effectiveSelectedAlert, triggerNode), [effectiveSelectedAlert, triggerNode]);
  const plainLocation = useMemo(() => getPlainLocation(effectiveSelectedAlert, triggerNode, zoneMeta), [effectiveSelectedAlert, triggerNode, zoneMeta]);

  // Filter list for "Other Active Alerts"
  const filteredAlerts = useMemo(() => {
    return alerts.filter((a) => {
      const aSev = (a.severity || '').toLowerCase();
      if (severityFilter !== 'all') {
        if (severityFilter === 'resolved' && a.state !== 'resolved') return false;
        if (severityFilter !== 'resolved' && aSev !== severityFilter.toLowerCase()) return false;
      }
      const aZone = a.zoneId || (a.nodeId ? NODES_METADATA[a.nodeId]?.zoneId : null);
      if (zoneFilter !== 'all' && aZone !== zoneFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchesMsg = a.message?.toLowerCase().includes(q);
        const matchesNode = a.nodeId?.toLowerCase().includes(q);
        const matchesAssignee = a.assignee?.toLowerCase().includes(q);
        const matchesId = a.id?.toLowerCase().includes(q);
        if (!matchesMsg && !matchesNode && !matchesAssignee && !matchesId) return false;
      }
      return true;
    });
  }, [alerts, severityFilter, zoneFilter, searchQuery]);

  // Deduplicate and group alerts by node + issue type
  const groupedAlerts = useMemo(() => {
    const groupsMap = new Map();

    filteredAlerts.forEach((alt) => {
      const node = nodes[alt.nodeId];
      const info = getPlainLanguageAlert(alt, node);
      const groupKey = `${alt.nodeId}__${info.iconType}`;
      const altTime = new Date(alt.timestamp || 0).getTime();
      const altZone = alt.zoneId || (alt.nodeId ? NODES_METADATA[alt.nodeId]?.zoneId : null);
      const altSev = (alt.severity || 'warning').toLowerCase();

      if (!groupsMap.has(groupKey)) {
        groupsMap.set(groupKey, {
          key: groupKey,
          nodeId: alt.nodeId,
          iconType: info.iconType,
          headline: info.headline,
          category: info.category,
          zoneId: altZone,
          primaryAlert: alt,
          alerts: [alt],
          firstTimestamp: altTime,
          latestTimestamp: altTime,
          count: 1,
          severity: altSev,
          state: alt.state,
          assignee: alt.assignee
        });
      } else {
        const grp = groupsMap.get(groupKey);
        grp.alerts.push(alt);
        grp.count += 1;
        if (altTime < grp.firstTimestamp) {
          grp.firstTimestamp = altTime;
        }
        if (altTime >= grp.latestTimestamp) {
          grp.latestTimestamp = altTime;
          grp.primaryAlert = alt;
          grp.state = alt.state;
          grp.assignee = alt.assignee;
        }
        if (altSev === 'critical') {
          grp.severity = 'critical';
        } else if (altSev === 'warning' && grp.severity !== 'critical') {
          grp.severity = 'warning';
        }
      }
    });

    return Array.from(groupsMap.values()).sort((a, b) => {
      const aResolved = a.state === 'resolved' ? 1 : 0;
      const bResolved = b.state === 'resolved' ? 1 : 0;
      if (aResolved !== bResolved) return aResolved - bResolved;

      const sevRank = { critical: 0, warning: 1, safe: 2, info: 3 };
      const aRank = sevRank[(a.severity || '').toLowerCase()] ?? 2;
      const bRank = sevRank[(b.severity || '').toLowerCase()] ?? 2;
      if (aRank !== bRank) return aRank - bRank;

      return b.latestTimestamp - a.latestTimestamp;
    });
  }, [filteredAlerts, nodes]);

  const visibleGroupedAlerts = useMemo(() => {
    return showAllAlerts ? groupedAlerts : groupedAlerts.slice(0, 8);
  }, [showAllAlerts, groupedAlerts]);

  // Actions
  const handleAcknowledge = () => {
    if (!effectiveSelectedAlert) return;
    acknowledgeAlert(effectiveSelectedAlert.id, 'Shift Supervisor');
    setActionToast({
      title: "I'm on it — Acknowledged",
      desc: `Incident #${effectiveSelectedAlert.id} acknowledged by Shift Supervisor. Dispatch status updated.`,
      color: '#00D9FF'
    });
    setTimeout(() => setActionToast(null), 4000);
  };

  const handleDispatch = () => {
    if (!effectiveSelectedAlert) return;
    assignAlert(effectiveSelectedAlert.id, 'Rapid Response Crew Delta');
    setActionToast({
      title: 'Help Dispatched — Crew En Route',
      desc: `Rapid Response Crew Delta assigned to Station ${effectiveSelectedAlert.nodeId}. Priority response initiated.`,
      color: '#FFB020'
    });
    setTimeout(() => setActionToast(null), 4000);
  };

  const handleEscalate = () => {
    if (!effectiveSelectedAlert) return;
    escalateAlert(effectiveSelectedAlert.id, 'Mine Operations Superintendent');
    setActionToast({
      title: 'Escalated to Mine Leadership',
      desc: `Incident #${effectiveSelectedAlert.id} escalated to Mine Superintendent and Site Safety Director.`,
      color: '#FF4D4D'
    });
    setTimeout(() => setActionToast(null), 4000);
  };

  const handleResolve = () => {
    if (!effectiveSelectedAlert) return;
    resolveAlert(effectiveSelectedAlert.id, 'Lead Safety Engineer');
    setActionToast({
      title: 'Hazard Resolved & Cleared',
      desc: `Incident #${effectiveSelectedAlert.id} marked RESOLVED. Post-inspection compliance logged.`,
      color: '#00D6A3'
    });
    setTimeout(() => setActionToast(null), 4000);
  };

  // Connected Progress Tracker calculation (4 steps)
  // 1. Reported -> 2. Notified -> 3. Responding -> 4. Resolved
  let stepIndex = 1; // Default: Reported (0) & Notified (1)
  if (effectiveSelectedAlert?.state === 'resolved') {
    stepIndex = 3; // Step 4 Resolved (0-indexed: 3)
  } else if (effectiveSelectedAlert?.state === 'escalated') {
    stepIndex = 2; // Step 3 Responding
  } else if (effectiveSelectedAlert?.assignee && effectiveSelectedAlert.assignee !== 'Unassigned' && effectiveSelectedAlert.assignee !== 'Control Room') {
    stepIndex = 2; // Step 3 Responding (Crew dispatched)
  } else if (effectiveSelectedAlert?.state === 'acknowledged') {
    stepIndex = 2; // Step 3 Responding (Operator on it)
  } else {
    stepIndex = 1; // Step 2 Notified (Paging active)
  }

  const trackerSteps = [
    {
      title: 'Reported',
      desc: 'Sensor anomaly detected',
      icon: Radio,
      time: effectiveSelectedAlert ? new Date(effectiveSelectedAlert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '10:14'
    },
    {
      title: 'Notified',
      desc: 'Control room paged',
      icon: BellRing,
      time: 'Immediate'
    },
    {
      title: 'Responding',
      desc: effectiveSelectedAlert?.assignee || 'Awaiting triage',
      icon: Users,
      time: effectiveSelectedAlert?.state === 'acknowledged' || effectiveSelectedAlert?.assignee !== 'Control Room' ? 'Active' : 'Standby'
    },
    {
      title: 'Resolved',
      desc: effectiveSelectedAlert?.state === 'resolved' ? 'Signed off' : 'Pending inspection',
      icon: CheckCircle2,
      time: effectiveSelectedAlert?.state === 'resolved' ? 'Cleared' : 'Open'
    }
  ];

  const overallSiteSeverity = critCount > 0 ? 'critical' : warnCount > 0 ? 'warning' : 'safe';
  const siteAccentColor = overallSiteSeverity === 'critical' ? '#FF4D4D' : overallSiteSeverity === 'warning' ? '#FFB020' : '#00D6A3';

  return (
    <CommandLayout>
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '24px 32px 48px',
          display: 'flex',
          flexDirection: 'column',
          gap: '20px',
          boxSizing: 'border-box',
          maxWidth: '1440px',
          margin: '0 auto',
          width: '100%'
        }}
      >
        {/* ── Page Eyebrow & High-Level Purpose ── */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
              <span
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  backgroundColor: siteAccentColor,
                  boxShadow: `0 0 10px ${siteAccentColor}`
                }}
              />
              <span
                style={{
                  color: siteAccentColor,
                  letterSpacing: '0.1em',
                  fontSize: '0.6875rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-mono)',
                  textTransform: 'uppercase'
                }}
              >
                Safety &amp; Incident Dispatch · Module 04
              </span>
            </div>
            <h1
              style={{
                margin: 0,
                fontFamily: 'var(--font-ui)',
                fontSize: '1.75rem',
                fontWeight: 700,
                letterSpacing: '-0.02em',
                color: '#FFFFFF',
                lineHeight: 1.2
              }}
            >
              Alert Dispatch &amp; Safety Lifecycle
            </h1>
            <p
              style={{
                margin: '4px 0 0',
                fontFamily: 'var(--font-ui)',
                fontSize: '0.875rem',
                color: 'var(--dust)',
                lineHeight: 1.4
              }}
            >
              Calm, clear underground hazard triage. Non-technical operators can review threats and dispatch help in seconds.
            </p>
          </div>

          {/* Quick Action Toast if present */}
          {actionToast && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '10px 18px',
                backgroundColor: 'rgba(14, 18, 24, 0.95)',
                border: `1.5px solid ${actionToast.color}`,
                borderRadius: '12px',
                boxShadow: `0 8px 24px rgba(0, 0, 0, 0.6), 0 0 16px ${actionToast.color}33`,
                animation: 'fadeIn 0.25s ease'
              }}
            >
              <div
                style={{
                  width: '28px',
                  height: '28px',
                  borderRadius: '50%',
                  backgroundColor: `${actionToast.color}22`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: actionToast.color
                }}
              >
                <Check size={16} />
              </div>
              <div>
                <div style={{ fontSize: '0.8125rem', fontWeight: 700, color: '#FFFFFF', fontFamily: 'var(--font-ui)' }}>
                  {actionToast.title}
                </div>
                <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-ui)', marginTop: '2px' }}>
                  {actionToast.desc}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* 1. HERO STATUS BAR (Top)                                                   */}
        {/* ========================================================================= */}
        <div
          style={{
            position: 'relative',
            backgroundColor: 'rgba(14, 17, 24, 0.85)',
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            borderRadius: '16px',
            padding: '18px 24px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '16px',
            overflow: 'hidden',
            boxShadow: '0 8px 24px rgba(0, 0, 0, 0.45)'
          }}
        >
          {/* Left colored vertical accent bar */}
          <div
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              bottom: 0,
              width: '6px',
              backgroundColor: siteAccentColor,
              boxShadow: `0 0 12px ${siteAccentColor}`
            }}
          />

          {/* Left Group: Circular Badge + Headline + Calm Subline */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '18px', paddingLeft: '6px' }}>
            <div
              style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                backgroundColor: `${siteAccentColor}18`,
                border: `1.5px solid ${siteAccentColor}66`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: siteAccentColor,
                boxShadow: `0 0 20px ${siteAccentColor}2a`,
                flexShrink: 0
              }}
            >
              {overallSiteSeverity === 'critical' ? (
                <AlertTriangle size={24} />
              ) : overallSiteSeverity === 'warning' ? (
                <ShieldAlert size={24} />
              ) : (
                <ShieldCheck size={24} />
              )}
            </div>

            <div>
              <h2
                style={{
                  margin: 0,
                  fontSize: '1.25rem',
                  fontWeight: 700,
                  color: '#FFFFFF',
                  fontFamily: 'var(--font-ui)',
                  letterSpacing: '-0.01em'
                }}
              >
                {critCount > 0
                  ? `${critCount} critical alert${critCount > 1 ? 's need' : ' needs'} attention`
                  : warnCount > 0
                  ? `${warnCount} warning alert${warnCount > 1 ? 's' : ''} under active monitoring`
                  : 'All site sectors stable — zero critical hazards'}
              </h2>
              <div
                style={{
                  margin: '3px 0 0',
                  fontSize: '0.8125rem',
                  color: 'var(--dust)',
                  fontFamily: 'var(--font-ui)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <span>Everything else on site is stable</span>
                <span style={{ color: 'rgba(255, 255, 255, 0.2)' }}>•</span>
                <span>{totalSafeStations} of 8 underground monitoring stations nominal</span>
              </div>
            </div>
          </div>

          {/* Right Group: Small "Site status" label with a colored status word */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexShrink: 0 }}>
            <div style={{ textAlign: 'right' }}>
              <span
                style={{
                  display: 'block',
                  fontSize: '0.625rem',
                  fontFamily: 'var(--font-ui)',
                  color: 'var(--dust)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.08em',
                  fontWeight: 600
                }}
              >
                Site Status
              </span>
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '4px 12px',
                  borderRadius: '9999px',
                  backgroundColor: `${siteAccentColor}18`,
                  border: `1px solid ${siteAccentColor}44`,
                  marginTop: '3px'
                }}
              >
                <span
                  style={{
                    width: '6px',
                    height: '6px',
                    borderRadius: '50%',
                    backgroundColor: siteAccentColor,
                    boxShadow: `0 0 8px ${siteAccentColor}`
                  }}
                />
                <span
                  style={{
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    color: siteAccentColor,
                    fontFamily: 'var(--font-mono)',
                    letterSpacing: '0.04em'
                  }}
                >
                  {overallSiteSeverity === 'critical' ? 'CRITICAL' : overallSiteSeverity === 'warning' ? 'ELEVATED' : 'ALL CLEAR'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* 2. FEATURED ALERT CARD (The Main Focus)                                    */}
        {/* ========================================================================= */}
        {effectiveSelectedAlert ? (
          <div
            style={{
              backgroundColor: 'rgba(12, 15, 22, 0.92)',
              backdropFilter: 'blur(16px)',
              WebkitBackdropFilter: 'blur(16px)',
              border: `1.5px solid ${plainAlert.severity === 'critical' ? 'rgba(255, 77, 77, 0.35)' : 'rgba(255, 176, 32, 0.35)'}`,
              borderRadius: '16px',
              padding: '28px 32px',
              display: 'flex',
              flexDirection: 'column',
              gap: '24px',
              boxShadow: `0 20px 50px rgba(0, 0, 0, 0.65), 0 0 30px ${plainAlert.severity === 'critical' ? 'rgba(255, 77, 77, 0.08)' : 'rgba(255, 176, 32, 0.08)'}`,
              position: 'relative'
            }}
          >
            {/* Top Bar: Pill Severity Badge + Relative Timestamp + Incident ID */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
                {/* Pill-shaped severity badge */}
                <div
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '6px 14px',
                    borderRadius: '9999px',
                    backgroundColor: plainAlert.severity === 'critical' ? 'rgba(255, 77, 77, 0.16)' : 'rgba(255, 176, 32, 0.16)',
                    border: `1px solid ${plainAlert.severity === 'critical' ? '#FF4D4D' : '#FFB020'}`,
                    color: plainAlert.severity === 'critical' ? '#FF4D4D' : '#FFB020',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    fontFamily: 'var(--font-mono)',
                    letterSpacing: '0.04em'
                  }}
                >
                  {plainAlert.severity === 'critical' ? <AlertCircle size={14} /> : <AlertTriangle size={14} />}
                  <span>{plainAlert.severity.toUpperCase()} ALERT</span>
                </div>

                {/* Relative timestamp with clock icon */}
                <div
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px',
                    color: 'var(--dust)',
                    fontSize: '0.75rem',
                    fontFamily: 'var(--font-ui)',
                    fontWeight: 500
                  }}
                >
                  <Clock size={14} color="#00D9FF" />
                  <span>
                    Triggered {new Date(effectiveSelectedAlert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>

                {/* Category Pill with Icon */}
                <span
                  style={{
                    fontSize: '0.6875rem',
                    fontFamily: 'var(--font-mono)',
                    color: 'var(--ash)',
                    backgroundColor: 'rgba(255, 255, 255, 0.04)',
                    padding: '3px 10px',
                    borderRadius: '6px',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                >
                  {getAlertIcon(plainAlert.iconType, 13)}
                  <span>{plainAlert.category}</span>
                </span>
              </div>

              {/* Right: Incident Reference */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span
                  style={{
                    fontSize: '0.75rem',
                    fontFamily: 'var(--font-mono)',
                    color: 'var(--dust)',
                    backgroundColor: 'rgba(0, 0, 0, 0.35)',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    padding: '4px 10px',
                    borderRadius: '8px'
                  }}
                >
                  ID: #{effectiveSelectedAlert.id}
                </span>
              </div>
            </div>

            {/* Headline and Location */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <h3
                style={{
                  margin: 0,
                  fontSize: '1.625rem',
                  fontWeight: 700,
                  color: '#FFFFFF',
                  fontFamily: 'var(--font-ui)',
                  lineHeight: 1.25,
                  letterSpacing: '-0.015em'
                }}
              >
                {plainAlert.headline}
              </h3>

              {/* Plain location line with map-pin icon */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  color: '#00D9FF',
                  fontSize: '0.875rem',
                  fontFamily: 'var(--font-ui)',
                  fontWeight: 500
                }}
              >
                <MapPin size={16} color="#00D9FF" style={{ flexShrink: 0 }} />
                <span>{plainLocation}</span>
              </div>
            </div>

            {/* Visual Risk Gauge & Trend Strip Row */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'auto minmax(0, 1fr)',
                gap: '24px',
                alignItems: 'center',
                backgroundColor: 'rgba(18, 22, 32, 0.65)',
                border: '1px solid rgba(255, 255, 255, 0.06)',
                borderRadius: '14px',
                padding: '18px 24px'
              }}
            >
              {/* Circular Risk Gauge (SVG Ring) */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px', borderRight: '1px solid rgba(255, 255, 255, 0.08)', paddingRight: '20px' }}>
                <RiskGauge score={plainAlert.riskScore} severity={plainAlert.severity} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <span style={{ fontSize: '0.6875rem', color: 'var(--dust)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600 }}>
                    Threat Level
                  </span>
                  <span
                    style={{
                      fontSize: '0.9375rem',
                      fontWeight: 700,
                      color: plainAlert.severity === 'critical' ? '#FF4D4D' : '#FFB020',
                      fontFamily: 'var(--font-ui)'
                    }}
                  >
                    {plainAlert.severity === 'critical' ? 'CRITICAL EVACUATION RISK' : 'ELEVATED WARNING'}
                  </span>
                  <span style={{ fontSize: '0.6875rem', color: 'var(--ash)' }}>
                    Continuous AI surveillance
                  </span>
                </div>
              </div>

              {/* Trend Strip: Sparkline + Plain Language Trend Statement with Real Numbers */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '20px',
                  backgroundColor: plainAlert.severity === 'critical' ? 'rgba(255, 77, 77, 0.07)' : 'rgba(255, 176, 32, 0.07)',
                  border: `1px solid ${plainAlert.severity === 'critical' ? 'rgba(255, 77, 77, 0.2)' : 'rgba(255, 176, 32, 0.2)'}`,
                  borderRadius: '12px',
                  padding: '14px 20px'
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    {plainAlert.severity === 'critical' ? (
                      <TrendingDown size={16} color="#FF4D4D" />
                    ) : (
                      <TrendingUp size={16} color="#FFB020" />
                    )}
                    <span
                      style={{
                        fontSize: '0.6875rem',
                        fontWeight: 700,
                        color: plainAlert.severity === 'critical' ? '#FF4D4D' : '#FFB020',
                        textTransform: 'uppercase',
                        letterSpacing: '0.06em',
                        fontFamily: 'var(--font-mono)'
                      }}
                    >
                      Trajectory Status
                    </span>
                  </div>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#FFFFFF', fontFamily: 'var(--font-ui)', lineHeight: 1.35 }}>
                    {plainAlert.trendStatement}
                  </div>
                  <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-ui)' }}>
                    {plainAlert.trendDetail}
                  </div>
                </div>

                <div style={{ flexShrink: 0 }}>
                  <Sparkline data={plainAlert.sparklineData} severity={plainAlert.severity} />
                  <div style={{ textAlign: 'right', fontSize: '0.625rem', color: 'var(--ash)', marginTop: '2px', fontFamily: 'var(--font-mono)' }}>
                    T-20m → Now
                  </div>
                </div>
              </div>
            </div>

            {/* 3 Large Pill-Shaped Action Buttons */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
              {/* Button 1: "I'm on it" (Acknowledge) */}
              <button
                onClick={handleAcknowledge}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '12px 26px',
                  borderRadius: '9999px',
                  backgroundColor: '#00D9FF',
                  border: 'none',
                  color: '#08090B',
                  fontSize: '0.875rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-ui)',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  boxShadow: '0 4px 14px rgba(0, 217, 255, 0.35)'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-1px)')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = 'none')}
              >
                <UserCheck size={18} />
                <span>{effectiveSelectedAlert.state === 'acknowledged' ? "I'm on it (Re-confirm)" : "I'm on it"}</span>
              </button>

              {/* Button 2: "Send help" (Dispatch Crew) */}
              <button
                onClick={handleDispatch}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '12px 26px',
                  borderRadius: '9999px',
                  backgroundColor: '#FFB020',
                  border: 'none',
                  color: '#08090B',
                  fontSize: '0.875rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-ui)',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  boxShadow: '0 4px 14px rgba(255, 176, 32, 0.35)'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-1px)')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = 'none')}
              >
                <Users size={18} />
                <span>Send help</span>
              </button>

              {/* Button 3: "Escalate" (Escalate to Leadership) */}
              <button
                onClick={handleEscalate}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '12px 26px',
                  borderRadius: '9999px',
                  backgroundColor: '#FF4D4D',
                  border: 'none',
                  color: '#FFFFFF',
                  fontSize: '0.875rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-ui)',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  boxShadow: '0 4px 14px rgba(255, 77, 77, 0.35)'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-1px)')}
                onMouseLeave={(e) => (e.currentTarget.style.transform = 'none')}
              >
                <Zap size={18} />
                <span>Escalate</span>
              </button>

              {/* Button 4: "Mark Resolved" */}
              <button
                onClick={handleResolve}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '12px 22px',
                  borderRadius: '9999px',
                  backgroundColor: 'rgba(0, 214, 163, 0.15)',
                  border: '1.5px solid #00D6A3',
                  color: '#00D6A3',
                  fontSize: '0.8125rem',
                  fontWeight: 600,
                  fontFamily: 'var(--font-ui)',
                  cursor: 'pointer',
                  marginLeft: 'auto',
                  transition: 'all 0.15s ease'
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(0, 214, 163, 0.25)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'rgba(0, 214, 163, 0.15)')}
              >
                <Check size={16} />
                <span>Mark Resolved</span>
              </button>
            </div>

            {/* Connected Progress Tracker: 4 Steps (Reported → Notified → Responding → Resolved) */}
            <div
              style={{
                backgroundColor: 'rgba(16, 20, 28, 0.75)',
                border: '1px solid rgba(255, 255, 255, 0.06)',
                borderRadius: '14px',
                padding: '18px 24px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--dust)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Safety Incident Response Progress
                </span>
                <span style={{ fontSize: '0.6875rem', color: '#00D9FF', fontFamily: 'var(--font-mono)' }}>
                  Current Phase: {trackerSteps[stepIndex]?.title}
                </span>
              </div>

              {/* Step Flow Bar */}
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 10px 4px' }}>
                {/* Background Connecting Line */}
                <div
                  style={{
                    position: 'absolute',
                    top: '26px',
                    left: '40px',
                    right: '40px',
                    height: '3px',
                    backgroundColor: 'rgba(255, 255, 255, 0.08)',
                    zIndex: 1
                  }}
                />

                {/* Filled Colored Progress Line */}
                <div
                  style={{
                    position: 'absolute',
                    top: '26px',
                    left: '40px',
                    width: `${(stepIndex / (trackerSteps.length - 1)) * 88}%`,
                    height: '3px',
                    backgroundColor: stepIndex === 3 ? '#00D6A3' : '#00D9FF',
                    boxShadow: `0 0 8px ${stepIndex === 3 ? '#00D6A3' : '#00D9FF'}`,
                    transition: 'width 0.4s ease',
                    zIndex: 2
                  }}
                />

                {trackerSteps.map((step, idx) => {
                  const isCompleted = idx <= stepIndex;
                  const isCurrent = idx === stepIndex;
                  const StepIcon = step.icon;
                  const stepColor = isCurrent ? '#00D9FF' : isCompleted ? '#00D6A3' : 'var(--ash)';

                  return (
                    <div
                      key={step.title}
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '8px',
                        zIndex: 3,
                        position: 'relative',
                        width: '120px',
                        textAlign: 'center'
                      }}
                    >
                      {/* Step Circle with Icon */}
                      <div
                        style={{
                          width: '32px',
                          height: '32px',
                          borderRadius: '50%',
                          backgroundColor: isCompleted ? (isCurrent ? '#00D9FF' : '#00D6A3') : 'rgba(20, 24, 32, 0.95)',
                          border: `2px solid ${stepColor}`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: isCompleted ? '#08090B' : 'var(--ash)',
                          boxShadow: isCurrent ? '0 0 16px rgba(0, 217, 255, 0.5)' : 'none',
                          transition: 'all 0.3s ease'
                        }}
                      >
                        <StepIcon size={16} />
                      </div>

                      {/* Step Labels */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span
                          style={{
                            fontSize: '0.75rem',
                            fontWeight: isCurrent ? 700 : 600,
                            color: isCurrent ? '#FFFFFF' : isCompleted ? '#E9E6E0' : 'var(--ash)',
                            fontFamily: 'var(--font-ui)'
                          }}
                        >
                          {step.title}
                        </span>
                        <span style={{ fontSize: '0.625rem', color: isCurrent ? '#00D9FF' : 'var(--dust)', fontFamily: 'var(--font-ui)' }}>
                          {step.desc}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Collapsible "View sensor readings" section for raw technical data */}
            <div
              style={{
                backgroundColor: 'rgba(10, 13, 18, 0.65)',
                border: '1px solid rgba(255, 255, 255, 0.06)',
                borderRadius: '14px',
                overflow: 'hidden'
              }}
            >
              {/* Collapsible Header Button */}
              <button
                onClick={() => setShowSensorDetails((prev) => !prev)}
                style={{
                  width: '100%',
                  padding: '14px 20px',
                  backgroundColor: 'transparent',
                  border: 'none',
                  color: 'var(--dust)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  cursor: 'pointer',
                  textAlign: 'left'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <SlidersHorizontal size={16} color="#00D9FF" />
                  <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#FFFFFF', fontFamily: 'var(--font-ui)' }}>
                    View Raw Sensor Telemetry &amp; Diagnostics
                  </span>
                  <span style={{ fontSize: '0.6875rem', color: 'var(--ash)', fontFamily: 'var(--font-ui)' }}>
                    (HC-SR04, MPU9250, Gas ADC, Battery)
                  </span>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.75rem', color: '#00D9FF' }}>
                  <span>{showSensorDetails ? 'Hide details' : 'Show details'}</span>
                  {showSensorDetails ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>
              </button>

              {/* Collapsible Content */}
              {showSensorDetails && (
                <div
                  style={{
                    padding: '0 20px 20px',
                    borderTop: '1px solid rgba(255, 255, 255, 0.06)',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                    gap: '12px',
                    marginTop: '12px'
                  }}
                >
                  {/* Metric Card 1: Roof Convergence */}
                  <div style={{ backgroundColor: 'rgba(20, 24, 32, 0.75)', padding: '12px 14px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.05)' }}>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
                      HC-SR04 Roof Clearance
                    </div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#FF4D4D', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
                      {plainAlert.currentValue}
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                      Threshold limit: 15.0 cm
                    </div>
                  </div>

                  {/* Metric Card 2: Structural Tilt */}
                  <div style={{ backgroundColor: 'rgba(20, 24, 32, 0.75)', padding: '12px 14px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.05)' }}>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
                      MPU9250 Pillar Tilt
                    </div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#FFB020', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
                      {triggerNode?.currentTilt ? `${triggerNode.currentTilt.toFixed(2)}°` : '3.35°'}
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                      Tolerance: &lt; 2.00°
                    </div>
                  </div>

                  {/* Metric Card 3: Gas ADC */}
                  <div style={{ backgroundColor: 'rgba(20, 24, 32, 0.75)', padding: '12px 14px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.05)' }}>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
                      Gas Sensor ADC
                    </div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#FF4D4D', fontFamily: 'var(--font-mono)', marginTop: '4px' }}>
                      {triggerNode?.gasAdc ? `${Math.round(triggerNode.gasAdc)} ADC` : '2720 ADC'}
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                      Threshold: 2200 ADC
                    </div>
                  </div>

                  {/* Metric Card 4: Hardware & Comms */}
                  <div style={{ backgroundColor: 'rgba(20, 24, 32, 0.75)', padding: '12px 14px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.05)' }}>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
                      Node Hardware Status
                    </div>
                    <div style={{ fontSize: '0.875rem', fontWeight: 700, color: '#00D6A3', fontFamily: 'var(--font-mono)', marginTop: '6px' }}>
                      ONLINE · Wi-Fi (94%)
                    </div>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '4px' }}>
                      Station {effectiveSelectedAlert.nodeId} · Depth -460m
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div
            style={{
              padding: '48px',
              textAlign: 'center',
              backgroundColor: 'rgba(12, 15, 22, 0.85)',
              borderRadius: '16px',
              border: '1px solid rgba(255, 255, 255, 0.08)'
            }}
          >
            <ShieldCheck size={48} color="#00D6A3" style={{ marginBottom: '12px' }} />
            <h3 style={{ fontSize: '1.25rem', color: '#FFFFFF', margin: 0 }}>All Mine Stations Nominal</h3>
            <p style={{ color: 'var(--dust)', fontSize: '0.875rem', marginTop: '6px' }}>
              No critical or warning alerts currently active across underground zones.
            </p>
          </div>
        )}

        {/* ========================================================================= */}
        {/* 3. OTHER ACTIVE ALERTS (Compact Rounded Cards Grid)                       */}
        {/* ========================================================================= */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginTop: '8px' }}>
          {/* Section Header with Search & Filter Tabs */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <h3
                style={{
                  margin: 0,
                  fontSize: '1.125rem',
                  fontWeight: 700,
                  color: '#FFFFFF',
                  fontFamily: 'var(--font-ui)'
                }}
              >
                Active Incident Reports ({groupedAlerts.length} distinct problem{groupedAlerts.length === 1 ? '' : 's'})
              </h3>
              <p style={{ margin: '2px 0 0', fontSize: '0.75rem', color: 'var(--dust)' }}>
                Deduplicated by station and issue type · Select any row to inspect and take action
              </p>
            </div>

            {/* Search and Filters */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
              {/* Search Bar */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  backgroundColor: 'rgba(14, 18, 26, 0.9)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '9999px',
                  padding: '6px 14px',
                  minWidth: '220px'
                }}
              >
                <Search size={14} color="#00D9FF" />
                <input
                  type="text"
                  placeholder="Search alerts or stations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: '#FFFFFF',
                    outline: 'none',
                    fontSize: '0.75rem',
                    fontFamily: 'var(--font-ui)',
                    width: '100%'
                  }}
                />
              </div>

              {/* Zone Filter Dropdown */}
              <select
                value={zoneFilter}
                onChange={(e) => setZoneFilter(e.target.value)}
                style={{
                  backgroundColor: 'rgba(14, 18, 26, 0.9)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '9999px',
                  padding: '6px 14px',
                  color: zoneFilter === 'all' ? 'var(--dust)' : '#00D9FF',
                  fontSize: '0.6875rem',
                  fontFamily: 'var(--font-ui)',
                  fontWeight: 600,
                  outline: 'none',
                  cursor: 'pointer'
                }}
              >
                <option value="all">All Underground Zones</option>
                {ZONES_METADATA.map((z) => (
                  <option key={z.id} value={z.id}>
                    {z.name}
                  </option>
                ))}
              </select>

              {/* Severity Pills */}
              <div
                style={{
                  display: 'flex',
                  backgroundColor: 'rgba(14, 18, 26, 0.9)',
                  borderRadius: '9999px',
                  padding: '3px',
                  border: '1px solid rgba(255, 255, 255, 0.08)'
                }}
              >
                {['all', 'critical', 'warning', 'resolved'].map((sev) => {
                  const isSelected = severityFilter === sev;
                  return (
                    <button
                      key={sev}
                      onClick={() => setSeverityFilter(sev)}
                      style={{
                        padding: '4px 12px',
                        fontSize: '0.6875rem',
                        fontFamily: 'var(--font-ui)',
                        fontWeight: isSelected ? 700 : 500,
                        border: 'none',
                        borderRadius: '9999px',
                        backgroundColor: isSelected ? '#00D9FF' : 'transparent',
                        color: isSelected ? '#08090B' : 'var(--dust)',
                        cursor: 'pointer',
                        textTransform: 'capitalize',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      {sev === 'all' ? 'All Alerts' : sev}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Deduplicated Compact Rows List */}
          {groupedAlerts.length === 0 ? (
            <div
              style={{
                padding: '32px',
                textAlign: 'center',
                backgroundColor: 'rgba(14, 18, 24, 0.65)',
                borderRadius: '14px',
                border: '1px dashed rgba(255, 255, 255, 0.1)',
                color: 'var(--dust)',
                fontSize: '0.8125rem'
              }}
            >
              No active alerts matching your search or filter criteria.
            </div>
          ) : (
            <div
              style={{
                backgroundColor: 'rgba(12, 15, 22, 0.75)',
                backdropFilter: 'blur(12px)',
                WebkitBackdropFilter: 'blur(12px)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                borderRadius: '14px',
                overflow: 'hidden',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.35)'
              }}
            >
              {visibleGroupedAlerts.map((grp, idx) => {
                const isSelected = effectiveSelectedAlert && grp.alerts.some((a) => a.id === effectiveSelectedAlert.id);
                const node = nodes[grp.nodeId];
                const isCrit = grp.severity === 'critical';
                const isResolved = grp.state === 'resolved';
                const rowColor = isResolved ? '#00D6A3' : isCrit ? '#FF4D4D' : '#FFB020';
                const firstTimeStr = new Date(grp.firstTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const latestTimeStr = new Date(grp.latestTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                const shortStation = node?.name || grp.nodeId;

                return (
                  <div
                    key={grp.key}
                    onClick={() => setSelectedAlertId(grp.primaryAlert.id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: '14px',
                      padding: '11px 18px',
                      borderBottom: idx < visibleGroupedAlerts.length - 1 ? '1px solid rgba(255, 255, 255, 0.05)' : 'none',
                      backgroundColor: isSelected ? 'rgba(0, 217, 255, 0.07)' : 'transparent',
                      borderLeft: isSelected ? `3px solid ${rowColor}` : '3px solid transparent',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                      if (!isSelected) e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.03)';
                    }}
                    onMouseLeave={(e) => {
                      if (!isSelected) e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    {/* Left Segment: Small Icon + Plain Description + Node & Time Info */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0, flex: 1 }}>
                      {/* Small severity icon */}
                      <div
                        style={{
                          width: '26px',
                          height: '26px',
                          borderRadius: '50%',
                          backgroundColor: `${rowColor}1c`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: rowColor,
                          flexShrink: 0
                        }}
                      >
                        {isResolved ? <Check size={13} /> : getAlertIcon(grp.iconType, 13)}
                      </div>

                      {/* One-line plain description */}
                      <span
                        style={{
                          fontSize: '0.8125rem',
                          fontWeight: isSelected ? 700 : 600,
                          color: isSelected ? '#FFFFFF' : '#E9E6E0',
                          fontFamily: 'var(--font-ui)',
                          whiteSpace: 'nowrap',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          maxWidth: '380px'
                        }}
                        title={grp.headline}
                      >
                        {grp.headline}
                      </span>

                      {/* Node/location badge */}
                      <span
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          fontSize: '0.6875rem',
                          fontFamily: 'var(--font-mono)',
                          color: 'var(--dust)',
                          backgroundColor: 'rgba(255, 255, 255, 0.04)',
                          padding: '2px 8px',
                          borderRadius: '6px',
                          flexShrink: 0
                        }}
                      >
                        <MapPin size={11} color="#00D9FF" />
                        <span>{grp.nodeId} · {shortStation}</span>
                      </span>

                      {/* Deduplication & Relative Timing text */}
                      <span
                        style={{
                          fontSize: '0.6875rem',
                          fontFamily: 'var(--font-mono)',
                          color: 'var(--ash)',
                          whiteSpace: 'nowrap',
                          flexShrink: 0
                        }}
                      >
                        {grp.count > 1 ? (
                          <>
                            Active since {firstTimeStr} · Last updated {latestTimeStr} ·{' '}
                            <strong style={{ color: rowColor }}>Triggered {grp.count}x</strong>
                          </>
                        ) : (
                          <>Triggered {latestTimeStr}</>
                        )}
                      </span>
                    </div>

                    {/* Right Segment: Assignee (if active) + Small "View" link */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexShrink: 0 }}>
                      {grp.assignee && grp.assignee !== 'Unassigned' && (
                        <span
                          style={{
                            fontSize: '0.6875rem',
                            fontFamily: 'var(--font-ui)',
                            color: 'var(--dust)',
                            backgroundColor: 'rgba(255, 255, 255, 0.03)',
                            padding: '2px 8px',
                            borderRadius: '6px'
                          }}
                        >
                          {grp.assignee}
                        </span>
                      )}

                      <div
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: '4px',
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          color: isSelected ? '#00D9FF' : 'var(--dust)',
                          fontFamily: 'var(--font-ui)'
                        }}
                      >
                        <span>{isSelected ? 'Viewing' : 'View'}</span>
                        <ArrowRight size={12} />
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* "Show all" / "Show less" toggle button if more than 8 items */}
              {groupedAlerts.length > 8 && (
                <button
                  onClick={() => setShowAllAlerts((prev) => !prev)}
                  style={{
                    width: '100%',
                    padding: '10px 18px',
                    backgroundColor: 'rgba(18, 22, 32, 0.6)',
                    border: 'none',
                    borderTop: '1px solid rgba(255, 255, 255, 0.06)',
                    color: '#00D9FF',
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    fontFamily: 'var(--font-ui)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '6px',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(0, 217, 255, 0.08)')}
                  onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'rgba(18, 22, 32, 0.6)')}
                >
                  <span>
                    {showAllAlerts
                      ? 'Show less (top 8 distinct alerts)'
                      : `Show all ${groupedAlerts.length} distinct problems (${alerts.length} total events)`}
                  </span>
                  {showAllAlerts ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                </button>
              )}
            </div>
          )}
        </div>

        {/* ========================================================================= */}
        {/* 4. SUMMARY STATS (Bottom, Secondary)                                      */}
        {/* ========================================================================= */}
        <div
          style={{
            marginTop: '12px',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: '12px'
          }}
        >
          {/* Card 1: Unresolved Critical */}
          <div
            style={{
              padding: '14px 18px',
              backgroundColor: 'rgba(14, 18, 24, 0.65)',
              border: '1px solid rgba(255, 255, 255, 0.06)',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', textTransform: 'uppercase', letterSpacing: '0.04em', fontWeight: 600 }}>
                Unresolved Critical
              </div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#FF4D4D', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>
                {critCount}
              </div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                Requires immediate action
              </div>
            </div>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                backgroundColor: 'rgba(255, 77, 77, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#FF4D4D'
              }}
            >
              <AlertTriangle size={18} />
            </div>
          </div>

          {/* Card 2: Warnings */}
          <div
            style={{
              padding: '14px 18px',
              backgroundColor: 'rgba(14, 18, 24, 0.65)',
              border: '1px solid rgba(255, 255, 255, 0.06)',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', textTransform: 'uppercase', letterSpacing: '0.04em', fontWeight: 600 }}>
                Warning Signals
              </div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#FFB020', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>
                {warnCount}
              </div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                Pre-emptive monitoring
              </div>
            </div>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                backgroundColor: 'rgba(255, 176, 32, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#FFB020'
              }}
            >
              <AlertCircle size={18} />
            </div>
          </div>

          {/* Card 3: Avg Response Time */}
          <div
            style={{
              padding: '14px 18px',
              backgroundColor: 'rgba(14, 18, 24, 0.65)',
              border: '1px solid rgba(255, 255, 255, 0.06)',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', textTransform: 'uppercase', letterSpacing: '0.04em', fontWeight: 600 }}>
                Avg Response Time
              </div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#00D9FF', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>
                18.4s
              </div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                SLA &lt;60s (99.2% on target)
              </div>
            </div>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                backgroundColor: 'rgba(0, 217, 255, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#00D9FF'
              }}
            >
              <Clock size={18} />
            </div>
          </div>

          {/* Card 4: Resolved Today */}
          <div
            style={{
              padding: '14px 18px',
              backgroundColor: 'rgba(14, 18, 24, 0.65)',
              border: '1px solid rgba(255, 255, 255, 0.06)',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--dust)', textTransform: 'uppercase', letterSpacing: '0.04em', fontWeight: 600 }}>
                Resolved Today
              </div>
              <div style={{ fontSize: '1.35rem', fontWeight: 800, color: '#00D6A3', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>
                {resolvedCount}
              </div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--ash)', marginTop: '2px' }}>
                Audited &amp; closed compliance
              </div>
            </div>
            <div
              style={{
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                backgroundColor: 'rgba(0, 214, 163, 0.12)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#00D6A3'
              }}
            >
              <CheckCircle2 size={18} />
            </div>
          </div>
        </div>
      </div>
    </CommandLayout>
  );
}

export default AlertsPage;
