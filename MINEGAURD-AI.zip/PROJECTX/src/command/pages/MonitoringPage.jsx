import React, { useState, useEffect } from 'react';
import { Wifi, Signal } from 'lucide-react';
import { CommandLayout } from '../components/CommandLayout';
import { MetricStrip } from '../components/MetricStrip';
import { ChannelSelector } from '../components/ChannelSelector';
import { TelemetryCanvasWaveform } from '../components/TelemetryCanvasWaveform';
import { ChannelInspector } from '../components/ChannelInspector';
import { Esp32SetupModal } from '../components/Esp32SetupModal';
import { useSim } from '../sim/engine';
import { disconnectDevice } from '../../services/telemetryClient';

/**
 * ESP32 Wi-Fi Network Connectivity Bar
 *
 * Real Hardware Architecture:
 * ESP32 + sensors -> Wi-Fi -> MineGuard Backend -> React Frontend
 *
 * Distinct Connection Layers:
 * 1. MineGuard Backend: CONNECTED / OFFLINE
 * 2. ESP32 Wi-Fi: CONNECTED / WAITING FOR CONNECTION / STALE
 * 3. Sensor Telemetry: LIVE / WAITING FOR DATA / STALE
 */
function Esp32NetworkBar() {
  const { backendConnected, backendState, gatewayState, nodes, simulatorMode } = useSim();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [nowTime, setNowTime] = useState(() => Date.now());

  // Clock tick for real-time relative timestamps & stale detection
  useEffect(() => {
    const clock = setInterval(() => setNowTime(Date.now()), 1000);
    return () => clearInterval(clock);
  }, []);

  // Handle Disconnect Submission to backend
  const handleDisconnect = async () => {
    try {
      const data = await disconnectDevice();
      if (data && data.state) {
        useSim.getState().ingestDeviceStatus(data.state);
      }
    } catch (err) {
      console.warn('Disconnect error:', err);
    }
  };

  // Backend connection state: CONNECTED / OFFLINE / RECONNECTING
  const isBackendOnline = backendConnected;
  let backendLabel = 'OFFLINE';
  let backendColor = '#FF4D4D';
  if (backendConnected) {
    backendLabel = 'CONNECTED';
    backendColor = '#00D6A3';
  } else if (backendState === 'RECONNECTING' || backendState === 'CONNECTING') {
    backendLabel = 'RECONNECTING';
    backendColor = '#FFB020';
  }

  // Real Hardware Connected State (ONLY true when real physical hardware is connected, NEVER for simulator)
  const isHwConnected = isBackendOnline && !simulatorMode && Boolean(gatewayState.connected) && gatewayState.latestSource === 'hardware';

  // Check if simulated demo telemetry is active
  const isSimActive = isBackendOnline && !isHwConnected && (
    gatewayState.latestSource === 'simulator' ||
    Boolean(gatewayState.simulatorActive) ||
    Object.values(nodes).some((n) => n.isOnline && n.source === 'simulator')
  );

  // Stale connection analysis (STALE_TIMEOUT_MS = 5000)
  let isStale = false;
  let lastPacketDisplay = '—';
  let lastUpdateFormatted = '—';

  if (gatewayState.lastPacket) {
    const packetDate = new Date(gatewayState.lastPacket);
    const elapsedSec = Math.max(0, Math.floor((nowTime - packetDate.getTime()) / 1000));
    lastPacketDisplay = `${elapsedSec}s ago`;
    lastUpdateFormatted = packetDate.toLocaleTimeString();
    if (isHwConnected && elapsedSec >= 5) {
      isStale = true;
    }
  }

  // ESP32 device state: CONNECTED / STALE / WAITING / OFFLINE
  let esp32Label = 'OFFLINE';
  let esp32Color = '#FF4D4D';
  if (!backendConnected) {
    esp32Label = 'OFFLINE';
    esp32Color = '#FF4D4D';
  } else if (isHwConnected) {
    if (isStale) {
      esp32Label = 'STALE';
      esp32Color = '#FFB020';
    } else {
      esp32Label = 'CONNECTED';
      esp32Color = '#00D6A3';
    }
  } else if (isSimActive) {
    esp32Label = 'WAITING';
    esp32Color = '#FFB020';
  } else {
    esp32Label = 'OFFLINE';
    esp32Color = '#FF4D4D';
  }

  // Telemetry state: LIVE / DEMO · LIVE / WAITING
  let telemetryLabel = 'WAITING';
  let telemetryColor = 'var(--dust)';
  if (isHwConnected && !isStale && gatewayState.lastPacket) {
    telemetryLabel = 'LIVE';
    telemetryColor = '#00D6A3';
  } else if (isHwConnected && isStale) {
    telemetryLabel = 'STALE';
    telemetryColor = '#FFB020';
  } else if (isSimActive) {
    telemetryLabel = 'DEMO · LIVE';
    telemetryColor = '#00D9FF';
  }

  // Active reporting hardware details
  const reportingNodeId = gatewayState.latestNodeId || Object.keys(nodes).find((id) => nodes[id].isOnline && nodes[id].isRealHardware) || Object.keys(nodes).find((id) => nodes[id].isOnline) || 'N-01';
  const reportingNode = nodes[reportingNodeId] || {};
  const reportingDeviceId = gatewayState.latestDeviceId || reportingNode.deviceId || gatewayState.gateway || 'ESP32-GATEWAY-01';
  const reportingSource = (gatewayState.latestSource || reportingNode.source || (isSimActive ? 'SIMULATOR' : 'HARDWARE')).toUpperCase();

  // Visual status pill configurations
  let statusBadge = {
    text: 'ESP32 OFFLINE',
    color: '#FF4D4D',
    bgColor: 'rgba(255, 77, 77, 0.12)',
    borderColor: 'rgba(255, 77, 77, 0.35)'
  };
  let deviceSubtitle = 'No hardware telemetry received';

  if (!isBackendOnline) {
    statusBadge = {
      text: 'BACKEND OFFLINE',
      color: '#FF4D4D',
      bgColor: 'rgba(255, 77, 77, 0.14)',
      borderColor: 'rgba(255, 77, 77, 0.4)'
    };
    deviceSubtitle = 'Backend service unavailable';
  } else if (isHwConnected) {
    if (isStale) {
      statusBadge = {
        text: 'ESP32 STALE',
        color: '#FFB020',
        bgColor: 'rgba(255, 176, 32, 0.12)',
        borderColor: 'rgba(255, 176, 32, 0.35)'
      };
      deviceSubtitle = `Last hardware telemetry ${lastPacketDisplay}`;
    } else {
      statusBadge = {
        text: 'ESP32 CONNECTED',
        color: '#00D6A3',
        bgColor: 'rgba(0, 214, 163, 0.12)',
        borderColor: 'rgba(0, 214, 163, 0.35)'
      };
      deviceSubtitle = 'ESP32 CONNECTED · Active hardware telemetry';
    }
  } else if (isSimActive) {
    statusBadge = {
      text: 'DEMO STREAM ACTIVE',
      color: '#00D9FF',
      bgColor: 'rgba(0, 217, 255, 0.12)',
      borderColor: 'rgba(0, 217, 255, 0.35)'
    };
    deviceSubtitle = 'Simulated MineGuard telemetry stream (Hardware disconnected)';
  } else {
    statusBadge = {
      text: 'ESP32 OFFLINE',
      color: '#FF4D4D',
      bgColor: 'rgba(255, 77, 77, 0.12)',
      borderColor: 'rgba(255, 77, 77, 0.35)'
    };
    deviceSubtitle = 'No hardware telemetry received';
  }

  return (
    <>
      <div
        className="panel esp32-network-bar"
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          padding: '14px 18px',
          backgroundColor: 'rgba(7, 9, 14, 0.85)',
          border: !isBackendOnline
            ? '1px solid rgba(255, 77, 77, 0.35)'
            : isHwConnected
            ? isStale
              ? '1px solid rgba(255, 176, 32, 0.35)'
              : '1px solid rgba(0, 214, 163, 0.28)'
            : '1px solid rgba(22, 136, 181, 0.25)',
          borderRadius: '6px',
          boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.04)',
          backdropFilter: 'blur(8px)',
          boxSizing: 'border-box'
        }}
      >
        <style>
          {`
            @keyframes wifiPulse {
              0%, 100% { opacity: 1; }
              50% { opacity: 0.4; }
            }
            @media (max-width: 1024px) {
              .monitoring-telemetry-grid {
                grid-template-columns: 1fr !important;
              }
            }
            @media (max-width: 768px) {
              .esp32-network-bar-row {
                flex-direction: column !important;
                align-items: flex-start !important;
                gap: 8px !important;
              }
            }
          `}
        </style>

        {/* Top Row: Title, Subtitle, Status Pill, and Connect/Disconnect Actions */}
        <div
          className="esp32-network-bar-row"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '12px',
            minWidth: 0
          }}
        >
          {/* Left: Icon + Title & Subtitle */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0 }}>
            <div
              style={{
                width: '34px',
                height: '34px',
                borderRadius: '4px',
                backgroundColor: isHwConnected
                  ? isStale
                    ? 'rgba(255, 176, 32, 0.1)'
                    : 'rgba(0, 214, 163, 0.1)'
                  : !isBackendOnline
                  ? 'rgba(255, 77, 77, 0.1)'
                  : 'rgba(255, 176, 32, 0.08)',
                border: `1px solid ${
                  isHwConnected
                    ? isStale
                      ? 'rgba(255, 176, 32, 0.35)'
                      : 'rgba(0, 214, 163, 0.3)'
                    : !isBackendOnline
                    ? 'rgba(255, 77, 77, 0.35)'
                    : 'rgba(255, 176, 32, 0.25)'
                }`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: isHwConnected
                  ? isStale
                    ? '#FFB020'
                    : '#00D6A3'
                  : !isBackendOnline
                  ? '#FF4D4D'
                  : '#FFB020',
                flexShrink: 0
              }}
            >
              <Wifi size={17} />
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                <span
                  style={{
                    fontFamily: 'var(--font-ui)',
                    fontSize: '0.84rem',
                    fontWeight: 600,
                    letterSpacing: '0.05em',
                    color: '#FFFFFF'
                  }}
                >
                  ESP32 NETWORK CONNECTION
                </span>

                {/* Status Pill Badge */}
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '5px',
                    padding: '2px 8px',
                    borderRadius: '3px',
                    backgroundColor: statusBadge.bgColor,
                    border: `1px solid ${statusBadge.borderColor}`,
                    fontSize: '0.625rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 700,
                    color: statusBadge.color,
                    letterSpacing: '0.06em'
                  }}
                >
                  <span
                    style={{
                      width: '5px',
                      height: '5px',
                      borderRadius: '50%',
                      backgroundColor: statusBadge.color,
                      boxShadow: `0 0 6px ${statusBadge.color}`,
                      animation: isHwConnected && !isStale ? 'wifiPulse 2.5s ease-in-out infinite' : 'none'
                    }}
                  />
                  {statusBadge.text}
                </span>
              </div>

              <span
                style={{
                  fontFamily: 'var(--font-ui)',
                  fontSize: '0.71875rem',
                  color: !isBackendOnline ? '#FF4D4D' : 'var(--dust)',
                  letterSpacing: '0.01em'
                }}
              >
                {deviceSubtitle}
              </span>
            </div>
          </div>

          {/* Right: Connect / Disconnect Action Buttons */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            {!isHwConnected ? (
              <button
                onClick={() => setIsModalOpen(true)}
                className="cmd-btn"
                style={{
                  padding: '7px 16px',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  fontFamily: 'var(--font-mono)',
                  letterSpacing: '0.06em',
                  background: 'rgba(0, 217, 255, 0.14)',
                  border: '1px solid #00D9FF',
                  color: '#00D9FF',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 0 12px rgba(0, 217, 255, 0.18)',
                  transition: 'all 0.15s ease'
                }}
              >
                <Wifi size={13} />
                <span>Connect ESP32</span>
              </button>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <button
                  onClick={() => setIsModalOpen(true)}
                  className="cmd-btn"
                  style={{
                    padding: '6px 12px',
                    fontSize: '0.6875rem',
                    fontWeight: 600,
                    fontFamily: 'var(--font-mono)',
                    letterSpacing: '0.04em',
                    background: 'rgba(0, 217, 255, 0.08)',
                    border: '1px solid rgba(0, 217, 255, 0.35)',
                    color: '#00D9FF',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '5px'
                  }}
                >
                  <Wifi size={11} />
                  <span>CONFIGURE IP</span>
                </button>
                <button
                  onClick={handleDisconnect}
                  className="cmd-btn"
                  style={{
                    padding: '6px 12px',
                    fontSize: '0.6875rem',
                    fontWeight: 600,
                    fontFamily: 'var(--font-mono)',
                    letterSpacing: '0.04em',
                    background: 'rgba(255, 77, 77, 0.1)',
                    border: '1px solid rgba(255, 77, 77, 0.35)',
                    color: '#FF4D4D',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  DISCONNECT
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Middle Row 1: 3 Distinct Architecture Connection States */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: '10px',
            padding: '10px 14px',
            backgroundColor: 'rgba(10, 14, 22, 0.65)',
            border: '1px solid rgba(22, 136, 181, 0.2)',
            borderRadius: '5px'
          }}
        >
          {/* 1. MineGuard Backend */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
            <span style={{ fontSize: '0.625rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.06em' }}>
              1. MINEGUARD BACKEND
            </span>
            <span
              style={{
                fontSize: '0.75rem',
                fontFamily: 'var(--font-mono)',
                fontWeight: 700,
                color: backendColor,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: backendColor,
                  boxShadow: `0 0 6px ${backendColor}`
                }}
              />
              {backendLabel}
            </span>
          </div>

          {/* 2. ESP32 Wi-Fi / Device */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
            <span style={{ fontSize: '0.625rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.06em' }}>
              2. ESP32 WI-FI / DEVICE
            </span>
            <span
              style={{
                fontSize: '0.75rem',
                fontFamily: 'var(--font-mono)',
                fontWeight: 700,
                color: esp32Color,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: isHwConnected ? (isStale ? '#FFB020' : '#00D6A3') : 'transparent',
                  border: isHwConnected ? 'none' : `1.5px solid ${esp32Color}`,
                  boxShadow: isHwConnected ? `0 0 6px ${isStale ? '#FFB020' : '#00D6A3'}` : 'none'
                }}
              />
              {esp32Label}
            </span>
          </div>

          {/* 3. Sensor Telemetry */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
            <span style={{ fontSize: '0.625rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.06em' }}>
              3. SENSOR TELEMETRY
            </span>
            <span
              style={{
                fontSize: '0.75rem',
                fontFamily: 'var(--font-mono)',
                fontWeight: 700,
                color: telemetryColor,
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px'
              }}
            >
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: isHwConnected && !isStale && gatewayState.lastPacket ? '#00D6A3' : (isHwConnected && isStale ? '#FFB020' : 'transparent'),
                  border: isHwConnected && gatewayState.lastPacket ? 'none' : '1.5px solid var(--dust)',
                  boxShadow: isHwConnected && !isStale && gatewayState.lastPacket ? '0 0 6px #00D6A3' : 'none'
                }}
              />
              {telemetryLabel}
            </span>
          </div>
        </div>

        {/* Middle Row 2: Telemetry Metadata (Real Hardware or Explicit Demo Stream) */}
        {(isHwConnected || isSimActive) && (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
              gap: '8px',
              padding: '10px 14px',
              backgroundColor: isHwConnected ? 'rgba(0, 214, 163, 0.04)' : 'rgba(0, 217, 255, 0.04)',
              border: isHwConnected ? '1px solid rgba(0, 214, 163, 0.22)' : '1px solid rgba(0, 217, 255, 0.22)',
              borderRadius: '5px'
            }}
          >
            <div>
              <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}>NODE ID</span>
              <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', fontWeight: 700, color: '#00D9FF', marginTop: '1px' }}>
                {reportingNodeId}
              </div>
            </div>
            <div>
              <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}>DEVICE ID</span>
              <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', fontWeight: 600, color: '#FFFFFF', marginTop: '1px' }}>
                {reportingDeviceId}
              </div>
            </div>
            <div>
              <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}>LAST TELEMETRY</span>
              <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', fontWeight: 600, color: isHwConnected ? (isStale ? '#FFB020' : '#00D6A3') : '#00D9FF', marginTop: '1px' }}>
                {lastPacketDisplay}
              </div>
            </div>
            <div>
              <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}>
                {isHwConnected ? 'HARDWARE SOURCE' : 'TELEMETRY SOURCE'}
              </span>
              <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', fontWeight: 700, color: isHwConnected ? '#00D6A3' : '#00D9FF', marginTop: '1px' }}>
                {reportingSource}
              </div>
            </div>
            <div>
              <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}>LAST UPDATE</span>
              <div style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--chalk)', marginTop: '1px' }}>
                {lastUpdateFormatted}
              </div>
            </div>
          </div>
        )}

        {/* Bottom Row: Minimal Transmission Pipeline & Compact Metrics */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '12px',
            paddingTop: '8px',
            borderTop: '1px solid rgba(22, 136, 181, 0.15)'
          }}
        >
          {/* Architecture Pipeline Indicator: ESP32 ── Wi-Fi ── Backend ── Live Monitoring */}
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.6875rem',
              fontFamily: 'var(--font-mono)',
              color: 'var(--dust)'
            }}
          >
            <span style={{ color: isHwConnected ? '#FFFFFF' : 'var(--dust)', fontWeight: 600 }}>ESP32</span>
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: isHwConnected ? '#00D6A3' : 'rgba(255, 255, 255, 0.2)' }} />
            <span style={{ width: '16px', height: '1px', backgroundColor: isHwConnected ? 'rgba(0, 217, 255, 0.35)' : 'rgba(255, 255, 255, 0.1)' }} />
            <span style={{ color: isHwConnected ? '#00D9FF' : 'var(--dust)' }}>Wi-Fi</span>
            <span style={{ width: '16px', height: '1px', backgroundColor: isHwConnected ? 'rgba(0, 217, 255, 0.35)' : 'rgba(255, 255, 255, 0.1)' }} />
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: isBackendOnline ? '#00D6A3' : '#FF4D4D' }} />
            <span style={{ color: isBackendOnline ? '#FFFFFF' : '#FF4D4D', fontWeight: 500 }}>Backend</span>
            <span style={{ width: '16px', height: '1px', backgroundColor: isBackendOnline ? 'rgba(0, 217, 255, 0.35)' : 'rgba(255, 255, 255, 0.1)' }} />
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: isBackendOnline ? '#00D6A3' : 'rgba(255, 255, 255, 0.2)' }} />
            <span style={{ color: isBackendOnline ? '#00D6A3' : 'var(--dust)', fontWeight: 600 }}>Live Monitoring</span>
          </div>

          {/* Compact Network Information: Nodes Online · Signal · Last Packet */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '14px',
              flexWrap: 'wrap'
            }}
          >
            {/* Nodes Online */}
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '5px' }}>
              <span
                style={{
                  width: '5px',
                  height: '5px',
                  borderRadius: '50%',
                  backgroundColor: isHwConnected && gatewayState.nodesOnline > 0 ? '#00D6A3' : '#FFB020'
                }}
              />
              <span
                className="t-mono"
                style={{
                  fontSize: '0.6875rem',
                  fontWeight: 600,
                  color: isHwConnected && gatewayState.nodesOnline > 0 ? '#FFFFFF' : 'var(--dust)'
                }}
              >
                {isHwConnected ? gatewayState.nodesOnline : 0} / {gatewayState.totalNodes || 8} NODES ONLINE
              </span>
            </div>

            <span style={{ color: 'rgba(255, 255, 255, 0.15)' }}>|</span>

            {/* Signal */}
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
              <Signal size={12} color={isHwConnected && gatewayState.signal !== null ? '#00D9FF' : 'var(--dust)'} />
              <span
                className="t-mono"
                style={{
                  fontSize: '0.6875rem',
                  color: 'var(--dust)'
                }}
              >
                SIGNAL{' '}
                <span style={{ color: isHwConnected && gatewayState.signal !== null ? '#FFFFFF' : 'var(--dust)', fontWeight: 600 }}>
                  {isHwConnected && gatewayState.signal !== null ? `${gatewayState.signal}%` : '——'}
                </span>
              </span>
            </div>

            <span style={{ color: 'rgba(255, 255, 255, 0.15)' }}>|</span>

            {/* Last Packet */}
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
              <span
                className="t-mono"
                style={{
                  fontSize: '0.6875rem',
                  color: 'var(--dust)'
                }}
              >
                LAST PACKET:{' '}
                <span style={{ color: isHwConnected && gatewayState.lastPacket ? (isStale ? '#FFB020' : '#00D6A3') : 'var(--dust)', fontWeight: 600 }}>
                  {lastPacketDisplay}
                </span>
              </span>
            </div>

            {isHwConnected && (
              <>
                <span style={{ color: 'rgba(255, 255, 255, 0.15)' }}>|</span>
                <span
                  style={{
                    fontSize: '0.625rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 700,
                    padding: '1px 6px',
                    borderRadius: '3px',
                    backgroundColor: isStale ? 'rgba(255, 176, 32, 0.15)' : 'rgba(0, 214, 163, 0.15)',
                    color: isStale ? '#FFB020' : '#00D6A3',
                    letterSpacing: '0.08em'
                  }}
                >
                  {isStale ? 'STALE' : 'LIVE'}
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Professional ESP32 Setup & Wi-Fi Provisioning Modal */}
      <Esp32SetupModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
}

export function MonitoringPage() {
  const { nodes, selectedNodeId, setSelectedNode } = useSim();
  const [isPaused, setIsPaused] = useState(false);
  const [sharedCursor, setSharedCursor] = useState(null);

  // Default to N-01 if none selected
  useEffect(() => {
    if (!selectedNodeId) {
      setSelectedNode('N-01');
    }
  }, [selectedNodeId, setSelectedNode]);

  // CSV Telemetry Export Handler
  const handleExport = () => {
    const activeNode = nodes[selectedNodeId] || nodes['N-01'];
    const rows = [
      ['Timestamp', 'ISO_Time', 'Node_ID', 'Zone_ID', 'Convergence_cm', 'Tilt_deg', 'Delta_Rate_cm_s', 'Status']
    ];

    if (activeNode && activeNode.history) {
      activeNode.history.forEach((h) => {
        rows.push([
          h.timestamp,
          new Date(h.timestamp).toISOString(),
          activeNode.id,
          activeNode.zoneId,
          h.convergence,
          h.tilt,
          activeNode.deltaRate?.toFixed(3) || '0.000',
          activeNode.status
        ]);
      });
    }

    const csvContent =
      'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `telemetry_${selectedNodeId || 'N-01'}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activeNode = nodes[selectedNodeId] || nodes['N-01'];

  return (
    <CommandLayout>
      <div
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '20px 28px',
          display: 'flex',
          flexDirection: 'column',
          gap: '16px',
          boxSizing: 'border-box'
        }}
      >
        {/* Page Header: Eyebrow + Main Title + Subtitle */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                backgroundColor: '#00D9FF',
                boxShadow: '0 0 8px #00D9FF'
              }}
            />
            <span
              className="t-micro"
              style={{
                color: '#00D9FF',
                letterSpacing: '0.12em',
                fontSize: '0.6875rem',
                fontWeight: 600
              }}
            >
              01 — LIVE MONITORING
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'baseline', gap: '14px', flexWrap: 'wrap' }}>
            <h1
              style={{
                margin: 0,
                fontFamily: 'var(--font-ui)',
                fontSize: '1.65rem',
                fontWeight: 600,
                letterSpacing: '-0.01em',
                color: '#FFFFFF',
                lineHeight: 1.15
              }}
            >
              Live Monitoring
            </h1>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.8125rem',
                color: 'var(--dust)',
                letterSpacing: '0.01em'
              }}
            >
              Real-time data from underground monitoring stations
            </span>
          </div>
        </div>

        {/* ESP32 Wi-Fi Hardware Connectivity Bar */}
        <Esp32NetworkBar />

        {/* Top Metric Strip (4 cards) */}
        <MetricStrip />

        {/* Sensor Channel Selector + Time Range + Pause/Export controls */}
        <ChannelSelector
          isPaused={isPaused}
          onTogglePause={() => setIsPaused(!isPaused)}
          onExport={handleExport}
        />

        {/* Main Telemetry Area (Waveform Hero Stack + Right Channel Inspector) */}
        <div
          className="monitoring-telemetry-grid"
          style={{
            display: 'grid',
            gridTemplateColumns: 'minmax(0, 1fr) 320px',
            gap: '16px',
            alignItems: 'start'
          }}
        >
          {/* Left Column: 3 Stacked Telemetry Waveforms */}
          <div
            style={{
              position: 'relative',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
              minWidth: 0
            }}
          >
            {/* Synchronized Crosshair Floating Tooltip (Reference-Style) */}
            {sharedCursor && (
              <div
                style={{
                  position: 'fixed',
                  left: Math.min(window.innerWidth - 220, sharedCursor.clientX + 16),
                  top: Math.max(80, sharedCursor.clientY - 40),
                  zIndex: 80,
                  backgroundColor: 'rgba(7, 8, 11, 0.94)',
                  border: '1px solid #FFB020',
                  borderRadius: '4px',
                  padding: '8px 12px',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.8), 0 0 12px rgba(255, 176, 32, 0.25)',
                  pointerEvents: 'none',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '4px',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.6875rem'
                }}
              >
                <div style={{ color: 'var(--ash)', borderBottom: '1px solid rgba(255,255,255,0.08)', paddingBottom: '3px' }}>
                  {new Date(sharedCursor.timestamp).toTimeString().split(' ')[0]}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '16px' }}>
                  <span style={{ color: '#FFB020', fontWeight: 600 }}>{selectedNodeId || 'N-04'}</span>
                  <span style={{ color: '#FFFFFF' }}>{sharedCursor.sampleVal}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '16px' }}>
                  <span style={{ color: 'var(--dust)' }}>Threshold</span>
                  <span style={{ color: '#FFB020' }}>{sharedCursor.thresholdDisplay}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: '16px' }}>
                  <span style={{ color: 'var(--dust)' }}>&Delta; rate</span>
                  <span style={{ color: '#00D6A3' }}>
                    {activeNode?.deltaRate > 0
                      ? `+${activeNode.deltaRate.toFixed(3)}`
                      : (activeNode?.deltaRate || 0.003).toFixed(3)}{' '}
                    cm/s
                  </span>
                </div>
              </div>
            )}

            {/* 1. CONVERGENCE Panel */}
            <TelemetryCanvasWaveform
              panelId="conv"
              title="CONVERGENCE"
              unit="cm"
              metricType="convergence"
              thresholdDisplay="±3.00 cm"
              thresholdNumeric={17.0}
              thresholdNumericCrit={15.0}
              allNodes={nodes}
              selectedNodeId={selectedNodeId || 'N-01'}
              isPaused={isPaused}
              sharedCursor={sharedCursor}
              setSharedCursor={setSharedCursor}
            />

            {/* 2. TILT ANGLE Panel */}
            <TelemetryCanvasWaveform
              panelId="tilt"
              title="TILT ANGLE"
              unit="degrees (°)"
              metricType="tilt"
              thresholdDisplay="±2.50°"
              thresholdNumeric={2.0}
              thresholdNumericCrit={3.0}
              allNodes={nodes}
              selectedNodeId={selectedNodeId || 'N-01'}
              isPaused={isPaused}
              sharedCursor={sharedCursor}
              setSharedCursor={setSharedCursor}
            />

            {/* 3. DELTA RATE Panel */}
            <TelemetryCanvasWaveform
              panelId="delta"
              title="DELTA RATE"
              unit="cm/s"
              metricType="delta"
              thresholdDisplay="±0.030 cm/s"
              thresholdNumeric={0.02}
              allNodes={nodes}
              selectedNodeId={selectedNodeId || 'N-01'}
              isPaused={isPaused}
              sharedCursor={sharedCursor}
              setSharedCursor={setSharedCursor}
            />
          </div>

          {/* Right Column: Selected-Channel Inspector */}
          <ChannelInspector />
        </div>
      </div>
    </CommandLayout>
  );
}
export default MonitoringPage;
