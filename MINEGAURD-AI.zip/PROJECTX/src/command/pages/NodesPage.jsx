import React, { useState, useMemo } from 'react';
import { CommandLayout } from '../components/CommandLayout';
import { useRouter } from '../../router/Router';
import { Sparkline } from '../viz/ChartPrimitives';
import { useSim } from '../sim/engine';
import {
  Search,
  ArrowUpDown,
  Activity,
  Radio,
  Cpu,
  ExternalLink,
  X,
  Sliders,
  RotateCw
} from 'lucide-react';

/**
 * Standard location metadata mapping for mine sensor nodes.
 */
const NODE_LOCATIONS = {
  'N-01': { tunnel: 'Tunnel A', section: 'Section 1 - Haulage Entry', depth: '320m' },
  'N-02': { tunnel: 'Tunnel A', section: 'Section 2 - Portal Cross-Cut', depth: '320m' },
  'N-03': { tunnel: 'Tunnel B', section: 'Section 3 - Central Junction', depth: '380m' },
  'N-04': { tunnel: 'Tunnel B', section: 'Section 4 - Support Pillar East', depth: '380m' },
  'N-05': { tunnel: 'Tunnel C', section: 'Section 1 - Ventilation Incline', depth: '410m' },
  'N-06': { tunnel: 'Tunnel D', section: 'Section 2 - South Access', depth: '460m' },
  'N-07': { tunnel: 'Tunnel D', section: 'Section 1 - Active Longwall Face', depth: '460m' },
  'N-08': { tunnel: 'Tunnel C', section: 'Section 2 - Hydraulic Roof Shield', depth: '410m' }
};

export function NodesPage() {
  const {
    nodes,
    selectedNodeId,
    setSelectedNode,
    calibrateNode,
    restartNode,
    gatewayState
  } = useSim();

  const { navigate } = useRouter();

  // Search, Filter, Sort, and Modal States
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL'); // 'ALL' | 'NORMAL' | 'WARNING' | 'CRITICAL'
  const [sortBy, setSortBy] = useState('risk-desc'); // 'risk-desc' | 'risk-asc' | 'id-asc' | 'health-desc' | 'displacement-desc' | 'vibration-desc'
  const [detailModalNodeId, setDetailModalNodeId] = useState(null);
  const [actionFeedback, setActionFeedback] = useState('');

  const nodeEntries = useMemo(() => Object.keys(nodes).map((id) => nodes[id]), [nodes]);

  // Derived Fleet Summary Counts from actual backend status
  const totalCount = gatewayState?.totalNodes || nodeEntries.length;
  const criticalCount = nodeEntries.filter(
    (n) => (n.status || '').toLowerCase() === 'critical'
  ).length;
  const warningCount = nodeEntries.filter(
    (n) => (n.status || '').toLowerCase() === 'warning'
  ).length;
  const normalCount = nodeEntries.filter(
    (n) => (n.status || '').toLowerCase() === 'normal' || (n.status || '').toLowerCase() === 'nominal' || (n.status || '').toLowerCase() === 'online'
  ).length;

  const onlineCount = gatewayState?.connected ? gatewayState.nodesOnline : nodeEntries.filter((n) => n.isOnline).length;
  const onlinePct = totalCount > 0 ? Math.round((onlineCount / totalCount) * 100) : 0;

  const avgHealth = useMemo(() => {
    if (totalCount === 0) return '97.3';
    const sum = nodeEntries.reduce((acc, n) => acc + (n.sensorHealth || n.battery || 95), 0);
    return (sum / totalCount).toFixed(1);
  }, [nodeEntries, totalCount]);

  // Handle hardware actions
  const handleAction = (type, nodeId) => {
    if (type === 'calibrate') {
      calibrateNode(nodeId);
      setActionFeedback(`Node ${nodeId} zero-datum recalibrated against laser baseline.`);
    } else if (type === 'restart') {
      restartNode(nodeId);
      setActionFeedback(`Node ${nodeId} warm boot packet dispatched over LoRa mesh.`);
    }
    setTimeout(() => setActionFeedback(''), 4000);
  };

  // Filtered & Sorted Node List
  const processedNodes = useMemo(() => {
    return nodeEntries
      .filter((node) => {
        // Status matching
        const isCrit = (node.status || '').toLowerCase() === 'critical';
        const isWarn = (node.status || '').toLowerCase() === 'warning';
        const isNorm = !isCrit && !isWarn;

        if (statusFilter === 'NORMAL' && !isNorm) return false;
        if (statusFilter === 'WARNING' && !isWarn) return false;
        if (statusFilter === 'CRITICAL' && !isCrit) return false;

        // Search matching
        if (searchTerm.trim()) {
          const term = searchTerm.toLowerCase();
          const loc = NODE_LOCATIONS[node.id];
          const matchesId = node.id.toLowerCase().includes(term);
          const matchesTunnel = loc?.tunnel?.toLowerCase().includes(term);
          const matchesSection = loc?.section?.toLowerCase().includes(term);
          const matchesDepth = loc?.depth?.toLowerCase().includes(term);
          if (!matchesId && !matchesTunnel && !matchesSection && !matchesDepth) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        const aCrit = (a.status || '').toLowerCase() === 'critical';
        const bCrit = (b.status || '').toLowerCase() === 'critical';
        const aWarn = (a.status || '').toLowerCase() === 'warning';
        const bWarn = (b.status || '').toLowerCase() === 'warning';

        const aRisk = a.strataRisk ?? (aCrit ? 91 : aWarn ? 54 : 0);
        const bRisk = b.strataRisk ?? (bCrit ? 91 : bWarn ? 54 : 0);

        if (sortBy === 'risk-desc') return bRisk - aRisk;
        if (sortBy === 'risk-asc') return aRisk - bRisk;
        if (sortBy === 'id-asc') return a.id.localeCompare(b.id);
        if (sortBy === 'health-desc') return (b.sensorHealth || b.battery || 0) - (a.sensorHealth || a.battery || 0);
        if (sortBy === 'displacement-desc') return (b.displacement || 0) - (a.displacement || 0);
        if (sortBy === 'vibration-desc') return (b.vibration || 0) - (a.vibration || 0);
        return 0;
      });
  }, [nodeEntries, statusFilter, searchTerm, sortBy]);

  // Active detail modal node
  const activeModalNode = detailModalNodeId ? nodes[detailModalNodeId] : null;
  const activeModalLoc = detailModalNodeId ? NODE_LOCATIONS[detailModalNodeId] : null;

  // Format timestamp helper
  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'Just now';
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  return (
    <CommandLayout>
      <div
        className="sensor-fleet-page-container"
        style={{
          position: 'relative',
          zIndex: 10,
          padding: '24px 28px 48px',
          display: 'flex',
          flexDirection: 'column',
          gap: '20px',
          boxSizing: 'border-box',
          maxWidth: '1680px',
          margin: '0 auto',
          width: '100%'
        }}
      >
        {/* ============================================================ */}
        {/* 1. PAGE HEADER & BANNER                                     */}
        {/* ============================================================ */}
        <div
          style={{
            position: 'relative',
            borderRadius: '8px',
            padding: '22px 26px',
            background: 'linear-gradient(135deg, rgba(8, 12, 18, 0.95) 0%, rgba(14, 20, 28, 0.9) 100%)',
            border: '1px solid rgba(22, 136, 181, 0.28)',
            boxShadow: '0 8px 24px rgba(0, 0, 0, 0.45)',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            overflow: 'hidden'
          }}
        >
          {/* Subtle Cyber Accent Line at top */}
          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '2px',
              background: 'linear-gradient(90deg, #00D9FF 0%, rgba(0, 217, 255, 0.2) 60%, transparent 100%)'
            }}
          />

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span
                style={{
                  width: '7px',
                  height: '7px',
                  borderRadius: '50%',
                  backgroundColor: '#00D9FF',
                  boxShadow: '0 0 10px #00D9FF'
                }}
              />
              <span
                className="t-micro"
                style={{
                  color: '#00D9FF',
                  letterSpacing: '0.12em',
                  fontSize: '0.6875rem',
                  fontWeight: 600
                }}
              >
                05 — SENSOR FLEET
              </span>
            </div>

            {/* Hardware Telemetry Badge */}
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '4px 10px',
                borderRadius: '4px',
                backgroundColor: 'rgba(22, 136, 181, 0.12)',
                border: '1px solid rgba(0, 217, 255, 0.22)',
                fontSize: '0.6875rem',
                fontFamily: 'var(--font-mono)',
                color: 'var(--dust)'
              }}
            >
              <Cpu size={13} color="#00D9FF" />
              <span>ESP32 + SX1262 LoRa sensor nodes</span>
              <span style={{ color: 'rgba(255, 255, 255, 0.2)' }}>|</span>
              <Radio size={13} color="#00D6A3" />
              <span style={{ color: '#00D6A3' }}>868 MHz Mesh Active</span>
            </div>
          </div>

          <h1
            style={{
              margin: 0,
              fontFamily: 'var(--font-ui)',
              fontSize: '1.75rem',
              fontWeight: 600,
              letterSpacing: '-0.015em',
              color: '#FFFFFF',
              lineHeight: 1.15
            }}
          >
            Sensor Fleet Management
          </h1>

          <p
            style={{
              margin: 0,
              fontFamily: 'var(--font-ui)',
              fontSize: '0.84rem',
              color: 'var(--dust)',
              letterSpacing: '0.01em',
              maxWidth: '840px',
              lineHeight: 1.45
            }}
          >
            Hardware configuration, sensor health, and real-time telemetry across deployed mine monitoring nodes.
          </p>
        </div>

        {/* Action Feedback Toast */}
        {actionFeedback && (
          <div
            style={{
              padding: '10px 16px',
              backgroundColor: 'rgba(0, 217, 255, 0.12)',
              border: '1px solid #00D9FF',
              borderRadius: '5px',
              color: '#00D9FF',
              fontSize: '0.75rem',
              fontFamily: 'var(--font-mono)',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              animation: 'fadeIn 0.2s ease-in-out'
            }}
          >
            <Activity size={14} />
            <span>{actionFeedback}</span>
          </div>
        )}

        {/* ============================================================ */}
        {/* 2. SUMMARY CARDS (DYNAMIC METRICS)                          */}
        {/* ============================================================ */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '12px'
          }}
        >
          {/* Card 1: Fleet Nodes Deployed */}
          <div
            className="panel"
            style={{
              padding: '16px 18px',
              backgroundColor: 'rgba(7, 9, 14, 0.9)',
              border: '1px solid rgba(22, 136, 181, 0.24)',
              borderRadius: '6px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)'
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '2rem',
                fontWeight: 700,
                color: '#FFFFFF',
                lineHeight: 1
              }}
            >
              {totalCount}
            </span>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em',
                color: 'var(--dust)'
              }}
            >
              FLEET NODES DEPLOYED
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: onlinePct === 100 ? '#00D6A3' : '#FFB020'
                }}
              />
              <span
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.71875rem',
                  color: onlinePct === 100 ? '#00D6A3' : '#FFB020'
                }}
              >
                {onlinePct}% Online
              </span>
            </div>
          </div>

          {/* Card 2: Normal Operational */}
          <div
            className="panel"
            style={{
              padding: '16px 18px',
              backgroundColor: 'rgba(7, 9, 14, 0.9)',
              border: '1px solid rgba(0, 214, 163, 0.25)',
              borderRadius: '6px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)'
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '2rem',
                fontWeight: 700,
                color: '#00D6A3',
                lineHeight: 1
              }}
            >
              {normalCount}
            </span>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em',
                color: 'var(--dust)'
              }}
            >
              NORMAL OPERATIONAL
            </span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.71875rem',
                color: 'var(--ash)',
                marginTop: '4px'
              }}
            >
              Nodes
            </span>
          </div>

          {/* Card 3: Elevated / Warning */}
          <div
            className="panel"
            style={{
              padding: '16px 18px',
              backgroundColor: 'rgba(7, 9, 14, 0.9)',
              border: '1px solid rgba(255, 176, 32, 0.28)',
              borderRadius: '6px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)'
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '2rem',
                fontWeight: 700,
                color: '#FFB020',
                lineHeight: 1
              }}
            >
              {warningCount}
            </span>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em',
                color: 'var(--dust)'
              }}
            >
              ELEVATED / WARNING
            </span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.71875rem',
                color: 'var(--ash)',
                marginTop: '4px'
              }}
            >
              Nodes
            </span>
          </div>

          {/* Card 4: Critical Hazard */}
          <div
            className="panel"
            style={{
              padding: '16px 18px',
              backgroundColor: 'rgba(7, 9, 14, 0.9)',
              border: '1px solid rgba(255, 77, 77, 0.32)',
              borderRadius: '6px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)'
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '2rem',
                fontWeight: 700,
                color: '#FF4D4D',
                lineHeight: 1
              }}
            >
              {criticalCount}
            </span>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em',
                color: 'var(--dust)'
              }}
            >
              CRITICAL HAZARD
            </span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.71875rem',
                color: 'var(--ash)',
                marginTop: '4px'
              }}
            >
              Nodes
            </span>
          </div>

          {/* Card 5: Sensor Health Avg */}
          <div
            className="panel"
            style={{
              padding: '16px 18px',
              backgroundColor: 'rgba(7, 9, 14, 0.9)',
              border: '1px solid rgba(0, 217, 255, 0.28)',
              borderRadius: '6px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)'
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '2rem',
                fontWeight: 700,
                color: '#00D9FF',
                lineHeight: 1
              }}
            >
              {avgHealth}%
            </span>
            <span
              style={{
                fontFamily: 'var(--font-ui)',
                fontSize: '0.6875rem',
                fontWeight: 600,
                letterSpacing: '0.08em',
                color: 'var(--dust)'
              }}
            >
              SENSOR HEALTH AVG
            </span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.71875rem',
                color: '#00D6A3',
                marginTop: '4px'
              }}
            >
              ↑ +2.1% vs last 24h
            </span>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 3. TOOLBAR: STATUS FILTERS + SEARCH + SORTING               */}
        {/* ============================================================ */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: '14px',
            backgroundColor: 'rgba(7, 9, 14, 0.85)',
            border: '1px solid rgba(22, 136, 181, 0.22)',
            borderRadius: '6px',
            padding: '10px 14px'
          }}
        >
          {/* Status Filter Tabs with Counts */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
            {[
              { id: 'ALL', label: 'ALL NODES', count: totalCount },
              { id: 'NORMAL', label: 'NORMAL', count: normalCount },
              { id: 'WARNING', label: 'WARNING', count: warningCount },
              { id: 'CRITICAL', label: 'CRITICAL', count: criticalCount }
            ].map((tab) => {
              const isActive = statusFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id)}
                  className="cmd-btn"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '7px',
                    padding: '6px 12px',
                    borderRadius: '4px',
                    fontSize: '0.6875rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 600,
                    cursor: 'pointer',
                    background: isActive ? 'rgba(0, 217, 255, 0.16)' : 'rgba(15, 19, 25, 0.6)',
                    border: isActive ? '1px solid #00D9FF' : '1px solid rgba(22, 136, 181, 0.2)',
                    color: isActive ? '#00D9FF' : 'var(--dust)',
                    transition: 'all 0.15s ease'
                  }}
                >
                  <span>{tab.label}</span>
                  <span
                    style={{
                      padding: '1px 5px',
                      borderRadius: '3px',
                      backgroundColor: isActive ? 'rgba(0, 217, 255, 0.25)' : 'rgba(255, 255, 255, 0.08)',
                      fontSize: '0.625rem',
                      color: isActive ? '#FFFFFF' : 'var(--ash)'
                    }}
                  >
                    {tab.count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search + Sort Controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            {/* Search Input */}
            <div
              style={{
                position: 'relative',
                display: 'flex',
                alignItems: 'center'
              }}
            >
              <Search
                size={14}
                style={{
                  position: 'absolute',
                  left: '10px',
                  color: 'var(--dust)',
                  pointerEvents: 'none'
                }}
              />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by Node ID, Tunnel, or Location..."
                style={{
                  padding: '7px 12px 7px 32px',
                  backgroundColor: 'rgba(12, 15, 20, 0.95)',
                  border: '1px solid rgba(22, 136, 181, 0.25)',
                  borderRadius: '4px',
                  color: '#FFFFFF',
                  fontSize: '0.75rem',
                  fontFamily: 'var(--font-ui)',
                  outline: 'none',
                  minWidth: '260px',
                  transition: 'border-color 0.15s ease'
                }}
                onFocus={(e) => (e.target.style.borderColor = '#00D9FF')}
                onBlur={(e) => (e.target.style.borderColor = 'rgba(22, 136, 181, 0.25)')}
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  style={{
                    position: 'absolute',
                    right: '8px',
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--dust)',
                    cursor: 'pointer',
                    padding: 0,
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  <X size={13} />
                </button>
              )}
            </div>

            {/* Sorting Dropdown */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <ArrowUpDown size={13} color="var(--dust)" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                style={{
                  padding: '7px 12px',
                  backgroundColor: 'rgba(12, 15, 20, 0.95)',
                  border: '1px solid rgba(22, 136, 181, 0.25)',
                  borderRadius: '4px',
                  color: 'var(--dust)',
                  fontSize: '0.75rem',
                  fontFamily: 'var(--font-mono)',
                  outline: 'none',
                  cursor: 'pointer'
                }}
              >
                <option value="risk-desc">Highest Risk</option>
                <option value="risk-asc">Lowest Risk</option>
                <option value="id-asc">Node ID</option>
                <option value="health-desc">Sensor Health</option>
                <option value="displacement-desc">Displacement (Highest)</option>
                <option value="vibration-desc">Vibration (Highest)</option>
              </select>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 4. MAIN NODE FLEET DATA TABLE (DESKTOP)                      */}
        {/* ============================================================ */}
        <div
          className="desktop-fleet-table-container"
          style={{
            backgroundColor: 'rgba(6, 8, 12, 0.9)',
            border: '1px solid rgba(22, 136, 181, 0.25)',
            borderRadius: '6px',
            overflowX: 'auto',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.45)'
          }}
        >
          <table
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              textAlign: 'left',
              fontSize: '0.8125rem',
              fontFamily: 'var(--font-ui)',
              minWidth: '960px'
            }}
          >
            <thead>
              <tr
                style={{
                  borderBottom: '1px solid rgba(22, 136, 181, 0.25)',
                  backgroundColor: 'rgba(12, 16, 23, 0.95)'
                }}
              >
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>NODE</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>LOCATION</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>STATUS</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>RISK SCORE</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>DISPLACEMENT</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>VIBRATION</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>SENSOR HEALTH</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>TREND (24H)</th>
                <th style={{ padding: '12px 16px', fontSize: '0.6875rem', fontFamily: 'var(--font-mono)', color: 'var(--dust)', letterSpacing: '0.08em', fontWeight: 600 }}>LAST UPDATE</th>
              </tr>
            </thead>
            <tbody>
              {processedNodes.length === 0 ? (
                <tr>
                  <td colSpan={9} style={{ padding: '36px', textAlign: 'center', color: 'var(--dust)' }}>
                    No sensor nodes found matching current filters.
                  </td>
                </tr>
              ) : (
                processedNodes.map((node) => {
                  const isSelected = selectedNodeId === node.id;
                  const rawStatus = (node.status || 'OFFLINE').toUpperCase();
                  const isCrit = rawStatus === 'CRITICAL';
                  const isWarn = rawStatus === 'WARNING';
                  const isStale = rawStatus === 'STALE';
                  const isOnline = node.isOnline;
                  const statusCol = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : isStale ? '#FFB020' : isOnline ? '#00D6A3' : '#6B7280';
                  const statusText = isCrit ? 'CRITICAL' : isWarn ? 'WARNING' : isStale ? 'STALE' : isOnline ? 'ONLINE' : 'OFFLINE';

                  const loc = NODE_LOCATIONS[node.id] || { tunnel: 'Tunnel A', section: 'Main Section', depth: '320m' };
                  const riskScore = node.strataRisk !== null && node.strataRisk !== undefined ? node.strataRisk : (isCrit ? 91 : isWarn ? 54 : 0);
                  const healthScore = node.sensorHealth || node.battery || 95;
                  const displacementStr = node.displacement !== null && node.displacement !== undefined ? `${node.displacement.toFixed(2)} mm` : 'N/A';
                  const vibrationStr = node.vibration !== null && node.vibration !== undefined ? `${node.vibration.toFixed(2)} mm/s` : 'N/A';

                  return (
                    <tr
                      key={node.id}
                      onClick={() => {
                        setSelectedNode(node.id);
                        setDetailModalNodeId(node.id);
                      }}
                      style={{
                        borderBottom: '1px solid rgba(22, 136, 181, 0.12)',
                        backgroundColor: isCrit
                          ? 'rgba(255, 77, 77, 0.04)'
                          : isSelected
                          ? 'rgba(0, 217, 255, 0.04)'
                          : 'transparent',
                        cursor: 'pointer',
                        transition: 'background-color 0.15s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = isCrit
                          ? 'rgba(255, 77, 77, 0.08)'
                          : 'rgba(0, 217, 255, 0.06)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = isCrit
                          ? 'rgba(255, 77, 77, 0.04)'
                          : isSelected
                          ? 'rgba(0, 217, 255, 0.04)'
                          : 'transparent';
                      }}
                    >
                      {/* NODE ID */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span
                            style={{
                              width: '7px',
                              height: '7px',
                              borderRadius: '50%',
                              backgroundColor: statusCol,
                              boxShadow: `0 0 6px ${statusCol}`
                            }}
                          />
                          <span
                            className="t-mono"
                            style={{
                              fontSize: '0.9375rem',
                              fontWeight: 700,
                              color: '#FFFFFF'
                            }}
                          >
                            {node.id}
                          </span>
                          <span
                            style={{
                              fontSize: '0.625rem',
                              fontFamily: 'var(--font-mono)',
                              color: 'var(--dust)',
                              backgroundColor: 'rgba(255, 255, 255, 0.05)',
                              padding: '1px 5px',
                              borderRadius: '3px'
                            }}
                          >
                            {node.fw || 'v2.4.1'}
                          </span>
                        </div>
                      </td>

                      {/* LOCATION (Tunnel, Section, Depth) */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                          <span style={{ fontWeight: 600, color: '#FFFFFF', fontSize: '0.8125rem' }}>
                            {loc.tunnel}
                          </span>
                          <span style={{ color: 'var(--dust)', fontSize: '0.71875rem' }}>
                            {loc.section}
                          </span>
                          <span className="t-mono" style={{ color: 'var(--ash)', fontSize: '0.6875rem' }}>
                            {loc.depth}
                          </span>
                        </div>
                      </td>

                      {/* STATUS */}
                      <td style={{ padding: '14px 16px' }}>
                        <span
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '5px',
                            padding: '3px 8px',
                            borderRadius: '3px',
                            fontSize: '0.6875rem',
                            fontFamily: 'var(--font-mono)',
                            fontWeight: 700,
                            color: statusCol,
                            backgroundColor: `${statusCol}16`,
                            border: `1px solid ${statusCol}33`
                          }}
                        >
                          <span style={{ width: '5px', height: '5px', borderRadius: '50%', backgroundColor: statusCol }} />
                          {statusText}
                        </span>
                      </td>

                      {/* RISK SCORE */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', maxWidth: '100px' }}>
                          <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px' }}>
                            <span
                              className="t-mono"
                              style={{
                                fontSize: '0.9375rem',
                                fontWeight: 700,
                                color: isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : '#FFFFFF'
                              }}
                            >
                              {riskScore}
                            </span>
                            <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--ash)' }}>
                              / 100
                            </span>
                          </div>
                          {/* Mini Progress Bar */}
                          <div style={{ height: '3px', width: '100%', backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: '2px', overflow: 'hidden' }}>
                            <div
                              style={{
                                height: '100%',
                                width: `${Math.min(100, riskScore)}%`,
                                backgroundColor: statusCol,
                                borderRadius: '2px'
                              }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* DISPLACEMENT */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                          <span
                            className="t-mono"
                            style={{
                              fontSize: '0.875rem',
                              fontWeight: 600,
                              color: isCrit ? '#FF4D4D' : '#FFFFFF'
                            }}
                          >
                            {displacementStr}
                          </span>
                          <span className="t-mono" style={{ fontSize: '0.6875rem', color: isCrit ? '#FF4D4D' : 'var(--dust)' }}>
                            {node.displacementTrend || (isCrit ? '↑ 12%' : '→ 0%')}
                          </span>
                        </div>
                      </td>

                      {/* VIBRATION */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                          <span
                            className="t-mono"
                            style={{
                              fontSize: '0.875rem',
                              fontWeight: 600,
                              color: isCrit ? '#FF4D4D' : '#FFFFFF'
                            }}
                          >
                            {vibrationStr}
                          </span>
                          <span className="t-mono" style={{ fontSize: '0.6875rem', color: isCrit ? '#FF4D4D' : 'var(--dust)' }}>
                            {node.vibrationTrend || (isCrit ? '↑ 18%' : '→ 0%')}
                          </span>
                        </div>
                      </td>

                      {/* SENSOR HEALTH */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span
                            className="t-mono"
                            style={{
                              fontSize: '0.875rem',
                              fontWeight: 600,
                              color: healthScore < 85 ? '#FFB020' : '#00D6A3'
                            }}
                          >
                            {healthScore}%
                          </span>
                        </div>
                      </td>

                      {/* TREND (24H) SPARKLINE */}
                      <td style={{ padding: '14px 16px' }}>
                        <div style={{ width: '90px' }}>
                          <Sparkline
                            data={node.history}
                            dataKey="convergence"
                            width={90}
                            height={22}
                            stroke={statusCol}
                            strokeWidth={1.4}
                          />
                        </div>
                      </td>

                      {/* LAST UPDATE */}
                      <td style={{ padding: '14px 16px' }}>
                        <span className="t-mono" style={{ fontSize: '0.75rem', color: 'var(--dust)' }}>
                          {formatTimestamp(node.lastSeen)}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* ============================================================ */}
        {/* 5. RESPONSIVE MOBILE NODE CARDS (NARROW SCREENS)            */}
        {/* ============================================================ */}
        <div
          className="mobile-fleet-cards-container"
          style={{
            display: 'none',
            flexDirection: 'column',
            gap: '12px'
          }}
        >
          {processedNodes.map((node) => {
            const rawStatus = (node.status || 'OFFLINE').toUpperCase();
            const isCrit = rawStatus === 'CRITICAL';
            const isWarn = rawStatus === 'WARNING';
            const isStale = rawStatus === 'STALE';
            const isOnline = node.isOnline;
            const statusCol = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : isStale ? '#FFB020' : isOnline ? '#00D6A3' : '#6B7280';
            const statusText = isCrit ? 'CRITICAL' : isWarn ? 'WARNING' : isStale ? 'STALE' : isOnline ? 'ONLINE' : 'OFFLINE';

            const loc = NODE_LOCATIONS[node.id] || { tunnel: 'Tunnel A', section: 'Main Section', depth: '320m' };
            const riskScore = node.strataRisk !== null && node.strataRisk !== undefined ? node.strataRisk : (isCrit ? 91 : isWarn ? 54 : 0);
            const healthScore = node.sensorHealth || node.battery || 95;

            return (
              <div
                key={`mob-${node.id}`}
                className="panel"
                style={{
                  padding: '14px 16px',
                  backgroundColor: 'rgba(7, 9, 14, 0.95)',
                  border: isCrit ? '1px solid rgba(255, 77, 77, 0.4)' : '1px solid rgba(22, 136, 181, 0.22)',
                  borderRadius: '6px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '10px'
                }}
              >
                {/* Top Row: Node ID + Status */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: statusCol }} />
                    <span className="t-mono" style={{ fontSize: '1rem', fontWeight: 700, color: '#FFFFFF' }}>
                      {node.id}
                    </span>
                    <span style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
                      {loc.tunnel} · {loc.depth}
                    </span>
                  </div>
                  <span
                    style={{
                      fontSize: '0.6875rem',
                      fontFamily: 'var(--font-mono)',
                      fontWeight: 700,
                      color: statusCol,
                      backgroundColor: `${statusCol}16`,
                      padding: '2px 6px',
                      borderRadius: '3px'
                    }}
                  >
                    {statusText}
                  </span>
                </div>

                {/* Section Name */}
                <span style={{ fontSize: '0.75rem', color: 'var(--dust)' }}>
                  {loc.section}
                </span>

                {/* Key Metrics Grid */}
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(4, 1fr)',
                    gap: '6px',
                    backgroundColor: 'rgba(15, 19, 25, 0.6)',
                    padding: '8px 10px',
                    borderRadius: '4px'
                  }}
                >
                  <div>
                    <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.5625rem' }}>RISK</span>
                    <div className="t-mono" style={{ fontSize: '0.8125rem', fontWeight: 700, color: isCrit ? '#FF4D4D' : '#FFFFFF' }}>
                      {riskScore}/100
                    </div>
                  </div>
                  <div>
                    <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.5625rem' }}>DISP</span>
                    <div className="t-mono" style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#FFFFFF' }}>
                      {(node.displacement || 0).toFixed(1)}mm
                    </div>
                  </div>
                  <div>
                    <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.5625rem' }}>VIB</span>
                    <div className="t-mono" style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#FFFFFF' }}>
                      {(node.vibration || 0).toFixed(1)}
                    </div>
                  </div>
                  <div>
                    <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.5625rem' }}>HEALTH</span>
                    <div className="t-mono" style={{ fontSize: '0.8125rem', fontWeight: 600, color: '#00D6A3' }}>
                      {healthScore}%
                    </div>
                  </div>
                </div>

                {/* Bottom Row: Last Update + View Details Button */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '4px' }}>
                  <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--ash)' }}>
                    {formatTimestamp(node.lastSeen)}
                  </span>
                  <button
                    onClick={() => {
                      setSelectedNode(node.id);
                      setDetailModalNodeId(node.id);
                    }}
                    className="cmd-btn"
                    style={{
                      padding: '4px 10px',
                      fontSize: '0.6875rem',
                      fontFamily: 'var(--font-mono)',
                      background: 'rgba(0, 217, 255, 0.1)',
                      border: '1px solid #00D9FF',
                      color: '#00D9FF',
                      borderRadius: '3px',
                      cursor: 'pointer'
                    }}
                  >
                    VIEW DETAILS
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* ============================================================ */}
        {/* 6. INDIVIDUAL NODE DETAILS MODAL / DRAWER                   */}
        {/* ============================================================ */}
        {activeModalNode && (
          <div
            style={{
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: 'rgba(0, 0, 0, 0.75)',
              backdropFilter: 'blur(6px)',
              zIndex: 1000,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '20px'
            }}
            onClick={() => setDetailModalNodeId(null)}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                width: '100%',
                maxWidth: '680px',
                backgroundColor: 'rgba(9, 12, 17, 0.98)',
                border: '1px solid rgba(0, 217, 255, 0.35)',
                borderRadius: '8px',
                boxShadow: '0 16px 48px rgba(0, 0, 0, 0.75)',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                maxHeight: '90vh'
              }}
            >
              {/* Modal Header */}
              <div
                style={{
                  padding: '16px 20px',
                  backgroundColor: 'rgba(14, 18, 26, 0.95)',
                  borderBottom: '1px solid rgba(22, 136, 181, 0.25)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span
                    style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      backgroundColor:
                        (activeModalNode.status || '').toLowerCase() === 'critical'
                          ? '#FF4D4D'
                          : (activeModalNode.status || '').toLowerCase() === 'warning' || (activeModalNode.status || '').toLowerCase() === 'stale'
                          ? '#FFB020'
                          : activeModalNode.isOnline
                          ? '#00D6A3'
                          : '#6B7280'
                    }}
                  />
                  <div>
                    <span className="t-mono" style={{ fontSize: '1.2rem', fontWeight: 700, color: '#FFFFFF' }}>
                      {activeModalNode.id}
                    </span>
                    <span style={{ color: 'var(--dust)', fontSize: '0.75rem', marginLeft: '8px' }}>
                      {activeModalLoc?.tunnel} · {activeModalLoc?.section} ({activeModalLoc?.depth})
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setDetailModalNodeId(null)}
                  style={{
                    background: 'transparent',
                    border: 'none',
                    color: 'var(--dust)',
                    cursor: 'pointer',
                    padding: '4px'
                  }}
                >
                  <X size={18} />
                </button>
              </div>

              {/* Modal Body (Scrollable) */}
              <div
                style={{
                  padding: '20px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '18px',
                  overflowY: 'auto'
                }}
              >
                {/* 1. Strata Geotechnical Telemetry */}
                <div>
                  <span
                    style={{
                      fontSize: '0.6875rem',
                      fontFamily: 'var(--font-mono)',
                      color: '#00D9FF',
                      letterSpacing: '0.08em',
                      fontWeight: 600,
                      display: 'block',
                      marginBottom: '8px'
                    }}
                  >
                    CURRENT STRATA READINGS
                  </span>
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
                      gap: '8px'
                    }}
                  >
                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.8)', padding: '10px 12px', borderRadius: '4px', border: '1px solid rgba(22, 136, 181, 0.18)' }}>
                      <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.625rem' }}>DISPLACEMENT</span>
                      <div className="t-mono" style={{ fontSize: '1.1rem', fontWeight: 700, color: (activeModalNode.status || '').toLowerCase() === 'critical' ? '#FF4D4D' : '#FFFFFF' }}>
                        {activeModalNode.displacement !== null && activeModalNode.displacement !== undefined ? `${activeModalNode.displacement.toFixed(2)} mm` : 'N/A'}
                      </div>
                      <span className="t-mono" style={{ fontSize: '0.625rem', color: 'var(--ash)' }}>{activeModalNode.displacementTrend || '→ 0%'}</span>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.8)', padding: '10px 12px', borderRadius: '4px', border: '1px solid rgba(22, 136, 181, 0.18)' }}>
                      <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.625rem' }}>VIBRATION</span>
                      <div className="t-mono" style={{ fontSize: '1.1rem', fontWeight: 700, color: (activeModalNode.status || '').toLowerCase() === 'critical' ? '#FF4D4D' : '#FFFFFF' }}>
                        {activeModalNode.vibration !== null && activeModalNode.vibration !== undefined ? `${activeModalNode.vibration.toFixed(2)} mm/s` : 'N/A'}
                      </div>
                      <span className="t-mono" style={{ fontSize: '0.625rem', color: 'var(--ash)' }}>{activeModalNode.vibrationTrend || '→ 0%'}</span>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.8)', padding: '10px 12px', borderRadius: '4px', border: '1px solid rgba(22, 136, 181, 0.18)' }}>
                      <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.625rem' }}>STRATA RISK</span>
                      <div className="t-mono" style={{ fontSize: '1.1rem', fontWeight: 700, color: (activeModalNode.status || '').toLowerCase() === 'critical' ? '#FF4D4D' : '#FFFFFF' }}>
                        {activeModalNode.strataRisk !== null && activeModalNode.strataRisk !== undefined ? `${activeModalNode.strataRisk} / 100` : 'N/A'}
                      </div>
                      <span className="t-mono" style={{ fontSize: '0.625rem', color: 'var(--ash)' }}>Backend Model</span>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.8)', padding: '10px 12px', borderRadius: '4px', border: '1px solid rgba(22, 136, 181, 0.18)' }}>
                      <span className="t-micro" style={{ color: 'var(--dust)', fontSize: '0.625rem' }}>CONVERGENCE</span>
                      <div className="t-mono" style={{ fontSize: '1.1rem', fontWeight: 700, color: '#FFFFFF' }}>
                        {activeModalNode.currentConvergence !== null && activeModalNode.currentConvergence !== undefined ? `${activeModalNode.currentConvergence.toFixed(1)} cm` : 'N/A'}
                      </div>
                      <span className="t-mono" style={{ fontSize: '0.625rem', color: 'var(--ash)' }}>{activeModalNode.deltaRate || 0} cm/s</span>
                    </div>
                  </div>
                </div>

                {/* 2. ESP32 Hardware Telemetry */}
                <div>
                  <span
                    style={{
                      fontSize: '0.6875rem',
                      fontFamily: 'var(--font-mono)',
                      color: '#00D9FF',
                      letterSpacing: '0.08em',
                      fontWeight: 600,
                      display: 'block',
                      marginBottom: '8px'
                    }}
                  >
                    HARDWARE SENSOR DATA (ESP32 + SX1262)
                  </span>
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
                      gap: '8px'
                    }}
                  >
                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>TEMPERATURE</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#FFFFFF' }}>
                        {activeModalNode.temperature || 24.2} °C
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>HUMIDITY</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#FFFFFF' }}>
                        {activeModalNode.humidity || 68.5} %
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>PRESSURE</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#FFFFFF' }}>
                        {activeModalNode.pressure || 1013.2} hPa
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>GAS ADC</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#FFFFFF' }}>
                        {activeModalNode.gasAdc || 1840} ppm
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>RAIN / MOISTURE ADC</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#FFFFFF' }}>
                        {activeModalNode.rainAdc || 150}
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>IMU MOTION</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#FFFFFF' }}>
                        {activeModalNode.imuMotion === 0 ? 'Stationary (0)' : 'Active IMU (1)'}
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>BATTERY &amp; RSSI</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: '#00D6A3' }}>
                        {activeModalNode.battery}% · {activeModalNode.rssi} dBm
                      </div>
                    </div>

                    <div style={{ backgroundColor: 'rgba(15, 20, 28, 0.6)', padding: '8px 10px', borderRadius: '4px' }}>
                      <span className="t-micro" style={{ color: 'var(--ash)', fontSize: '0.625rem' }}>FIRMWARE &amp; CALIBRATED</span>
                      <div className="t-mono" style={{ fontSize: '0.875rem', color: 'var(--dust)' }}>
                        {activeModalNode.fw} · {activeModalNode.calibrated}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. Hardware Commands: Calibrate & Reboot */}
                <div>
                  <span
                    style={{
                      fontSize: '0.6875rem',
                      fontFamily: 'var(--font-mono)',
                      color: 'var(--dust)',
                      letterSpacing: '0.08em',
                      fontWeight: 600,
                      display: 'block',
                      marginBottom: '8px'
                    }}
                  >
                    NODE HARDWARE ACTIONS
                  </span>
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                      onClick={() => handleAction('calibrate', activeModalNode.id)}
                      className="cmd-btn"
                      style={{
                        padding: '6px 12px',
                        fontSize: '0.75rem',
                        fontFamily: 'var(--font-mono)',
                        background: 'rgba(0, 217, 255, 0.1)',
                        border: '1px solid #00D9FF',
                        color: '#00D9FF',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '6px'
                      }}
                    >
                      <Sliders size={13} />
                      <span>CALIBRATE ZERO-DATUM</span>
                    </button>

                    <button
                      onClick={() => handleAction('restart', activeModalNode.id)}
                      className="cmd-btn"
                      style={{
                        padding: '6px 12px',
                        fontSize: '0.75rem',
                        fontFamily: 'var(--font-mono)',
                        background: 'rgba(255, 176, 32, 0.1)',
                        border: '1px solid #FFB020',
                        color: '#FFB020',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '6px'
                      }}
                    >
                      <RotateCw size={13} />
                      <span>REBOOT NODE</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Modal Footer: Direct Navigation Actions */}
              <div
                style={{
                  padding: '14px 20px',
                  backgroundColor: 'rgba(12, 15, 22, 0.95)',
                  borderTop: '1px solid rgba(22, 136, 181, 0.25)',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  gap: '10px'
                }}
              >
                <button
                  onClick={() => {
                    setSelectedNode(activeModalNode.id);
                    navigate('/monitoring');
                  }}
                  className="cmd-btn"
                  style={{
                    padding: '8px 14px',
                    fontSize: '0.75rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 600,
                    background: 'rgba(0, 217, 255, 0.15)',
                    border: '1px solid #00D9FF',
                    color: '#00D9FF',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                >
                  <Activity size={14} />
                  <span>VIEW LIVE MONITORING</span>
                </button>

                <button
                  onClick={() => {
                    setSelectedNode(activeModalNode.id);
                    navigate('/section');
                  }}
                  className="cmd-btn"
                  style={{
                    padding: '8px 14px',
                    fontSize: '0.75rem',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 600,
                    background: '#00D9FF',
                    border: '1px solid #00D9FF',
                    color: '#030508',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '6px'
                  }}
                >
                  <ExternalLink size={14} />
                  <span>OPEN IN DIGITAL TWIN</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @media (max-width: 900px) {
          .desktop-fleet-table-container {
            display: none !important;
          }
          .mobile-fleet-cards-container {
            display: flex !important;
          }
        }
      `}</style>
    </CommandLayout>
  );
}

export default NodesPage;
