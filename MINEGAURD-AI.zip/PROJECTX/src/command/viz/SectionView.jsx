import React, { useState, useRef } from 'react';
import { useSim } from '../sim/engine';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Minimize2, Move } from 'lucide-react';

/**
 * MineGuard AI — 2D Underground Mine Intelligence Map
 *
 * Professional 2D interactive subterranean map showing:
 * - Organic connected tunnel galleries (Tunnel A, Tunnel B, Tunnel C, Sub-Level 4)
 * - Vertical hoisting shaft and ventilation conduits
 * - Surface headframe and live ESP32 / LoRa Gateway
 * - Live sensor nodes (N-01 to N-08) with status glow and pulses
 * - Real-time telemetry data packets moving continuously through the mine network
 * - Localized risk zones (amber halo on Tunnel B / N-04, red hazard aura on Sub-Level 4 / N-07)
 * - Interactive Pan, Zoom, Level Filtering, and Node Selection
 */
export function SectionView({
  selectedLevel = 'all',
  onSelectNode,
  className = ''
}) {
  const { nodes, selectedNodeId, setSelectedNode, gatewayState } = useSim();

  // Navigation & View Transformation States
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [hoveredNodeId, setHoveredNodeId] = useState(null);

  const containerRef = useRef(null);

  // SVG coordinate system
  const W = 1000;
  const H = 680;

  // Zoom controls
  const handleZoomIn = () => setZoom((z) => Math.min(2.5, Number((z + 0.25).toFixed(2))));
  const handleZoomOut = () => setZoom((z) => Math.max(0.65, Number((z - 0.25).toFixed(2))));
  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Fullscreen toggle
  const handleToggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  // Mouse pan drag handlers
  const handleMouseDown = (e) => {
    if (e.target.closest('.dt-ctrl-btn') || e.target.closest('.dt-node-interactive')) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y
    });
  };

  const handleMouseUp = () => setIsDragging(false);

  // Scroll wheel zoom
  const handleWheel = (e) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.08 : 0.08;
    setZoom((z) => Math.min(2.5, Math.max(0.65, Number((z + delta).toFixed(2)))));
  };

  // Node selection handler
  const handleNodeClick = (e, nodeId) => {
    e.stopPropagation();
    setSelectedNode(nodeId);
    if (onSelectNode) onSelectNode(nodeId);
  };

  // Node coordinates inside the 2D organic tunnel galleries
  const nodePositions = {
    'N-01': { x: 300, y: 155, level: 'level-1', depth: '-100 m', tunnel: 'Tunnel A', name: 'Main Haulage Entry' },
    'N-02': { x: 700, y: 155, level: 'level-1', depth: '-100 m', tunnel: 'Tunnel A', name: 'Portal Cross-Cut' },
    'N-03': { x: 280, y: 280, level: 'level-2', depth: '-200 m', tunnel: 'Tunnel B', name: 'Central Junction' },
    'N-04': { x: 730, y: 265, level: 'level-2', depth: '-200 m', tunnel: 'Tunnel B', name: 'North Drift Heading' },
    'N-05': { x: 310, y: 410, level: 'level-3', depth: '-300 m', tunnel: 'Tunnel C', name: 'Ventilation Incline' },
    'N-08': { x: 690, y: 395, level: 'level-3', depth: '-300 m', tunnel: 'Tunnel C', name: 'Drainage Return' },
    'N-06': { x: 290, y: 540, level: 'level-4', depth: '-460 m', tunnel: 'level-4', name: 'South Access Heading' },
    'N-07': { x: 720, y: 525, level: 'level-4', depth: '-460 m', tunnel: 'level-4', name: 'Active Longwall Face' }
  };

  // Compute level dimming opacity based on selectedLevel
  const getLevelOpacity = (lvl) => {
    if (selectedLevel === 'all') return 1;
    if (selectedLevel === lvl) return 1;
    return 0.22;
  };

  // Dynamic vertical pan bias when filtering levels
  let levelYOffset = 0;
  if (selectedLevel === 'surface') levelYOffset = 180;
  else if (selectedLevel === 'level-1') levelYOffset = 120;
  else if (selectedLevel === 'level-2') levelYOffset = 40;
  else if (selectedLevel === 'level-3') levelYOffset = -60;
  else if (selectedLevel === 'level-4') levelYOffset = -180;

  return (
    <div
      ref={containerRef}
      className={`digital-twin-2d-map-container ${className}`}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        minHeight: '600px',
        backgroundColor: '#030609',
        borderRadius: '6px',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        userSelect: 'none'
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
    >
      <style>{`
        @keyframes nodeCritPulse {
          0% { r: 6px; opacity: 0.95; }
          50% { r: 22px; opacity: 0.3; }
          100% { r: 32px; opacity: 0; }
        }
        @keyframes nodeWarnPulse {
          0% { r: 6px; opacity: 0.85; }
          50% { r: 18px; opacity: 0.25; }
          100% { r: 26px; opacity: 0; }
        }
        @keyframes nodeNormPulse {
          0% { r: 5px; opacity: 0.8; }
          50% { r: 14px; opacity: 0.2; }
          100% { r: 20px; opacity: 0; }
        }
        @keyframes selectedRingExpand {
          0% { r: 12px; opacity: 0.9; }
          50% { r: 17px; opacity: 0.35; }
          100% { r: 22px; opacity: 0; }
        }
        @keyframes gatewayBeaconPulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.45; transform: scale(0.9); }
        }
        @keyframes hazardAuraBreathe {
          0%, 100% { opacity: 0.75; }
          50% { opacity: 0.45; }
        }
      `}</style>

      {/* ════════════════════════════════════════════════════════════ */}
      {/* 2D UNDERGROUND MINE SVG MAP                                  */}
      {/* ════════════════════════════════════════════════════════════ */}
      <div style={{ position: 'relative', width: '100%', flex: 1, minHeight: 0 }}>
        <svg
          width="100%"
          height="100%"
          viewBox={`0 0 ${W} ${H}`}
          preserveAspectRatio="xMidYMid meet"
          style={{ display: 'block', cursor: isDragging ? 'grabbing' : 'grab' }}
        >
          <defs>
            {/* Subtle Map Grid Pattern */}
            <pattern id="mine2dGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(22, 136, 181, 0.07)" strokeWidth="0.8" />
              <circle cx="0" cy="0" r="1" fill="rgba(0, 217, 255, 0.12)" />
            </pattern>

            {/* Localized Warning Aura (N-04 in Tunnel B) */}
            <radialGradient id="warnAura" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FFB020" stopOpacity="0.45" />
              <stop offset="50%" stopColor="#FFB020" stopOpacity="0.18" />
              <stop offset="100%" stopColor="#FFB020" stopOpacity="0" />
            </radialGradient>

            {/* Localized Critical Hazard Aura (N-07 in Sub-Level 4) */}
            <radialGradient id="critAura" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#FF4D4D" stopOpacity="0.55" />
              <stop offset="45%" stopColor="#FF4D4D" stopOpacity="0.22" />
              <stop offset="100%" stopColor="#FF4D4D" stopOpacity="0" />
            </radialGradient>

            {/* Gateway Beacon Glow */}
            <radialGradient id="gwGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#00D9FF" stopOpacity="0.6" />
              <stop offset="60%" stopColor="#00D9FF" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#00D9FF" stopOpacity="0" />
            </radialGradient>

            {/* Tunnel Path Linear Gradients */}
            <linearGradient id="tunnelGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(10, 22, 34, 0.9)" />
              <stop offset="50%" stopColor="rgba(14, 30, 48, 0.95)" />
              <stop offset="100%" stopColor="rgba(10, 22, 34, 0.9)" />
            </linearGradient>

            <linearGradient id="shaftGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgba(0, 217, 255, 0.3)" />
              <stop offset="100%" stopColor="rgba(0, 217, 255, 0.08)" />
            </linearGradient>

            {/* ── FLOW PATH DEFINITIONS FOR CONTINUOUS TELEMETRY PACKETS ── */}
            {/* Shaft vertical drop */}
            <path id="pathShaft" d="M 500 55 L 500 560" />

            {/* Tunnel A flow: N-01 -> Shaft -> N-02 */}
            <path id="pathTunnelA_L" d="M 170 155 Q 300 155 500 155" />
            <path id="pathTunnelA_R" d="M 830 155 Q 700 155 500 155" />

            {/* Tunnel B flow: N-03 -> Shaft -> N-04 */}
            <path id="pathTunnelB_L" d="M 180 285 Q 300 280 500 275" />
            <path id="pathTunnelB_R" d="M 820 260 Q 720 265 500 275" />

            {/* Tunnel C flow: N-05 -> Shaft -> N-08 */}
            <path id="pathTunnelC_L" d="M 190 415 Q 320 410 500 400" />
            <path id="pathTunnelC_R" d="M 810 390 Q 690 395 500 400" />

            {/* Sub-Level 4 flow: N-06 -> Shaft -> N-07 */}
            <path id="pathSubLevel4_L" d="M 180 545 Q 300 540 500 530" />
            <path id="pathSubLevel4_R" d="M 820 520 Q 710 525 500 530" />
          </defs>

          {/* Background Grid */}
          <rect width="100%" height="100%" fill="url(#mine2dGrid)" />

          {/* World Pan & Zoom Transform Layer */}
          <g
            transform={`translate(${pan.x + W / 2}, ${pan.y + H / 2 + levelYOffset}) scale(${zoom}) translate(${-W / 2}, ${-H / 2})`}
            style={{ transition: isDragging ? 'none' : 'transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)' }}
          >
            {/* ════════════════════════════════════════════════════════════ */}
            {/* LOCALIZED RISK AURA OVERLAYS                                */}
            {/* ════════════════════════════════════════════════════════════ */}
            {Object.keys(nodePositions).map((nId) => {
              const nData = nodes[nId];
              const pos = nodePositions[nId];
              const isCrit = nData?.status === 'critical' || nData?.status === 'CRITICAL';
              const isWarn = (nData?.status === 'warning' || nData?.status === 'WARNING') && !isCrit;
              if (!isCrit && !isWarn) return null;
              return (
                <g key={`aura-${nId}`} style={{ opacity: getLevelOpacity(pos.level) }}>
                  <ellipse
                    cx={pos.x}
                    cy={pos.y}
                    rx={isCrit ? 130 : 100}
                    ry={isCrit ? 65 : 50}
                    fill={isCrit ? 'url(#critAura)' : 'url(#warnAura)'}
                    style={{ animation: isCrit ? 'hazardAuraBreathe 2s ease-in-out infinite' : 'hazardAuraBreathe 3s ease-in-out infinite' }}
                  />
                </g>
              );
            })}

            {/* ════════════════════════════════════════════════════════════ */}
            {/* VERTICAL SHAFTS & CONNECTIONS                               */}
            {/* ════════════════════════════════════════════════════════════ */}
            {/* Central Main Hoist Shaft (Double-line walls) */}
            <g opacity={selectedLevel === 'all' ? 0.9 : 0.45}>
              {/* Shaft interior */}
              <rect x="488" y="55" width="24" height="515" fill="rgba(6, 14, 24, 0.95)" />
              {/* Shaft walls */}
              <line x1="488" y1="55" x2="488" y2="570" stroke="#00D9FF" strokeWidth="1.6" opacity="0.6" />
              <line x1="512" y1="55" x2="512" y2="570" stroke="#00D9FF" strokeWidth="1.6" opacity="0.6" />
              {/* Structural shaft ladder/cage guide rungs */}
              {Array.from({ length: 25 }).map((_, idx) => (
                <line
                  key={`rung-${idx}`}
                  x1="490"
                  y1={75 + idx * 20}
                  x2="510"
                  y2={75 + idx * 20}
                  stroke="rgba(0, 217, 255, 0.18)"
                  strokeWidth="1"
                />
              ))}
              {/* Shaft center telemetry trunk line */}
              <line x1="500" y1="55" x2="500" y2="560" stroke="rgba(0, 217, 255, 0.4)" strokeWidth="1.2" strokeDasharray="4 3" />
            </g>

            {/* Secondary Ventilation Raise (East Shaft: Connecting Tunnel A to Sub-Level 4) */}
            <g opacity={selectedLevel === 'all' ? 0.6 : 0.25}>
              <line x1="790" y1="165" x2="790" y2="515" stroke="rgba(22, 136, 181, 0.4)" strokeWidth="1.4" strokeDasharray="6 4" />
              <text x="798" y="340" fill="rgba(22, 136, 181, 0.65)" fontSize="8" fontFamily="monospace">VENT RAISE 02</text>
            </g>

            {/* Secondary Escape Incline (West Shaft: Connecting Tunnel B to Level 3) */}
            <g opacity={selectedLevel === 'all' ? 0.6 : 0.25}>
              <line x1="210" y1="165" x2="210" y2="420" stroke="rgba(22, 136, 181, 0.4)" strokeWidth="1.4" strokeDasharray="6 4" />
              <text x="142" y="300" fill="rgba(22, 136, 181, 0.65)" fontSize="8" fontFamily="monospace">WEST RAISE 01</text>
            </g>

            {/* ════════════════════════════════════════════════════════════ */}
            {/* TUNNEL GALLERIES (ORGANIC DOUBLE-LINE 2D PATHS)             */}
            {/* ════════════════════════════════════════════════════════════ */}

            {/* ── TUNNEL A: LEVEL 1 (−100 m) ── */}
            <g style={{ opacity: getLevelOpacity('level-1'), transition: 'opacity 0.25s ease' }}>
              {/* Tunnel Floor & Ceiling Ribbon */}
              <path
                d="M 150 142 Q 320 140 500 143 Q 680 140 850 142 L 850 168 Q 680 170 500 167 Q 320 170 150 168 Z"
                fill="url(#tunnelGrad)"
              />
              {/* Upper Ceiling Line */}
              <path
                d="M 150 142 Q 320 140 500 143 Q 680 140 850 142"
                fill="none"
                stroke="#1688B5"
                strokeWidth="2"
                strokeOpacity="0.85"
              />
              {/* Lower Floor Line */}
              <path
                d="M 150 168 Q 320 170 500 167 Q 680 170 850 168"
                fill="none"
                stroke="#1688B5"
                strokeWidth="2"
                strokeOpacity="0.85"
              />
              {/* Tunnel Center Rail/Data Guideway */}
              <path
                d="M 160 155 Q 320 155 500 155 Q 680 155 840 155"
                fill="none"
                stroke="rgba(0, 217, 255, 0.22)"
                strokeWidth="1"
                strokeDasharray="8 6"
              />
              {/* Tunnel Label */}
              <text x="160" y="132" fill="#00D9FF" fontSize="10" fontFamily="monospace" fontWeight="600" letterSpacing="0.08em">
                TUNNEL A — MAIN HAULAGE (−100 m)
              </text>
            </g>

            {/* ── TUNNEL B: LEVEL 2 (−200 m) ── */}
            <g style={{ opacity: getLevelOpacity('level-2'), transition: 'opacity 0.25s ease' }}>
              {/* Organic Curved Heading */}
              <path
                d="M 160 272 Q 320 268 500 263 Q 660 252 840 248 L 840 274 Q 660 278 500 287 Q 320 292 160 296 Z"
                fill="url(#tunnelGrad)"
              />
              {/* Upper Ceiling Line */}
              <path
                d="M 160 272 Q 320 268 500 263 Q 660 252 840 248"
                fill="none"
                stroke={nodePositions['N-04'] ? '#FFB020' : '#1688B5'}
                strokeWidth="2"
                strokeOpacity="0.85"
              />
              {/* Lower Floor Line */}
              <path
                d="M 160 296 Q 320 292 500 287 Q 660 278 840 274"
                fill="none"
                stroke={nodePositions['N-04'] ? '#FFB020' : '#1688B5'}
                strokeWidth="2"
                strokeOpacity="0.85"
              />
              {/* Tunnel Center Rail/Data Guideway */}
              <path
                d="M 170 284 Q 320 280 500 275 Q 660 265 830 261"
                fill="none"
                stroke="rgba(255, 176, 32, 0.25)"
                strokeWidth="1"
                strokeDasharray="8 6"
              />
              {/* Tunnel Label */}
              <text x="160" y="258" fill="#FFB020" fontSize="10" fontFamily="monospace" fontWeight="600" letterSpacing="0.08em">
                TUNNEL B — NORTH DRIFT (−200 m) · ELEVATED TILT
              </text>
            </g>

            {/* ── TUNNEL C: LEVEL 3 (−300 m) ── */}
            <g style={{ opacity: getLevelOpacity('level-3'), transition: 'opacity 0.25s ease' }}>
              {/* Organic Tunnel Path */}
              <path
                d="M 170 402 Q 330 398 500 388 Q 660 380 830 378 L 830 404 Q 660 406 500 412 Q 330 422 170 426 Z"
                fill="url(#tunnelGrad)"
              />
              {/* Upper Ceiling Line */}
              <path
                d="M 170 402 Q 330 398 500 388 Q 660 380 830 378"
                fill="none"
                stroke="#1688B5"
                strokeWidth="2"
                strokeOpacity="0.85"
              />
              {/* Lower Floor Line */}
              <path
                d="M 170 426 Q 330 422 500 412 Q 660 406 830 404"
                fill="none"
                stroke="#1688B5"
                strokeWidth="2"
                strokeOpacity="0.85"
              />
              {/* Tunnel Center Rail */}
              <path
                d="M 180 414 Q 330 410 500 400 Q 660 393 820 391"
                fill="none"
                stroke="rgba(0, 217, 255, 0.22)"
                strokeWidth="1"
                strokeDasharray="8 6"
              />
              {/* Tunnel Label */}
              <text x="160" y="388" fill="#00D9FF" fontSize="10" fontFamily="monospace" fontWeight="600" letterSpacing="0.08em">
                TUNNEL C — VENTILATION INCLINE (−300 m)
              </text>
            </g>

            {/* ── SUB-LEVEL 4: LEVEL 4 (−460 m) ── */}
            <g style={{ opacity: getLevelOpacity('level-4'), transition: 'opacity 0.25s ease' }}>
              {/* Widened Active Longwall Extraction Stope */}
              <path
                d="M 160 530 Q 320 528 500 518 Q 680 505 840 502 L 840 534 Q 680 537 500 544 Q 320 552 160 556 Z"
                fill="url(#tunnelGrad)"
              />
              {/* Upper Ceiling Line */}
              <path
                d="M 160 530 Q 320 528 500 518 Q 680 505 840 502"
                fill="none"
                stroke="#FF4D4D"
                strokeWidth="2.2"
                strokeOpacity="0.9"
              />
              {/* Lower Floor Line */}
              <path
                d="M 160 556 Q 320 552 500 544 Q 680 537 840 534"
                fill="none"
                stroke="#FF4D4D"
                strokeWidth="2.2"
                strokeOpacity="0.9"
              />
              {/* Center Guidance Track */}
              <path
                d="M 170 543 Q 320 540 500 531 Q 680 521 830 518"
                fill="none"
                stroke="rgba(255, 77, 77, 0.3)"
                strokeWidth="1"
                strokeDasharray="8 6"
              />
              {/* Tunnel Label */}
              <text x="160" y="518" fill="#FF4D4D" fontSize="10" fontFamily="monospace" fontWeight="700" letterSpacing="0.08em">
                SUB-LEVEL 4 — ACTIVE LONGWALL STOPE (−460 m) · CRITICAL ROOF CONVERGENCE
              </text>
            </g>

            {/* ════════════════════════════════════════════════════════════ */}
            {/* LIVE CONTINUOUS TELEMETRY PARTICLES (<animateMotion>)        */}
            {/* ════════════════════════════════════════════════════════════ */}
            {(gatewayState?.connected || gatewayState?.nodesOnline > 0) && (
              <>
                {/* Packets traveling through Tunnel A into Shaft */}
                <circle r="2.8" fill="#00D9FF" opacity="0.9">
                  <animateMotion dur="4.2s" repeatCount="indefinite">
                    <mpath href="#pathTunnelA_L" />
                  </animateMotion>
                </circle>
                <circle r="2.8" fill="#00D9FF" opacity="0.9">
                  <animateMotion dur="4.5s" begin="1.8s" repeatCount="indefinite">
                    <mpath href="#pathTunnelA_R" />
                  </animateMotion>
                </circle>

                {/* Packets traveling through Tunnel B into Shaft */}
                <circle r="2.8" fill="#FFB020" opacity="0.9">
                  <animateMotion dur="4.8s" repeatCount="indefinite">
                    <mpath href="#pathTunnelB_R" />
                  </animateMotion>
                </circle>
                <circle r="2.8" fill="#00D6A3" opacity="0.8">
                  <animateMotion dur="5.0s" begin="2.1s" repeatCount="indefinite">
                    <mpath href="#pathTunnelB_L" />
                  </animateMotion>
                </circle>

                {/* Packets traveling through Tunnel C into Shaft */}
                <circle r="2.8" fill="#00D6A3" opacity="0.85">
                  <animateMotion dur="5.2s" repeatCount="indefinite">
                    <mpath href="#pathTunnelC_L" />
                  </animateMotion>
                </circle>
                <circle r="2.8" fill="#00D6A3" opacity="0.85">
                  <animateMotion dur="4.9s" begin="2.4s" repeatCount="indefinite">
                    <mpath href="#pathTunnelC_R" />
                  </animateMotion>
                </circle>

                {/* Packets traveling through Sub-Level 4 into Shaft */}
                <circle r="3.2" fill="#FF4D4D" opacity="0.95">
                  <animateMotion dur="4.0s" repeatCount="indefinite">
                    <mpath href="#pathSubLevel4_R" />
                  </animateMotion>
                </circle>
                <circle r="2.8" fill="#00D6A3" opacity="0.8">
                  <animateMotion dur="4.7s" begin="1.5s" repeatCount="indefinite">
                    <mpath href="#pathSubLevel4_L" />
                  </animateMotion>
                </circle>

                {/* Packets traveling up the Central Shaft to the Surface Gateway */}
                <circle r="3" fill="#00D9FF" opacity="0.9">
                  <animateMotion dur="3.6s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1">
                    <mpath href="#pathShaft" />
                  </animateMotion>
                </circle>
                <circle r="3" fill="#00D9FF" opacity="0.75">
                  <animateMotion dur="3.6s" begin="1.8s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1">
                    <mpath href="#pathShaft" />
                  </animateMotion>
                </circle>
              </>
            )}

            {/* ════════════════════════════════════════════════════════════ */}
            {/* SURFACE INFRASTRUCTURE & ESP32 GATEWAY                       */}
            {/* ════════════════════════════════════════════════════════════ */}
            <g style={{ opacity: getLevelOpacity('surface'), transition: 'opacity 0.25s ease' }}>
              {/* Surface Terrain Contour */}
              <path
                d="M 40 55 Q 260 48 500 55 Q 740 60 960 52"
                fill="none"
                stroke="rgba(22, 136, 181, 0.45)"
                strokeWidth="1.8"
              />
              <text x="60" y="44" fill="var(--dust)" fontSize="9" fontFamily="monospace" letterSpacing="0.08em">
                SURFACE ELEVATION 0 m
              </text>

              {/* Surface Headframe Tower Gear */}
              <g transform="translate(500, 52)">
                <path d="M -22 0 L -8 -32 L 8 -32 L 22 0 Z" fill="rgba(8, 14, 22, 0.95)" stroke="#00D9FF" strokeWidth="1.5" />
                <circle cx="0" cy="-32" r="7" fill="none" stroke="#00D9FF" strokeWidth="1.2" />
                <circle cx="0" cy="-32" r="2.5" fill="#00D9FF" />
              </g>

              {/* ESP32 / LoRa Gateway Badge */}
              <g transform="translate(500, 16)">
                {/* Glow Backdrop */}
                <rect
                  x="-110"
                  y="-14"
                  width="220"
                  height="26"
                  rx="4"
                  fill="rgba(6, 10, 16, 0.95)"
                  stroke="#00D9FF"
                  strokeWidth="1.4"
                  filter="drop-shadow(0 0 8px rgba(0, 217, 255, 0.25))"
                />
                {/* Status Beacon Circle */}
                <circle
                  cx="-92"
                  cy="-1"
                  r="4.5"
                  fill={gatewayState?.connected || gatewayState?.nodesOnline > 0 ? '#00D6A3' : '#717888'}
                  style={{ animation: gatewayState?.connected || gatewayState?.nodesOnline > 0 ? 'gatewayBeaconPulse 2s ease-in-out infinite' : 'none' }}
                />
                <circle cx="-92" cy="-1" r="8" fill="none" stroke={gatewayState?.connected || gatewayState?.nodesOnline > 0 ? '#00D6A3' : '#717888'} strokeWidth="1" opacity="0.5" />
                {/* Gateway Text */}
                <text
                  x="-78"
                  y="3"
                  fill="#FFFFFF"
                  fontSize="9.5"
                  fontFamily="monospace"
                  fontWeight="600"
                  letterSpacing="0.06em"
                >
                  ESP32 / LoRa GATEWAY
                </text>
                <text
                  x="56"
                  y="3"
                  fill={gatewayState?.connected || gatewayState?.nodesOnline > 0 ? '#00D6A3' : '#717888'}
                  fontSize="9"
                  fontFamily="monospace"
                  fontWeight="700"
                >
                  {gatewayState?.connected || gatewayState?.nodesOnline > 0 ? 'CONNECTED' : 'STANDBY'}
                </text>
              </g>
            </g>

            {/* ════════════════════════════════════════════════════════════ */}
            {/* SENSOR NODES (N-01 to N-08)                                 */}
            {/* ════════════════════════════════════════════════════════════ */}
            {Object.keys(nodePositions).map((nodeId) => {
              const pos = nodePositions[nodeId];
              const nodeData = nodes[nodeId];
              const isSelected = selectedNodeId === nodeId;
              const isHovered = hoveredNodeId === nodeId;

              const isCrit = nodeData?.status === 'critical' || nodeData?.status === 'CRITICAL';
              const isWarn = (nodeData?.status === 'warning' || nodeData?.status === 'WARNING') && !isCrit;
              const isStale = (nodeData?.status === 'stale' || nodeData?.status === 'STALE') && !isCrit && !isWarn;
              const isOffline = !nodeData?.isOnline && nodeData?.status !== 'ONLINE' && !isCrit && !isWarn && !isStale;

              const nodeColor = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : isStale ? '#FF8800' : isOffline ? '#5B6271' : '#00D6A3';
              const pulseAnim = isCrit
                ? 'nodeCritPulse 1.8s ease-out infinite'
                : isWarn
                ? 'nodeWarnPulse 2.4s ease-out infinite'
                : isStale
                ? 'nodeWarnPulse 3.0s ease-out infinite'
                : isOffline
                ? 'none'
                : 'nodeNormPulse 3.2s ease-out infinite';

              const parentOpacity = getLevelOpacity(pos.level);

              return (
                <g
                  key={nodeId}
                  className="dt-node-interactive"
                  transform={`translate(${pos.x}, ${pos.y})`}
                  style={{
                    cursor: 'pointer',
                    opacity: parentOpacity,
                    transition: 'opacity 0.25s ease'
                  }}
                  onClick={(e) => handleNodeClick(e, nodeId)}
                  onMouseEnter={() => setHoveredNodeId(nodeId)}
                  onMouseLeave={() => setHoveredNodeId(null)}
                >
                  {/* Expanding Pulse Ring */}
                  {pulseAnim !== 'none' && (
                    <circle
                      cx="0"
                      cy="0"
                      r="6"
                      fill="none"
                      stroke={nodeColor}
                      strokeWidth="1.5"
                      style={{ animation: pulseAnim }}
                    />
                  )}

                  {/* Selected Node Ring Lock */}
                  {isSelected && (
                    <>
                      <circle
                        cx="0"
                        cy="0"
                        r="14"
                        fill="none"
                        stroke="#00D9FF"
                        strokeWidth="1.6"
                        strokeDasharray="4 3"
                        style={{ animation: 'selectedRingExpand 2s linear infinite' }}
                      />
                      <circle cx="0" cy="0" r="16" fill="none" stroke="#00D9FF" strokeWidth="1.2" />
                    </>
                  )}

                  {/* Core Node Disc */}
                  <circle
                    cx="0"
                    cy="0"
                    r={isSelected ? 8 : 6.5}
                    fill="rgba(5, 9, 15, 0.95)"
                    stroke={nodeColor}
                    strokeWidth={isSelected ? 2.2 : 1.8}
                    filter={`drop-shadow(0 0 6px ${nodeColor})`}
                  />
                  <circle cx="0" cy="0" r="3.2" fill={nodeColor} />

                  {/* Node ID Label Tag */}
                  <rect
                    x={pos.x > 500 ? 12 : -46}
                    y="-10"
                    width="34"
                    height="18"
                    rx="3"
                    fill="rgba(5, 8, 12, 0.9)"
                    stroke={isSelected ? '#00D9FF' : 'rgba(22, 136, 181, 0.35)'}
                    strokeWidth={isSelected ? 1.4 : 1}
                  />
                  <text
                    x={pos.x > 500 ? 29 : -29}
                    y="3"
                    fill={isSelected ? '#FFFFFF' : 'var(--chalk)'}
                    fontSize="9.5"
                    fontFamily="monospace"
                    fontWeight="700"
                    textAnchor="middle"
                  >
                    {nodeId}
                  </text>

                  {/* Hover HUD Tooltip */}
                  {isHovered && (
                    <g transform={`translate(${pos.x > 500 ? -160 : 20}, -64)`} style={{ pointerEvents: 'none' }}>
                      <rect
                        width="150"
                        height="64"
                        rx="4"
                        fill="rgba(7, 10, 16, 0.96)"
                        stroke="#00D9FF"
                        strokeWidth="1.2"
                        filter="drop-shadow(0 4px 16px rgba(0,0,0,0.65))"
                      />
                      <text x="10" y="16" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="700">
                        {nodeId} · {pos.name}
                      </text>
                      <text x="10" y="30" fill={nodeColor} fontSize="9" fontFamily="monospace" fontWeight="600">
                        STATUS: {isCrit ? 'CRITICAL' : isWarn ? 'WARNING' : isStale ? 'STALE' : isOffline ? 'OFFLINE' : 'ONLINE'}
                      </text>
                      <text x="10" y="44" fill="var(--dust)" fontSize="8.5" fontFamily="monospace">
                        DISP: {nodeData?.displacement != null ? `${nodeData.displacement.toFixed(1)}mm` : nodeData?.distance != null ? `${(nodeData.distance * 10).toFixed(1)}mm` : 'N/A'} · VIB: {nodeData?.vibration != null ? nodeData.vibration.toFixed(2) : nodeData?.imuMotion != null ? nodeData.imuMotion.toFixed(2) : 'N/A'}
                      </text>
                      <text x="10" y="56" fill="var(--dust)" fontSize="8.5" fontFamily="monospace">
                        RISK: {nodeData?.strataRisk != null ? `${nodeData.strataRisk}/100` : isOffline ? '0/100' : '18/100'} · {pos.depth}
                      </text>
                    </g>
                  )}
                </g>
              );
            })}
          </g>
        </svg>
      </div>

      {/* ════════════════════════════════════════════════════════════ */}
      {/* MINIMAL BOTTOM CONTROLS & COMPACT STATUS LEGEND              */}
      {/* ════════════════════════════════════════════════════════════ */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '8px',
          padding: '8px 14px',
          backgroundColor: 'rgba(5, 7, 11, 0.95)',
          borderTop: '1px solid rgba(22, 136, 181, 0.22)',
          zIndex: 20
        }}
      >
        {/* Compact Status Legend */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px', fontFamily: 'var(--font-mono)' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '0.6875rem', color: 'var(--dust)' }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: '#00D6A3', boxShadow: '0 0 6px #00D6A3' }} />
            Normal
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '0.6875rem', color: 'var(--dust)' }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: '#FFB020', boxShadow: '0 0 6px #FFB020' }} />
            Warning
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '0.6875rem', color: 'var(--dust)' }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: '#FF4D4D', boxShadow: '0 0 6px #FF4D4D' }} />
            Critical
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontSize: '0.6875rem', color: 'var(--dust)' }}>
            <span style={{ width: '7px', height: '7px', borderRadius: '50%', backgroundColor: '#5B6271' }} />
            Offline
          </span>
        </div>

        {/* Minimal Map Controls (PAN, ZOOM +, ZOOM -, RESET, FULLSCREEN) */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          {/* PAN RECENTER */}
          <button
            onClick={() => setPan({ x: 0, y: 0 })}
            className="cmd-btn dt-ctrl-btn"
            style={{
              padding: '4px 8px',
              fontSize: '0.625rem',
              fontFamily: 'var(--font-mono)',
              background: 'transparent',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              color: 'var(--dust)',
              borderRadius: '3px',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px'
            }}
            title="Recenter Map Pan"
          >
            <Move size={12} />
            <span>PAN</span>
          </button>

          {/* ZOOM + */}
          <button
            onClick={handleZoomIn}
            className="cmd-btn dt-ctrl-btn"
            style={{
              padding: '4px 8px',
              fontSize: '0.625rem',
              fontFamily: 'var(--font-mono)',
              background: 'transparent',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              color: 'var(--dust)',
              borderRadius: '3px',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px'
            }}
            title="Zoom In"
          >
            <ZoomIn size={12} />
            <span>ZOOM +</span>
          </button>

          {/* ZOOM - */}
          <button
            onClick={handleZoomOut}
            className="cmd-btn dt-ctrl-btn"
            style={{
              padding: '4px 8px',
              fontSize: '0.625rem',
              fontFamily: 'var(--font-mono)',
              background: 'transparent',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              color: 'var(--dust)',
              borderRadius: '3px',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px'
            }}
            title="Zoom Out"
          >
            <ZoomOut size={12} />
            <span>ZOOM −</span>
          </button>

          {/* RESET */}
          <button
            onClick={handleReset}
            className="cmd-btn dt-ctrl-btn"
            style={{
              padding: '4px 8px',
              fontSize: '0.625rem',
              fontFamily: 'var(--font-mono)',
              background: 'transparent',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              color: 'var(--dust)',
              borderRadius: '3px',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px'
            }}
            title="Reset Zoom & Pan"
          >
            <RotateCcw size={11} />
            <span>RESET</span>
          </button>

          {/* FULLSCREEN */}
          <button
            onClick={handleToggleFullscreen}
            className="cmd-btn dt-ctrl-btn"
            style={{
              padding: '4px 8px',
              fontSize: '0.625rem',
              fontFamily: 'var(--font-mono)',
              background: 'transparent',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              color: 'var(--dust)',
              borderRadius: '3px',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px'
            }}
            title={isFullscreen ? 'Exit Fullscreen' : 'View Fullscreen'}
          >
            {isFullscreen ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
            <span>FULLSCREEN</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default SectionView;
