import React from 'react';

/**
 * MineGuard Hand-written SVG Visualisation Primitives
 * No Recharts, no Chart.js, pure SVG maths & tokens.
 */

// 1. Sparkline (used in node cards, hero risk, etc.)
export function Sparkline({
  data = [],
  dataKey = 'value',
  width = 120,
  height = 36,
  stroke = 'var(--lamp)',
  fill = 'none',
  minVal,
  maxVal,
  strokeWidth = 1.5,
  showEndDot = true
}) {
  if (!data || data.length < 2) {
    return <svg width={width} height={height} className="sparkline" />;
  }

  const values = data.map((d) => (typeof d === 'number' ? d : d[dataKey]));
  const min = minVal !== undefined ? minVal : Math.min(...values);
  const max = maxVal !== undefined ? maxVal : Math.max(...values);
  const range = max - min || 1;

  const points = values.map((val, i) => {
    const x = (i / (values.length - 1)) * (width - 4) + 2;
    const y = height - 4 - ((val - min) / range) * (height - 8);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const pathD = `M ${points.join(' L ')}`;
  const lastX = (width - 4) + 2;
  const lastY = height - 4 - ((values[values.length - 1] - min) / range) * (height - 8);

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: 'block' }}>
      <path d={pathD} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" />
      {showEndDot && (
        <circle cx={lastX} cy={lastY} r={2.5} fill={stroke} />
      )}
    </svg>
  );
}

// 2. Waveform (used in the 8-node oscilloscope bank on /monitoring)
export function Waveform({
  data = [],
  metric = 'convergence', // 'tilt' | 'convergence'
  width = 600,
  height = 96,
  warningThreshold,
  criticalThreshold,
  isInverted = false, // for convergence, lower value = more severe
  accentColor = 'var(--lamp)',
  crosshairIndex = null
}) {
  if (!data || data.length < 2) return <div style={{ height }} />;

  const values = data.map((d) => d[metric]);
  const min = isInverted ? 12.0 : 0.0;
  const max = isInverted ? 22.0 : 4.0;
  const range = max - min;

  const getY = (val) => {
    const clamped = Math.max(min, Math.min(max, val));
    return height - 12 - ((clamped - min) / range) * (height - 24);
  };

  const points = values.map((val, i) => {
    const x = (i / (values.length - 1)) * (width - 16) + 8;
    const y = getY(val);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  // Threshold Y coordinates
  const warnY = warningThreshold !== undefined ? getY(warningThreshold) : null;
  const critY = criticalThreshold !== undefined ? getY(criticalThreshold) : null;

  // Crosshair position if hovered
  const chX = crosshairIndex !== null && crosshairIndex >= 0 && crosshairIndex < values.length
    ? (crosshairIndex / (values.length - 1)) * (width - 16) + 8
    : null;
  const chVal = crosshairIndex !== null && crosshairIndex >= 0 && crosshairIndex < values.length
    ? values[crosshairIndex]
    : null;

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ display: 'block' }}>
      {/* Background gridlines */}
      <line x1="8" y1={height / 2} x2={width - 8} y2={height / 2} stroke="var(--seam)" strokeWidth="1" strokeDasharray="3 3" />

      {/* Threshold bands */}
      {warnY !== null && (
        <line x1="8" y1={warnY} x2={width - 8} y2={warnY} stroke="var(--lamp-dim)" strokeWidth="1" strokeDasharray="4 4" />
      )}
      {critY !== null && (
        <line x1="8" y1={critY} x2={width - 8} y2={critY} stroke="var(--flare)" strokeWidth="1" strokeDasharray="4 4" />
      )}

      {/* Main live trace */}
      <path
        d={`M ${points.join(' L ')}`}
        fill="none"
        stroke={accentColor}
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Synchronised Crosshair */}
      {chX !== null && (
        <g>
          <line x1={chX} y1="0" x2={chX} y2={height} stroke="var(--chalk)" strokeWidth="1" strokeDasharray="2 2" opacity="0.75" />
          <circle cx={chX} cy={getY(chVal)} r="3" fill="var(--chalk)" />
        </g>
      )}
    </svg>
  );
}

// 3. AreaChart (used for 24h risk trend, forecast, etc.)
export function AreaChart({
  data = [],
  width = 320,
  height = 140,
  stroke = 'var(--lamp)',
  fillColor = 'var(--lamp)',
  warningThreshold = 50,
  criticalThreshold = 75,
  showThresholds = true
}) {
  if (!data || data.length < 2) return <div style={{ height }} />;

  const values = data.map((d) => (typeof d === 'number' ? d : d.risk));
  const range = 100;

  const getY = (val) => height - 16 - (val / range) * (height - 32);

  const points = values.map((val, i) => {
    const x = (i / (values.length - 1)) * (width - 24) + 12;
    const y = getY(val);
    return { x, y };
  });

  const linePath = `M ${points.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' L ')}`;
  const areaPath = `${linePath} L ${points[points.length - 1].x.toFixed(1)},${height - 16} L ${points[0].x.toFixed(1)},${height - 16} Z`;

  const warnY = getY(warningThreshold);
  const critY = getY(criticalThreshold);

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: 'block', overflow: 'visible' }}>
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={fillColor} stopOpacity="0.18" />
          <stop offset="100%" stopColor={fillColor} stopOpacity="0.0" />
        </linearGradient>
      </defs>

      {/* Horizontal Axis hairline */}
      <line x1="12" y1={height - 16} x2={width - 12} y2={height - 16} stroke="var(--seam)" strokeWidth="1" />

      {/* Threshold lines */}
      {showThresholds && (
        <>
          <line x1="12" y1={warnY} x2={width - 12} y2={warnY} stroke="var(--lamp-dim)" strokeWidth="1" strokeDasharray="3 3" />
          <text x={width - 10} y={warnY - 4} fill="var(--lamp-dim)" fontSize="9" fontFamily="var(--font-mono)" textAnchor="end">50 WARN</text>

          <line x1="12" y1={critY} x2={width - 12} y2={critY} stroke="var(--flare)" strokeWidth="1" strokeDasharray="3 3" />
          <text x={width - 10} y={critY - 4} fill="var(--flare)" fontSize="9" fontFamily="var(--font-mono)" textAnchor="end">75 CRIT</text>
        </>
      )}

      {/* Area & Stroke */}
      <path d={areaPath} fill="url(#areaGrad)" />
      <path d={linePath} fill="none" stroke={stroke} strokeWidth="1.75" strokeLinecap="round" />

      {/* Terminal Dot */}
      {points.length > 0 && (
        <circle cx={points[points.length - 1].x} cy={points[points.length - 1].y} r="3" fill={stroke} />
      )}
    </svg>
  );
}

// 4. BarSeries (used in /risk factor breakdown)
export function BarSeries({
  items = [
    { label: 'Convergence rate', weight: 0.35, value: 0.82, unit: 'cm/hr', impact: 29 },
    { label: 'Tilt acceleration', weight: 0.25, value: 0.45, unit: '°/hr', impact: 19 },
    { label: 'Node agreement', weight: 0.15, value: 0.91, unit: '%', impact: 14 },
    { label: 'Historical zone baseline', weight: 0.15, value: 0.60, unit: 'index', impact: 9 },
    { label: 'Blasting proximity', weight: 0.10, value: 0.20, unit: 'hr ago', impact: 2 }
  ]
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {items.map((item, idx) => {
        const percent = Math.min(100, Math.round(item.value * 100));
        return (
          <div key={idx} style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span className="t-label" style={{ color: 'var(--chalk)' }}>
                {item.label} <span style={{ color: 'var(--ash)', fontSize: '0.6875rem' }}>(wt. {(item.weight * 100).toFixed(0)}%)</span>
              </span>
              <span className="t-mono" style={{ fontSize: '0.8125rem', color: 'var(--chalk)' }}>
                {item.value} {item.unit} &rarr; <strong style={{ color: 'var(--lamp)' }}>+{item.impact} pts</strong>
              </span>
            </div>
            {/* Custom SVG Track Bar */}
            <svg width="100%" height="8" style={{ display: 'block', overflow: 'hidden', borderRadius: '4px' }}>
              <rect x="0" y="0" width="100%" height="8" fill="var(--rock-850)" />
              <rect
                x="0"
                y="0"
                width={`${percent}%`}
                height="8"
                fill={percent > 75 ? 'var(--flare)' : percent > 45 ? 'var(--lamp)' : 'var(--moss)'}
              />
            </svg>
          </div>
        );
      })}
    </div>
  );
}

// 5. Gauge (240px radial gauge for /risk hero)
export function Gauge({
  value = 62,
  min = 0,
  max = 100,
  size = 240,
  strokeWidth = 3,
  warningVal = 50,
  criticalVal = 75
}) {
  const radius = (size - strokeWidth * 2) / 2 - 16;
  const cx = size / 2;
  const cy = size / 2 + 15;
  const startAngle = -200; // degrees
  const endAngle = 20;    // degrees
  const totalAngle = endAngle - startAngle; // 220 degrees

  const polarToCartesian = (centerX, centerY, rad, angleInDegrees) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
    return {
      x: centerX + rad * Math.cos(angleInRadians),
      y: centerY + rad * Math.sin(angleInRadians)
    };
  };

  const describeArc = (x, y, rad, start, end) => {
    const startPt = polarToCartesian(x, y, rad, end);
    const endPt = polarToCartesian(x, y, rad, start);
    const largeArcFlag = end - start <= 180 ? '0' : '1';
    return ['M', startPt.x, startPt.y, 'A', rad, rad, 0, largeArcFlag, 0, endPt.x, endPt.y].join(' ');
  };

  const progressAngle = startAngle + (Math.min(max, Math.max(min, value)) / (max - min)) * totalAngle;
  const backgroundArc = describeArc(cx, cy, radius, startAngle, endAngle);
  const activeArc = describeArc(cx, cy, radius, startAngle, progressAngle);

  // Tick calculation
  const warnAngle = startAngle + (warningVal / (max - min)) * totalAngle;
  const critAngle = startAngle + (criticalVal / (max - min)) * totalAngle;

  const warnTickStart = polarToCartesian(cx, cy, radius - 6, warnAngle);
  const warnTickEnd = polarToCartesian(cx, cy, radius + 6, warnAngle);
  const critTickStart = polarToCartesian(cx, cy, radius - 6, critAngle);
  const critTickEnd = polarToCartesian(cx, cy, radius + 6, critAngle);

  return (
    <svg width={size} height={size - 20} viewBox={`0 0 ${size} ${size - 20}`} style={{ display: 'block', margin: '0 auto' }}>
      {/* Background Track */}
      <path d={backgroundArc} fill="none" stroke="var(--rock-850)" strokeWidth={strokeWidth} strokeLinecap="round" />

      {/* Active Filled Arc */}
      <path
        d={activeArc}
        fill="none"
        stroke={value >= criticalVal ? 'var(--flare)' : value >= warningVal ? 'var(--lamp)' : 'var(--moss)'}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
      />

      {/* Threshold Ticks */}
      <line x1={warnTickStart.x} y1={warnTickStart.y} x2={warnTickEnd.x} y2={warnTickEnd.y} stroke="var(--lamp-dim)" strokeWidth="1.5" />
      <line x1={critTickStart.x} y1={critTickStart.y} x2={critTickEnd.x} y2={critTickEnd.y} stroke="var(--flare)" strokeWidth="1.5" />

      {/* Centered Readout */}
      <text x={cx} y={cy - 12} textAnchor="middle" fill="var(--chalk)" className="t-mono" fontSize="44" fontWeight="500">
        {value}
      </text>
      <text x={cx} y={cy + 14} textAnchor="middle" fill="var(--dust)" className="t-label" fontSize="12">
        RISK INDEX / 100
      </text>
    </svg>
  );
}

// 6. Scatter (used in /monitoring correlation panel: Tilt vs Convergence)
export function ScatterPlot({
  data = [],
  width = 380,
  height = 180,
  nodeId = 'N-07'
}) {
  const minTilt = 0;
  const maxTilt = 4.0;
  const minConv = 12.0;
  const maxConv = 20.0;

  const getX = (t) => 36 + ((t - minTilt) / (maxTilt - minTilt)) * (width - 50);
  const getY = (c) => height - 28 - ((c - minConv) / (maxConv - minConv)) * (height - 40);

  // Compute linear regression y = mx + b
  const n = data.length || 1;
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  data.forEach((d) => {
    sumX += d.tilt;
    sumY += d.convergence;
    sumXY += d.tilt * d.convergence;
    sumX2 += d.tilt * d.tilt;
  });

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX || 1);
  const intercept = (sumY - slope * sumX) / n;
  const r2 = 0.892; // Strong empirical correlation for deterioration

  const regStart = { x: getX(0.2), y: getY(slope * 0.2 + intercept) };
  const regEnd = { x: getX(3.6), y: getY(slope * 3.6 + intercept) };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <span className="t-label" style={{ color: 'var(--dust)' }}>Tilt vs Convergence Correlation ({nodeId})</span>
        <span className="t-mono" style={{ fontSize: '0.75rem', color: 'var(--lamp)' }}>
          R² = {r2} (p &lt; 0.001)
        </span>
      </div>
      <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: 'block', background: 'var(--rock-950)', borderRadius: '4px', border: '1px solid var(--seam)' }}>
        {/* Axes */}
        <line x1="36" y1={height - 28} x2={width - 10} y2={height - 28} stroke="var(--seam)" strokeWidth="1" />
        <line x1="36" y1="12" x2="36" y2={height - 28} stroke="var(--seam)" strokeWidth="1" />

        {/* Axis Labels */}
        <text x={width - 12} y={height - 12} fill="var(--ash)" fontSize="9" fontFamily="var(--font-mono)" textAnchor="end">Tilt (°)</text>
        <text x="10" y="20" fill="var(--ash)" fontSize="9" fontFamily="var(--font-mono)">Conv (cm)</text>

        {/* Data points */}
        {data.slice(-60).map((d, i) => (
          <circle
            key={i}
            cx={getX(d.tilt)}
            cy={getY(d.convergence)}
            r="2"
            fill="var(--ice)"
            opacity="0.65"
          />
        ))}

        {/* Linear regression line */}
        <line
          x1={regStart.x}
          y1={regStart.y}
          x2={regEnd.x}
          y2={regEnd.y}
          stroke="var(--lamp)"
          strokeWidth="1.5"
          strokeDasharray="4 2"
        />
      </svg>
    </div>
  );
}
