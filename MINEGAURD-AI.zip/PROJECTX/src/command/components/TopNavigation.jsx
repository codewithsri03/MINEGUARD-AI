import React, { useState, useEffect } from 'react';
import { useRouter } from '../../router/Router';
import { useSim } from '../sim/engine';

export function TopNavigation() {
  const { path, navigate } = useRouter();
  const { backendConnected, gatewayState } = useSim();
  const [clockStr, setClockStr] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const year = now.getUTCFullYear();
      const month = String(now.getUTCMonth() + 1).padStart(2, '0');
      const day = String(now.getUTCDate()).padStart(2, '0');
      const hours = String(now.getUTCHours()).padStart(2, '0');
      const mins = String(now.getUTCMinutes()).padStart(2, '0');
      const secs = String(now.getUTCSeconds()).padStart(2, '0');
      setClockStr(`${year}-${month}-${day} ${hours}:${mins}:${secs} UTC`);
    };

    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, []);

  const navLinks = [
    { label: 'MONITORING', route: '/monitoring' },
    { label: 'RISK', route: '/risk' },
    { label: 'DIGITAL TWIN', route: '/section' },
    { label: 'ALERTS', route: '/alerts' },
    { label: 'NODES', route: '/nodes' }
  ];

  return (
    <header
      style={{
        height: '56px',
        backgroundColor: 'rgba(7, 8, 11, 0.88)',
        borderBottom: '1px solid rgba(22, 136, 181, 0.2)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 24px',
        position: 'sticky',
        top: 0,
        zIndex: 45,
        boxSizing: 'border-box'
      }}
    >
      {/* Left: Brand logo linking back to Home */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <button
          onClick={() => navigate('/')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '9px',
            background: 'transparent',
            border: 'none',
            color: 'var(--chalk)',
            cursor: 'pointer',
            padding: 0
          }}
          title="Return to Public Landing Page"
        >
          <span
            style={{
              width: '20px',
              height: '20px',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <svg viewBox="0 0 24 24" fill="none" width="20" height="20">
              <path
                d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                stroke="#00D9FF"
                strokeWidth="2"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          <span
            style={{
              fontFamily: 'var(--font-ui)',
              fontSize: '0.875rem',
              fontWeight: 600,
              letterSpacing: '0.06em',
              color: '#FFFFFF'
            }}
          >
            MINEGUARD AI
          </span>
        </button>
      </div>

      {/* Center: Top Navigation Links */}
      <nav style={{ display: 'flex', alignItems: 'center', gap: '4px' }} aria-label="Command Module Navigation">
        {navLinks.map((item) => {
          const isActive =
            path === item.route || (item.route === '/section' && path === '/digital-twin');

          return (
            <button
              key={item.route}
              onClick={() => navigate(item.route)}
              style={{
                background: isActive ? 'rgba(0, 217, 255, 0.08)' : 'transparent',
                border: isActive ? '1px solid rgba(0, 217, 255, 0.4)' : '1px solid transparent',
                borderRadius: '4px',
                color: isActive ? '#00D9FF' : 'var(--dust)',
                fontFamily: 'var(--font-ui)',
                fontSize: '0.75rem',
                fontWeight: isActive ? 600 : 500,
                letterSpacing: '0.08em',
                padding: '6px 14px',
                cursor: 'pointer',
                transition: 'all 0.15s ease',
                boxShadow: isActive ? '0 0 12px rgba(0, 217, 255, 0.2)' : 'none'
              }}
              onMouseEnter={(e) => {
                if (!isActive) {
                  e.currentTarget.style.color = 'var(--chalk)';
                  e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.04)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isActive) {
                  e.currentTarget.style.color = 'var(--dust)';
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Right: Live System Status & UTC Clock */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {(() => {
          const isHardwareStreaming = backendConnected && (gatewayState?.connected || (gatewayState?.nodesOnline > 0));
          const isStandby = backendConnected && !isHardwareStreaming;
          const isOffline = !backendConnected;

          const statusDotColor = isOffline ? '#FF4D4D' : isStandby ? '#00D9FF' : '#00D6A3';
          const statusLabel = isOffline
            ? 'BACKEND OFFLINE'
            : isStandby
            ? 'BACKEND READY · STANDBY'
            : 'SYSTEM OPERATIONAL';

          const pillLabel = isOffline ? 'OFFLINE' : isStandby ? 'STANDBY' : 'LIVE';
          const pillColor = isOffline ? '#FF4D4D' : isStandby ? '#00D9FF' : '#00D6A3';

          return (
            <>
              <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
                <span
                  style={{
                    width: '7px',
                    height: '7px',
                    borderRadius: '50%',
                    backgroundColor: statusDotColor,
                    boxShadow: `0 0 8px ${statusDotColor}CC`
                  }}
                />
                <span
                  style={{
                    fontFamily: 'var(--font-ui)',
                    fontSize: '0.6875rem',
                    fontWeight: 600,
                    letterSpacing: '0.08em',
                    color: statusDotColor
                  }}
                >
                  {statusLabel}
                </span>
              </div>

              <span
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.6875rem',
                  color: pillColor,
                  backgroundColor: `${pillColor}1A`,
                  border: `1px solid ${pillColor}4D`,
                  padding: '2px 7px',
                  borderRadius: '3px',
                  letterSpacing: '0.06em'
                }}
              >
                {pillLabel}
              </span>
            </>
          );
        })()}

        <span
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '0.75rem',
            color: 'var(--dust)',
            letterSpacing: '0.02em'
          }}
        >
          {clockStr}
        </span>
      </div>
    </header>
  );
}
