import React from 'react';
import { useSim } from '../sim/engine';

export function ChannelSelector({ isPaused, onTogglePause, onExport }) {
  const { nodes, selectedNodeId, setSelectedNode, timeWindow, setTimeWindow } = useSim();

  const channelList = ['N-01', 'N-02', 'N-03', 'N-04', 'N-05', 'N-06', 'N-07', 'N-08'];
  const timeWindows = ['5m', '15m', '1h', '6h', '24h'];

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '12px',
        padding: '10px 16px',
        backgroundColor: 'rgba(7, 8, 11, 0.75)',
        border: '1px solid rgba(22, 136, 181, 0.22)',
        borderRadius: '6px',
        boxSizing: 'border-box'
      }}
    >
      {/* Left: Horizontal Sensor Channels */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
        <span
          className="t-micro"
          style={{
            color: 'var(--dust)',
            marginRight: '6px',
            fontSize: '0.6875rem',
            letterSpacing: '0.08em'
          }}
        >
          CHANNELS:
        </span>

        {channelList.map((id) => {
          const node = nodes[id];
          const isSelected = selectedNodeId === id;
          const isCrit = node?.status === 'critical' || node?.status === 'CRITICAL';
          const isWarn = (node?.status === 'warning' || node?.status === 'WARNING') && !isCrit;
          const isStale = (node?.status === 'stale' || node?.status === 'STALE') && !isCrit && !isWarn;
          const isOffline = !node?.isOnline && node?.status !== 'ONLINE' && !isCrit && !isWarn && !isStale;

          // Color definition matching reference
          let accentColor = '#00D9FF'; // Default cyan
          let dotColor = '#00D9FF';
          let borderStyle = '1px solid rgba(0, 217, 255, 0.25)';
          let bgStyle = 'rgba(0, 217, 255, 0.04)';

          if (isCrit) {
            accentColor = '#FF4D4D';
            dotColor = '#FF4D4D';
            borderStyle = '1px solid rgba(255, 77, 77, 0.35)';
            bgStyle = 'rgba(255, 77, 77, 0.06)';
          } else if (isWarn) {
            accentColor = '#FFB020';
            dotColor = '#FFB020';
            borderStyle = '1px solid rgba(255, 176, 32, 0.4)';
            bgStyle = 'rgba(255, 176, 32, 0.08)';
          } else if (isStale) {
            accentColor = '#FF8800';
            dotColor = '#FF8800';
            borderStyle = '1px solid rgba(255, 136, 0, 0.35)';
            bgStyle = 'rgba(255, 136, 0, 0.06)';
          } else if (isOffline) {
            accentColor = '#717888';
            dotColor = '#5B6271';
            borderStyle = '1px solid rgba(113, 120, 136, 0.25)';
            bgStyle = 'rgba(113, 120, 136, 0.04)';
          }

          if (isSelected) {
            bgStyle = isWarn
              ? 'rgba(255, 176, 32, 0.2)'
              : isCrit
              ? 'rgba(255, 77, 77, 0.22)'
              : isStale
              ? 'rgba(255, 136, 0, 0.2)'
              : isOffline
              ? 'rgba(113, 120, 136, 0.18)'
              : 'rgba(0, 217, 255, 0.18)';
            borderStyle = `1px solid ${accentColor}`;
          }

          return (
            <button
              key={id}
              onClick={() => setSelectedNode(id)}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
                padding: '5px 12px',
                borderRadius: '4px',
                border: borderStyle,
                background: bgStyle,
                color: isSelected ? '#FFFFFF' : accentColor,
                fontFamily: 'var(--font-mono)',
                fontSize: '0.75rem',
                fontWeight: isSelected ? 600 : 500,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
                boxShadow: isSelected ? `0 0 10px ${accentColor}44` : 'none',
                userSelect: 'none'
              }}
              onMouseEnter={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.borderColor = accentColor;
                  e.currentTarget.style.color = '#FFFFFF';
                }
              }}
              onMouseLeave={(e) => {
                if (!isSelected) {
                  e.currentTarget.style.border = borderStyle;
                  e.currentTarget.style.color = accentColor;
                }
              }}
              title={`Select ${id} for telemetry focus`}
            >
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: dotColor,
                  boxShadow: `0 0 6px ${dotColor}`
                }}
              />
              <span>{id}</span>
            </button>
          );
        })}
      </div>

      {/* Right: Time Range Selector + Pause / Export buttons */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
        {/* Time Window Buttons */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            backgroundColor: 'rgba(20, 23, 27, 0.8)',
            border: '1px solid rgba(22, 136, 181, 0.25)',
            borderRadius: '4px',
            padding: '2px'
          }}
        >
          {timeWindows.map((tw) => {
            const isActive = timeWindow === tw;
            return (
              <button
                key={tw}
                onClick={() => setTimeWindow(tw)}
                style={{
                  padding: '4px 10px',
                  fontSize: '0.6875rem',
                  fontFamily: 'var(--font-mono)',
                  border: 'none',
                  borderRadius: '3px',
                  background: isActive ? '#1688B5' : 'transparent',
                  color: isActive ? '#FFFFFF' : 'var(--dust)',
                  cursor: 'pointer',
                  fontWeight: isActive ? 600 : 400,
                  transition: 'all 0.15s ease'
                }}
              >
                {tw}
              </button>
            );
          })}
        </div>

        {/* Action Controls: Pause & Export */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <button
            onClick={onTogglePause}
            className="cmd-btn"
            style={{
              padding: '5px 12px',
              fontSize: '0.6875rem',
              fontWeight: 600,
              fontFamily: 'var(--font-ui)',
              letterSpacing: '0.06em',
              background: isPaused ? 'rgba(255, 176, 32, 0.15)' : 'rgba(20, 23, 27, 0.8)',
              border: `1px solid ${isPaused ? '#FFB020' : 'rgba(22, 136, 181, 0.3)'}`,
              color: isPaused ? '#FFB020' : 'var(--chalk)',
              borderRadius: '4px'
            }}
            title={isPaused ? 'Resume live stream' : 'Pause live telemetry stream'}
          >
            <span style={{ fontSize: '0.75rem' }}>{isPaused ? '▶ RESUME' : '⏸ PAUSE'}</span>
          </button>

          <button
            onClick={onExport}
            className="cmd-btn"
            style={{
              padding: '5px 12px',
              fontSize: '0.6875rem',
              fontWeight: 600,
              fontFamily: 'var(--font-ui)',
              letterSpacing: '0.06em',
              background: 'rgba(0, 217, 255, 0.08)',
              border: '1px solid rgba(0, 217, 255, 0.35)',
              color: '#00D9FF',
              borderRadius: '4px'
            }}
            title="Export historical telemetry data (CSV)"
          >
            <span>⭳ EXPORT</span>
          </button>
        </div>
      </div>
    </div>
  );
}
