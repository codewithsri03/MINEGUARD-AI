import React from 'react';

/**
 * MineGuard Command System — Sticky Page Header (64px)
 * Sentence case for headings, no eyebrow labels, contextual controls only.
 */
export function CommandHeader({
  title,
  subtitle,
  actions
}) {
  return (
    <header
      style={{
        height: 'var(--header-height)',
        borderBottom: '1px solid var(--seam)',
        backgroundColor: 'var(--rock-950)',
        position: 'sticky',
        top: 0,
        zIndex: 40,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 var(--space-3)',
        boxSizing: 'border-box'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '16px' }}>
        <h1 className="t-title" style={{ margin: 0, color: 'var(--chalk)', fontSize: '1.25rem' }}>
          {title}
        </h1>
        {subtitle && (
          <span className="t-body" style={{ color: 'var(--dust)', fontSize: '0.8125rem' }}>
            {subtitle}
          </span>
        )}
      </div>

      {actions && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {actions}
        </div>
      )}
    </header>
  );
}
