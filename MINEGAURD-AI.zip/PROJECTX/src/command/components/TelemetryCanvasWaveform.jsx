import React, { useEffect, useRef } from 'react';

/**
 * TelemetryCanvasWaveform
 * High-performance Canvas 2D telemetry oscilloscope panel.
 * Renders multiple sensor channel traces, highlighted selected warning/critical trace,
 * horizontal threshold lines, continuous right-to-left signal streaming,
 * and synchronized crosshair across all stacked panels.
 */
export function TelemetryCanvasWaveform({
  panelId,
  title,
  unit,
  metricType,
  thresholdDisplay,
  thresholdNumeric,
  thresholdNumericCrit,
  allNodes,
  selectedNodeId,
  isPaused,
  sharedCursor,
  setSharedCursor
}) {
  const canvasRef = useRef(null);
  const animOffsetRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId;
    let isVisible = true;
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const updateDimensions = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(rect.height * dpr);
      ctx.scale(dpr, dpr);
    };

    updateDimensions();

    const resizeObserver = new ResizeObserver(() => {
      updateDimensions();
    });
    resizeObserver.observe(canvas);

    const onVisibilityChange = () => {
      isVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    const render = () => {
      animationFrameId = requestAnimationFrame(render);
      if (!isVisible) return;

      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;

      if (!isPaused && !prefersReducedMotion) {
        animOffsetRef.current += 0.8;
      }

      // 1. Clear background (Deep dark instrument surface)
      ctx.fillStyle = '#05070A';
      ctx.fillRect(0, 0, width, height);

      // 2. Subtle Engineering Grid
      ctx.strokeStyle = 'rgba(22, 136, 181, 0.07)';
      ctx.lineWidth = 1;
      ctx.setLineDash([]);

      const gridX = 48;
      const gridY = 28;

      // Vertical grid lines
      const xShift = (animOffsetRef.current % gridX);
      for (let x = width - xShift; x >= 0; x -= gridX) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }

      // Horizontal grid lines
      for (let y = gridY; y < height; y += gridY) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Scale calculations based on metric type
      let minVal = 0;
      let maxVal = 25;

      if (metricType === 'convergence') {
        minVal = 10.0;
        maxVal = 22.0; // cm
      } else if (metricType === 'tilt') {
        minVal = 0.0;
        maxVal = 4.0; // degrees
      } else if (metricType === 'delta') {
        minVal = -0.04;
        maxVal = 0.04; // cm/s
      }

      const valToY = (val) => {
        const clamped = Math.max(minVal, Math.min(maxVal, val));
        const norm = (clamped - minVal) / (maxVal - minVal);
        return height - 16 - norm * (height - 32);
      };

      // 3. Threshold Lines
      if (thresholdNumeric !== undefined) {
        const threshY = valToY(thresholdNumeric);

        ctx.beginPath();
        ctx.setLineDash([5, 4]);
        ctx.strokeStyle = 'rgba(255, 176, 32, 0.45)';
        ctx.lineWidth = 1.2;
        ctx.moveTo(0, threshY);
        ctx.lineTo(width - 55, threshY);
        ctx.stroke();

        // Label on right axis
        ctx.font = '500 10px "JetBrains Mono", monospace';
        ctx.fillStyle = '#FFB020';
        ctx.textAlign = 'right';
        ctx.fillText(thresholdDisplay, width - 8, threshY + 3);
      }

      if (thresholdNumericCrit !== undefined) {
        const critY = valToY(thresholdNumericCrit);

        ctx.beginPath();
        ctx.setLineDash([4, 3]);
        ctx.strokeStyle = 'rgba(255, 77, 77, 0.55)';
        ctx.lineWidth = 1.2;
        ctx.moveTo(0, critY);
        ctx.lineTo(width - 55, critY);
        ctx.stroke();

        ctx.font = '500 10px "JetBrains Mono", monospace';
        ctx.fillStyle = '#FF4D4D';
        ctx.textAlign = 'right';
        ctx.fillText('CRIT', width - 8, critY + 3);
      }

      ctx.setLineDash([]);

      // 4. Draw All Inactive Traces (Cyan background multi-channel field)
      const nodeKeys = Object.keys(allNodes);

      nodeKeys.forEach((nodeId) => {
        if (nodeId === selectedNodeId) return; // Drawn last for emphasis

        const node = allNodes[nodeId];
        if (!node || !node.history || node.history.length === 0) return;

        const history = node.history;
        const totalPoints = history.length;

        ctx.beginPath();
        ctx.strokeStyle = 'rgba(0, 217, 255, 0.22)';
        ctx.lineWidth = 1.0;

        for (let i = 0; i < totalPoints; i++) {
          const x = (i / (totalPoints - 1)) * (width - 65);
          let rawVal = 0;

          if (metricType === 'convergence') {
            rawVal = history[i].convergence;
          } else if (metricType === 'tilt') {
            rawVal = history[i].tilt;
          } else {
            // Delta Rate: derived derivative
            const prev = history[Math.max(0, i - 1)].convergence;
            const curr = history[i].convergence;
            rawVal = (curr - prev) * 0.4;
          }

          const y = valToY(rawVal);

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      });

      // 5. Draw Highlighted Selected Sensor Trace (N-04 / Selected)
      const activeNode = allNodes[selectedNodeId] || allNodes['N-01'];
      let activeCoordAtCursor = null;

      if (activeNode && activeNode.history && activeNode.history.length > 0) {
        const history = activeNode.history;
        const totalPoints = history.length;

        const statusUpper = (activeNode.status || '').toUpperCase();
        const isWarn = statusUpper === 'WARNING';
        const isCrit = statusUpper === 'CRITICAL';

        const strokeCol = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : '#00D9FF';

        ctx.beginPath();
        ctx.strokeStyle = strokeCol;
        ctx.lineWidth = 2.4;
        ctx.shadowColor = strokeCol;
        ctx.shadowBlur = 8;

        let lastX = 0;
        let lastY = 0;

        for (let i = 0; i < totalPoints; i++) {
          const x = (i / (totalPoints - 1)) * (width - 65);
          let rawVal = 0;

          if (metricType === 'convergence') {
            rawVal = history[i].convergence;
          } else if (metricType === 'tilt') {
            rawVal = history[i].tilt;
          } else {
            const prev = history[Math.max(0, i - 1)].convergence;
            const curr = history[i].convergence;
            rawVal = (curr - prev) * 0.4;
          }

          const y = valToY(rawVal);

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }

          lastX = x;
          lastY = y;

          // Track value at synchronized cursor fraction
          if (sharedCursor && sharedCursor.fraction !== null) {
            const cursorX = sharedCursor.fraction * (width - 65);
            if (Math.abs(x - cursorX) <= (width - 65) / totalPoints) {
              activeCoordAtCursor = { x, y, rawVal, time: history[i].timestamp };
            }
          }
        }

        ctx.stroke();
        ctx.shadowBlur = 0; // Reset blur

        // Pulse dot at right leading edge
        ctx.beginPath();
        ctx.arc(lastX, lastY, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = strokeCol;
        ctx.shadowColor = strokeCol;
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;
      } else {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
        ctx.font = '500 11px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText('Awaiting live telemetry packets...', (width - 65) / 2, height / 2);
      }

      // 6. Synchronized Crosshair & Marker
      if (sharedCursor && sharedCursor.fraction !== null) {
        const crosshairX = sharedCursor.fraction * (width - 65);

        ctx.beginPath();
        ctx.setLineDash([3, 3]);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.lineWidth = 1;
        ctx.moveTo(crosshairX, 0);
        ctx.lineTo(crosshairX, height);
        ctx.stroke();
        ctx.setLineDash([]);

        if (activeCoordAtCursor) {
          // Circle marker on selected trace at crosshair
          ctx.beginPath();
          ctx.arc(activeCoordAtCursor.x, activeCoordAtCursor.y, 4.5, 0, Math.PI * 2);
          ctx.fillStyle = '#FFFFFF';
          ctx.strokeStyle = '#FFB020';
          ctx.lineWidth = 2;
          ctx.shadowColor = '#FFB020';
          ctx.shadowBlur = 12;
          ctx.fill();
          ctx.stroke();
          ctx.shadowBlur = 0;
        }
      }
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [
    metricType,
    thresholdNumeric,
    thresholdNumericCrit,
    thresholdDisplay,
    allNodes,
    selectedNodeId,
    isPaused,
    sharedCursor
  ]);

  // Mouse Interaction handlers for synchronized crosshair
  const handleMouseMove = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    const effectiveWidth = rect.width - 65;

    if (relX >= 0 && relX <= effectiveWidth) {
      const frac = relX / effectiveWidth;

      // Extract sample from active node history at fraction
      const activeNode = allNodes[selectedNodeId] || allNodes['N-04'];
      let sampleVal = null;
      let timestamp = Date.now();

      if (activeNode && activeNode.history && activeNode.history.length > 0) {
        const idx = Math.min(
          activeNode.history.length - 1,
          Math.max(0, Math.floor(frac * activeNode.history.length))
        );
        const item = activeNode.history[idx];
        timestamp = item.timestamp;

        if (metricType === 'convergence') sampleVal = `${item.convergence.toFixed(2)} cm`;
        else if (metricType === 'tilt') sampleVal = `${item.tilt.toFixed(2)}°`;
        else sampleVal = `${(activeNode.deltaRate || 0.003).toFixed(3)} cm/s`;
      }

      setSharedCursor({
        fraction: frac,
        clientX: e.clientX,
        clientY: e.clientY,
        timestamp,
        nodeId: selectedNodeId,
        panelId,
        metricType,
        sampleVal,
        thresholdDisplay
      });
    }
  };

  const handleMouseLeave = () => {
    setSharedCursor(null);
  };

  const activeNode = allNodes[selectedNodeId] || allNodes['N-01'] || Object.values(allNodes)[0];
  let currentValStr = 'N/A';
  if (activeNode) {
    if (metricType === 'convergence') {
      currentValStr = activeNode.currentConvergence != null ? `${activeNode.currentConvergence.toFixed(1)} cm` : 'N/A';
    } else if (metricType === 'tilt') {
      currentValStr = activeNode.currentTilt != null ? `${activeNode.currentTilt.toFixed(2)}°` : 'N/A';
    } else {
      currentValStr = activeNode.deltaRate != null ? `${activeNode.deltaRate > 0 ? `+${activeNode.deltaRate.toFixed(3)}` : activeNode.deltaRate.toFixed(3)} cm/s` : 'N/A';
    }
  }

  const isCrit = activeNode?.status === 'critical' || activeNode?.status === 'CRITICAL';
  const isWarn = (activeNode?.status === 'warning' || activeNode?.status === 'WARNING') && !isCrit;
  const isStale = (activeNode?.status === 'stale' || activeNode?.status === 'STALE') && !isCrit && !isWarn;
  const isOffline = !activeNode?.isOnline && activeNode?.status !== 'ONLINE' && !isCrit && !isWarn && !isStale;
  const badgeColor = isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : isStale ? '#FF8800' : isOffline ? '#717888' : '#00D9FF';

  return (
    <div
      style={{
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: 'rgba(7, 8, 11, 0.85)',
        border: '1px solid rgba(22, 136, 181, 0.22)',
        borderRadius: '6px',
        overflow: 'hidden',
        boxSizing: 'border-box'
      }}
    >
      {/* Panel Header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '8px 14px',
          borderBottom: '1px solid rgba(22, 136, 181, 0.15)',
          backgroundColor: 'rgba(12, 14, 18, 0.65)'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px' }}>
          <span
            style={{
              fontFamily: 'var(--font-ui)',
              fontSize: '0.8125rem',
              fontWeight: 600,
              letterSpacing: '0.04em',
              color: '#FFFFFF'
            }}
          >
            {title}
          </span>
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.6875rem',
              color: 'var(--dust)'
            }}
          >
            [{unit}]
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.6875rem',
              color: 'var(--ash)'
            }}
          >
            Threshold: {thresholdDisplay}
          </span>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '2px 8px',
              borderRadius: '3px',
              backgroundColor: `${badgeColor}18`,
              border: `1px solid ${badgeColor}40`
            }}
          >
            <span
              style={{
                width: '5px',
                height: '5px',
                borderRadius: '50%',
                backgroundColor: badgeColor,
                boxShadow: `0 0 6px ${badgeColor}`
              }}
            />
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '0.75rem',
                fontWeight: 600,
                color: badgeColor
              }}
            >
              {selectedNodeId}: {currentValStr}
            </span>
          </div>
        </div>
      </div>

      {/* Canvas Area */}
      <div
        style={{
          position: 'relative',
          width: '100%',
          height: '160px',
          cursor: 'crosshair'
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
      >
        <canvas
          ref={canvasRef}
          style={{
            width: '100%',
            height: '100%',
            display: 'block'
          }}
        />
      </div>
    </div>
  );
}
