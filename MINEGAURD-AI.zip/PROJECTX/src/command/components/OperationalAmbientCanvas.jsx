import React, { useEffect, useRef } from 'react';
import { useRouter } from '../../router/Router';

/**
 * OperationalAmbientCanvas
 * Dedicated 2D Canvas ambient environment for all non-Home command pages.
 * Completely independent from Home's WebGL particle scene.
 *
 * Visual characteristics:
 * - Almost black background (#020507 / #030609)
 * - Fine blue/cyan particles (#00D9FF, #1688B5)
 * - Faint data-network traces connecting nearby nodes
 * - Sparse amber particles (#FFB020) and occasional critical red points
 * - Continuous slow organic drift via requestAnimationFrame
 * - Route-aware: adjusts particle flow slightly based on active command route
 * - Pauses on document.hidden
 * - Respects prefers-reduced-motion
 */
export function OperationalAmbientCanvas() {
  const canvasRef = useRef(null);
  const { path } = useRouter();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId;
    let isVisible = true;
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Responsive canvas dimensions
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const onResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize);

    const onVisibilityChange = () => {
      isVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    // Particle pool: 140 fine particles desktop, 70 mobile
    const count = window.innerWidth < 768 ? 70 : 140;
    const particles = [];

    const cyanPalette = ['#00D9FF', '#1688B5', '#4FD8FF', '#2E4C57'];
    const amberPalette = ['#FFB020', '#F2A93B'];
    const redPalette = ['#FF4D4D', '#E0533F'];

    for (let i = 0; i < count; i++) {
      const rand = Math.random();
      const isRed = rand < 0.05; // 5% critical red points
      const isAmber = !isRed && rand < 0.18; // 13% amber points

      const color = isRed
        ? redPalette[Math.floor(Math.random() * redPalette.length)]
        : isAmber
        ? amberPalette[Math.floor(Math.random() * amberPalette.length)]
        : cyanPalette[Math.floor(Math.random() * cyanPalette.length)];

      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        radius: Math.random() * 1.3 + 0.6,
        color,
        alpha: Math.random() * 0.4 + 0.15,
        pulseSpeed: Math.random() * 0.02 + 0.01,
        pulseOffset: Math.random() * Math.PI * 2
      });
    }

    let time = 0;

    const render = () => {
      animationFrameId = requestAnimationFrame(render);
      if (!isVisible) return;

      time += 0.01;

      // Deep void clear
      ctx.fillStyle = '#020507';
      ctx.fillRect(0, 0, width, height);

      // Subtle atmospheric technical grid
      ctx.strokeStyle = 'rgba(22, 136, 181, 0.03)';
      ctx.lineWidth = 1;
      const gridSize = 120;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Update & Render particles
      for (let i = 0; i < count; i++) {
        const p = particles[i];

        if (!prefersReducedMotion) {
          p.x += p.vx;
          p.y += p.vy;

          // Route-specific subtle force
          if (path === '/monitoring') {
            p.x += 0.08; // Subtle horizontal telemetry current
          } else if (path === '/risk') {
            // Gentle convergence toward upper-center
            p.x += (width * 0.5 - p.x) * 0.00004;
            p.y += (height * 0.4 - p.y) * 0.00004;
          }

          // Boundary wrapping
          if (p.x < 0) p.x = width;
          if (p.x > width) p.x = 0;
          if (p.y < 0) p.y = height;
          if (p.y > height) p.y = 0;
        }

        const currentAlpha = p.alpha * (0.8 + 0.2 * Math.sin(time + p.pulseOffset));

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = currentAlpha;
        ctx.shadowBlur = 4;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        // Faint network connection lines between nearby particles
        for (let j = i + 1; j < count; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const distSq = dx * dx + dy * dy;
          const maxDist = 100;

          if (distSq < maxDist * maxDist) {
            const dist = Math.sqrt(distSq);
            const lineAlpha = (1 - dist / maxDist) * 0.08;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = '#00D9FF';
            ctx.globalAlpha = lineAlpha;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      ctx.globalAlpha = 1.0;
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [path]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        zIndex: 0,
        pointerEvents: 'none',
        display: 'block'
      }}
      aria-hidden="true"
    />
  );
}
