import React from 'react';
import { useSim } from '../sim/engine';

export function MetricStrip() {
  const { nodes, gatewayState, mineRisk } = useSim();
  const onlineCount = gatewayState.connected ? gatewayState.nodesOnline : Object.values(nodes).filter((n) => n.isOnline).length;
  const totalCount = gatewayState.totalNodes || Object.keys(nodes).length;

  const statusSubtext =
    onlineCount === 0
      ? 'Standby · No Nodes'
      : onlineCount === totalCount
      ? 'All Nodes Online'
      : `${onlineCount} of ${totalCount} Active`;

  const isHealthy = onlineCount > 0 && mineRisk < 70;

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
        gap: '12px',
        width: '100%'
      }}
    >
      {/* 1. Active Channels */}
      <div
        className="panel"
        style={{
          padding: '12px 16px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          backgroundColor: 'rgba(7, 8, 11, 0.75)',
          border: '1px solid rgba(22, 136, 181, 0.22)',
          borderRadius: '6px',
          boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.04)'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span
            className="t-micro"
            style={{ color: 'var(--dust)', letterSpacing: '0.08em', fontSize: '0.6875rem' }}
          >
            ACTIVE CHANNELS
          </span>
          <span
            style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              backgroundColor: onlineCount > 0 ? '#00D6A3' : '#FFB020',
              boxShadow: onlineCount > 0 ? '0 0 6px rgba(0, 214, 163, 0.7)' : 'none'
            }}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginTop: '6px' }}>
          <span
            className="t-mono"
            style={{ fontSize: '1.4rem', fontWeight: 600, color: '#FFFFFF', lineHeight: 1 }}
          >
            {onlineCount} / {totalCount}
          </span>
          <span style={{ fontSize: '0.75rem', color: 'var(--dust)' }}>{statusSubtext}</span>
        </div>
      </div>

      {/* 2. Sample Rate */}
      <div
        className="panel"
        style={{
          padding: '12px 16px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          backgroundColor: 'rgba(7, 8, 11, 0.75)',
          border: '1px solid rgba(22, 136, 181, 0.22)',
          borderRadius: '6px',
          boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.04)'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span
            className="t-micro"
            style={{ color: 'var(--dust)', letterSpacing: '0.08em', fontSize: '0.6875rem' }}
          >
            SAMPLE RATE
          </span>
          <span style={{ color: onlineCount > 0 ? '#00D9FF' : 'var(--dust)', fontSize: '0.75rem', fontFamily: 'var(--font-mono)' }}>
            {onlineCount > 0 ? '1000ms' : 'Standby'}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginTop: '6px' }}>
          <span
            className="t-mono"
            style={{ fontSize: '1.4rem', fontWeight: 600, color: onlineCount > 0 ? '#00D9FF' : 'var(--dust)', lineHeight: 1 }}
          >
            {onlineCount > 0 ? '1.0 Hz' : '0.0 Hz'}
          </span>
          <span style={{ fontSize: '0.75rem', color: 'var(--dust)' }}>
            {onlineCount > 0 ? 'Wi-Fi Ingest' : 'Awaiting Packets'}
          </span>
        </div>
      </div>

      {/* 3. Data Latency */}
      <div
        className="panel"
        style={{
          padding: '12px 16px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          backgroundColor: 'rgba(7, 8, 11, 0.75)',
          border: '1px solid rgba(22, 136, 181, 0.22)',
          borderRadius: '6px',
          boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.04)'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span
            className="t-micro"
            style={{ color: 'var(--dust)', letterSpacing: '0.08em', fontSize: '0.6875rem' }}
          >
            DATA LATENCY
          </span>
          <span style={{ color: onlineCount > 0 ? '#00D6A3' : 'var(--dust)', fontSize: '0.75rem', fontFamily: 'var(--font-mono)' }}>
            {onlineCount > 0 ? 'Wi-Fi / Mesh' : 'Inactive'}
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginTop: '6px' }}>
          <span
            className="t-mono"
            style={{ fontSize: '1.4rem', fontWeight: 600, color: onlineCount > 0 ? '#FFFFFF' : 'var(--dust)', lineHeight: 1 }}
          >
            {onlineCount > 0 ? '42 ms' : '——'}
          </span>
          <span style={{ fontSize: '0.75rem', color: 'var(--dust)' }}>
            {onlineCount > 0 ? 'Gateway RT' : 'Standby'}
          </span>
        </div>
      </div>

      {/* 4. System Health */}
      <div
        className="panel"
        style={{
          padding: '12px 16px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          backgroundColor: 'rgba(7, 8, 11, 0.75)',
          border: '1px solid rgba(22, 136, 181, 0.22)',
          borderRadius: '6px',
          boxShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.04)'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span
            className="t-micro"
            style={{ color: 'var(--dust)', letterSpacing: '0.08em', fontSize: '0.6875rem' }}
          >
            SYSTEM HEALTH
          </span>
          {/* Small circular health indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <svg width="14" height="14" viewBox="0 0 20 20">
              <circle
                cx="10"
                cy="10"
                r="7"
                fill="none"
                stroke={isHealthy ? 'rgba(0, 214, 163, 0.2)' : 'rgba(255, 176, 32, 0.2)'}
                strokeWidth="2.5"
              />
              <circle
                cx="10"
                cy="10"
                r="7"
                fill="none"
                stroke={isHealthy ? '#00D6A3' : '#FFB020'}
                strokeWidth="2.5"
                strokeDasharray="44"
                strokeDashoffset={isHealthy ? '1' : '15'}
                strokeLinecap="round"
                transform="rotate(-90 10 10)"
              />
            </svg>
            <span
              style={{
                color: isHealthy ? '#00D6A3' : '#FFB020',
                fontSize: '0.75rem',
                fontWeight: 600,
                fontFamily: 'var(--font-mono)'
              }}
            >
              {onlineCount > 0 ? (isHealthy ? 'Nominal' : 'Elevated') : 'Standby'}
            </span>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginTop: '6px' }}>
          <span
            className="t-mono"
            style={{ fontSize: '1.4rem', fontWeight: 600, color: onlineCount > 0 ? '#FFFFFF' : 'var(--dust)', lineHeight: 1 }}
          >
            {onlineCount > 0 ? '99.8%' : '——'}
          </span>
          <span style={{ fontSize: '0.75rem', color: 'var(--dust)' }}>
            {onlineCount > 0 ? 'MTBF > 4,200h' : 'Awaiting Nodes'}
          </span>
        </div>
      </div>
    </div>
  );
}
