import React, { useState, useEffect } from 'react';
import { useRouter } from '../../router/Router';
import { useSim } from '../sim/engine';
import {
  Activity,
  ShieldAlert,
  GitCommit,
  Bell,
  Cpu,
  ArrowLeft
} from 'lucide-react';

/**
 * MineGuard Command System — Left Navigation Rail
 * Fixed 72px width, icon + label expands to 200px on hover.
 * Exactly ONE nav element (no floating pill).
 * System status dot at top, live shift clock at bottom.
 */
export function NavRail() {
  const { path, navigate } = useRouter();
  const { mineRisk } = useSim();
  const [timeStr, setTimeStr] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);

  // Live UTC / Mine Shift Clock
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const hours = String(d.getUTCHours()).padStart(2, '0');
      const mins = String(d.getUTCMinutes()).padStart(2, '0');
      const secs = String(d.getUTCSeconds()).padStart(2, '0');
      setTimeStr(`${hours}:${mins}:${secs} UTC`);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { label: 'Live Telemetry', route: '/monitoring', icon: Activity },
    { label: 'Risk Analysis', route: '/risk', icon: ShieldAlert },
    { label: 'Mine Section', route: '/section', icon: GitCommit },
    { label: 'Alerts', route: '/alerts', icon: Bell },
    { label: 'Sensor Fleet', route: '/nodes', icon: Cpu }
  ];

  return (
    <nav
      className="nav-rail"
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
      style={{
        position: 'fixed',
        left: 0,
        top: 0,
        bottom: 'var(--ticker-height)',
        width: isExpanded ? 'var(--rail-expanded-width)' : 'var(--rail-collapsed-width)',
        backgroundColor: 'var(--rock-900)',
        borderRight: '1px solid var(--seam)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        zIndex: 50,
        transition: 'width 0.2s cubic-bezier(0.16, 1, 0.3, 1)',
        overflow: 'hidden',
        boxShadow: isExpanded ? '4px 0 24px rgba(0,0,0,0.5)' : 'none'
      }}
      aria-label="Command System Navigation"
    >
      {/* Top Branding & Status Dot */}
      <div style={{ padding: '16px 14px', borderBottom: '1px solid var(--seam)', display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div
          style={{
            width: '10px',
            height: '10px',
            borderRadius: '50%',
            backgroundColor: mineRisk >= 75 ? 'var(--flare)' : mineRisk >= 50 ? 'var(--lamp)' : 'var(--moss)',
            flexShrink: 0
          }}
          title={`System Health: ${mineRisk >= 75 ? 'Critical' : mineRisk >= 50 ? 'Warning' : 'Nominal'}`}
        />
        {isExpanded && (
          <div style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden', whiteSpace: 'nowrap' }}>
            <span style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.875rem', color: 'var(--chalk)' }}>
              MineGuard AI
            </span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6875rem', color: 'var(--dust)' }}>
              OPS DESK v2.0
            </span>
          </div>
        )}
      </div>

      {/* Nav Item List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', padding: '12px 8px', flex: 1 }}>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = path === item.route || (item.route === '/section' && path === '/digital-twin');

          return (
            <button
              key={item.route}
              onClick={() => navigate(item.route)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '14px',
                padding: '10px 14px',
                width: '100%',
                borderRadius: 'var(--panel-radius)',
                border: 'none',
                background: isActive ? 'var(--rock-800)' : 'transparent',
                color: isActive ? 'var(--lamp)' : 'var(--dust)',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 0.15s ease',
                outline: 'none',
                whiteSpace: 'nowrap'
              }}
              onMouseEnter={(e) => {
                if (!isActive) {
                  e.currentTarget.style.backgroundColor = 'var(--rock-850)';
                  e.currentTarget.style.color = 'var(--chalk)';
                }
              }}
              onMouseLeave={(e) => {
                if (!isActive) {
                  e.currentTarget.style.backgroundColor = 'transparent';
                  e.currentTarget.style.color = 'var(--dust)';
                }
              }}
              title={!isExpanded ? item.label : undefined}
            >
              <Icon size={20} style={{ flexShrink: 0 }} />
              {isExpanded && (
                <span style={{ fontFamily: 'var(--font-ui)', fontSize: '0.8125rem', fontWeight: isActive ? 600 : 400 }}>
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Return to Public Home & Bottom Live Clock */}
      <div style={{ borderTop: '1px solid var(--seam)', padding: '12px 10px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        <button
          onClick={() => navigate('/')}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '8px 12px',
            borderRadius: 'var(--panel-radius)',
            border: '1px solid var(--seam)',
            background: 'var(--rock-850)',
            color: 'var(--dust)',
            cursor: 'pointer',
            fontSize: '0.75rem',
            whiteSpace: 'nowrap'
          }}
          title="Return to Public Overview"
        >
          <ArrowLeft size={16} style={{ flexShrink: 0 }} />
          {isExpanded && <span>Public Home</span>}
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '4px 6px', overflow: 'hidden' }}>
          <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--ash)', whiteSpace: 'nowrap' }}>
            {isExpanded ? timeStr : timeStr.slice(0, 5)}
          </span>
        </div>
      </div>
    </nav>
  );
}
