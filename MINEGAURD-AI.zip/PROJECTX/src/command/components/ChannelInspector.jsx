import React, { useState, useEffect } from 'react';
import { useSim, ZONES_METADATA } from '../sim/engine';
import { useRouter } from '../../router/Router';

/**
 * Node Sensor Details Inspector
 * Displays real-time hardware telemetry from ESP32, environmental conditions, and backend node status.
 *
 * Requirements:
 * - HC-SR04 distance (cm) & displacement (mm)
 * - MPU9250 motion/IMU (accel x/y/z, vibration, tilt in degrees)
 * - Temperature (°C), Humidity (%), Pressure (hPa), Gas (ADC), Rain (ADC)
 * - Source indicator (HARDWARE vs SIMULATOR)
 * - Real node status: ONLINE, STALE, DISCONNECTED, ERROR (No hardcoded LIVE)
 * - Displays "N/A" when telemetry is unavailable
 */
export function ChannelInspector() {
  const { nodes, selectedNodeId } = useSim();
  const { navigate } = useRouter();
  const [timeStr, setTimeStr] = useState('');

  const [nowMs, setNowMs] = useState(() => Date.now());

  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      const h = String(d.getHours()).padStart(2, '0');
      const m = String(d.getMinutes()).padStart(2, '0');
      const s = String(d.getSeconds()).padStart(2, '0');
      setTimeStr(`${h}:${m}:${s}`);
      setNowMs(Date.now());
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const activeNode = nodes[selectedNodeId] || nodes['N-01'];
  const zoneMeta = ZONES_METADATA.find((z) => z.id === activeNode?.zoneId);

  // Status mapping strictly driven by backend
  const rawStatus = (activeNode?.status || 'OFFLINE').toUpperCase();
  const isOnline = rawStatus === 'ONLINE';
  const isStale = rawStatus === 'STALE';
  const isCrit = rawStatus === 'CRITICAL';
  const isWarn = rawStatus === 'WARNING';

  let statusLabel = rawStatus;
  let statusColor = '#6B7280'; // muted gray for offline

  if (isCrit) {
    statusLabel = 'CRITICAL';
    statusColor = '#FF4D4D';
  } else if (isWarn) {
    statusLabel = 'WARNING';
    statusColor = '#FFB020';
  } else if (isStale) {
    statusLabel = 'STALE';
    statusColor = '#FFB020';
  } else if (isOnline) {
    statusLabel = 'ONLINE';
    statusColor = '#00D6A3';
  }

  // Source indicator: HARDWARE vs SIMULATOR
  const sourceLabel = activeNode?.source ? activeNode.source.toUpperCase() : (activeNode?.isRealHardware ? 'HARDWARE' : 'STANDBY');
  const isHardware = activeNode?.source === 'hardware' || activeNode?.isRealHardware;

  // Strata Risk
  const strataRisk = activeNode?.strataRisk !== null && activeNode?.strataRisk !== undefined ? activeNode.strataRisk : null;
  const strataRiskColor = strataRisk !== null ? (strataRisk >= 70 ? '#FF4D4D' : strataRisk >= 40 ? '#FFB020' : '#00D6A3') : 'var(--dust)';

  // Sensor Health / Battery
  const sensorHealth = activeNode?.sensorHealth ?? activeNode?.battery ?? null;
  const sensorHealthColor = sensorHealth !== null ? (sensorHealth >= 85 ? '#00D6A3' : sensorHealth >= 70 ? '#FFB020' : '#FF4D4D') : 'var(--dust)';

  // HC-SR04 Roof Distance & Displacement
  const distanceCm = activeNode?.currentConvergence !== null && activeNode?.currentConvergence !== undefined ? Number(activeNode.currentConvergence).toFixed(1) : null;
  const displacementVal = activeNode?.displacement !== null && activeNode?.displacement !== undefined ? Number(activeNode.displacement).toFixed(2) : null;
  const displacementTrend = activeNode?.displacementTrend && activeNode?.displacementTrend !== '—' ? activeNode.displacementTrend : (isCrit ? '↑ 12%' : isWarn ? '↑ 8%' : '→ 0%');

  // MPU9250 IMU Motion & Vibration
  const vibrationVal = activeNode?.vibration !== null && activeNode?.vibration !== undefined ? Number(activeNode.vibration).toFixed(2) : null;
  const tiltVal = activeNode?.currentTilt !== null && activeNode?.currentTilt !== undefined ? Number(activeNode.currentTilt).toFixed(2) : null;
  const imuObj = activeNode?.imu && typeof activeNode.imu === 'object' ? activeNode.imu : null;

  // Environmental Sensors
  const tempVal = activeNode?.temperature !== null && activeNode?.temperature !== undefined ? Number(activeNode.temperature).toFixed(1) : null;
  const humVal = activeNode?.humidity !== null && activeNode?.humidity !== undefined ? Number(activeNode.humidity).toFixed(1) : null;
  const pressVal = activeNode?.pressure !== null && activeNode?.pressure !== undefined ? Number(activeNode.pressure).toFixed(1) : null;
  const gasVal = activeNode?.gasAdc !== null && activeNode?.gasAdc !== undefined ? activeNode.gasAdc : null;
  const rainVal = activeNode?.rainAdc !== null && activeNode?.rainAdc !== undefined ? activeNode.rainAdc : null;

  // Format last packet time using state timestamp
  let lastSeenDisplay = 'Never';
  if (activeNode?.lastSeen) {
    const elapsedSec = Math.max(0, Math.floor((nowMs - Number(activeNode.lastSeen)) / 1000));
    if (elapsedSec < 60) {
      lastSeenDisplay = `${elapsedSec}s ago`;
    } else if (elapsedSec < 3600) {
      lastSeenDisplay = `${Math.floor(elapsedSec / 60)}m ago`;
    } else {
      lastSeenDisplay = new Date(activeNode.lastSeen).toLocaleTimeString();
    }
  }

  return (
    <aside
      style={{
        width: '100%',
        backgroundColor: 'rgba(7, 8, 11, 0.85)',
        border: '1px solid rgba(22, 136, 181, 0.22)',
        borderRadius: '6px',
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
        boxSizing: 'border-box',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.45)',
        flexShrink: 0,
        maxHeight: 'calc(100vh - 180px)',
        overflowY: 'auto',
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(22, 136, 181, 0.3) transparent'
      }}
      aria-label="Node Sensor Details"
    >
      {/* ============================================================ */}
      {/* 1. NODE HEADER                                              */}
      {/* ============================================================ */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '1px solid rgba(22, 136, 181, 0.15)',
          paddingBottom: '10px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '1.2rem',
              fontWeight: 700,
              color: '#FFFFFF',
              letterSpacing: '0.02em'
            }}
          >
            {selectedNodeId || 'N-01'}
          </span>

          {/* Hardware Source Badge */}
          <span
            style={{
              fontSize: '0.5625rem',
              fontFamily: 'var(--font-mono)',
              fontWeight: 700,
              padding: '2px 6px',
              borderRadius: '3px',
              backgroundColor: isHardware ? 'rgba(0, 217, 255, 0.15)' : 'rgba(255, 176, 32, 0.12)',
              border: `1px solid ${isHardware ? 'rgba(0, 217, 255, 0.35)' : 'rgba(255, 176, 32, 0.3)'}`,
              color: isHardware ? '#00D9FF' : '#FFB020',
              letterSpacing: '0.05em'
            }}
          >
            {sourceLabel}
          </span>
        </div>

        {/* Real Status Indicator Badge */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            backgroundColor: `${statusColor}18`,
            border: `1px solid ${statusColor}40`,
            borderRadius: '3px',
            padding: '2px 8px'
          }}
        >
          <span
            style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              backgroundColor: statusColor,
              boxShadow: isOnline ? `0 0 6px ${statusColor}` : 'none'
            }}
          />
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.6875rem',
              fontWeight: 600,
              color: statusColor,
              letterSpacing: '0.05em'
            }}
          >
            {statusLabel}
          </span>
        </div>
      </div>

      {/* Node Meta Details (Zone, Depth, Device, Last Seen) */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '6px',
          fontSize: '0.8125rem'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ color: 'var(--dust)' }}>Zone</span>
          <span style={{ color: 'var(--chalk)', fontWeight: 500 }}>
            {activeNode?.zoneName || zoneMeta?.shortName || 'Zone 01 — Main Haulage'}
          </span>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ color: 'var(--dust)' }}>Depth</span>
          <span className="t-mono" style={{ color: 'var(--chalk)', fontWeight: 500 }}>
            {activeNode?.depth !== undefined ? `${activeNode.depth} m` : (zoneMeta?.depth !== undefined ? `${zoneMeta.depth} m` : '-320 m')}
          </span>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ color: 'var(--dust)' }}>Gateway</span>
          <span className="t-mono" style={{ color: 'var(--ash)', fontSize: '0.75rem' }}>
            {activeNode?.deviceId || 'ESP32-GATEWAY-01'}
          </span>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ color: 'var(--dust)' }}>Last Telemetry</span>
          <span className="t-mono" style={{ color: activeNode?.lastSeen ? '#00D6A3' : 'var(--ash)', fontSize: '0.75rem' }}>
            {lastSeenDisplay}
          </span>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 2. CURRENT READINGS (Prominent 4 Cards)                      */}
      {/* ============================================================ */}
      <div
        style={{
          borderTop: '1px solid rgba(22, 136, 181, 0.15)',
          paddingTop: '10px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px'
        }}
      >
        <span
          className="t-micro"
          style={{
            color: '#00D9FF',
            letterSpacing: '0.08em',
            fontSize: '0.6875rem',
            fontWeight: 600
          }}
        >
          CURRENT GEOTECHNICAL READINGS
        </span>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
          {/* Card 1: HC-SR04 ROOF DISTANCE / DISPLACEMENT */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.75)',
              border: '1px solid rgba(22, 136, 181, 0.18)',
              borderRadius: '4px',
              padding: '8px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span
              className="t-micro"
              style={{ color: 'var(--dust)', fontSize: '0.5625rem', letterSpacing: '0.05em' }}
            >
              HC-SR04 DISTANCE
            </span>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: '4px', marginTop: '1px' }}>
              <span className="t-mono" style={{ fontSize: '0.9375rem', fontWeight: 600, color: distanceCm !== null ? '#FFFFFF' : 'var(--dust)' }}>
                {distanceCm !== null ? `${distanceCm} cm` : 'N/A'}
              </span>
              {displacementVal !== null && (
                <span
                  className="t-mono"
                  style={{
                    fontSize: '0.625rem',
                    color: isCrit ? '#FF4D4D' : isWarn ? '#FFB020' : '#00D6A3',
                    fontWeight: 600
                  }}
                  title="Computed roof displacement"
                >
                  {displacementVal} mm ({displacementTrend})
                </span>
              )}
            </div>
          </div>

          {/* Card 2: MPU9250 TILT & VIBRATION */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.75)',
              border: '1px solid rgba(22, 136, 181, 0.18)',
              borderRadius: '4px',
              padding: '8px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span
              className="t-micro"
              style={{ color: 'var(--dust)', fontSize: '0.5625rem', letterSpacing: '0.05em' }}
            >
              MPU9250 TILT ANGLE
            </span>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: '4px', marginTop: '1px' }}>
              <span className="t-mono" style={{ fontSize: '0.9375rem', fontWeight: 600, color: tiltVal !== null ? '#FFFFFF' : 'var(--dust)' }}>
                {tiltVal !== null ? `${tiltVal}°` : 'N/A'}
              </span>
              {vibrationVal !== null && (
                <span
                  className="t-mono"
                  style={{
                    fontSize: '0.625rem',
                    color: '#00D9FF',
                    fontWeight: 600
                  }}
                  title="Dynamic acceleration magnitude"
                >
                  {vibrationVal} g
                </span>
              )}
            </div>
          </div>

          {/* Card 3: STRATA RISK */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.75)',
              border: '1px solid rgba(22, 136, 181, 0.18)',
              borderRadius: '4px',
              padding: '8px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span
              className="t-micro"
              style={{ color: 'var(--dust)', fontSize: '0.5625rem', letterSpacing: '0.05em' }}
            >
              STRATA RISK
            </span>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px', marginTop: '1px' }}>
              <span
                className="t-mono"
                style={{ fontSize: '0.9375rem', fontWeight: 600, color: strataRiskColor }}
              >
                {strataRisk !== null ? strataRisk : 'N/A'}
              </span>
              {strataRisk !== null && (
                <span className="t-mono" style={{ fontSize: '0.6875rem', color: 'var(--dust)' }}>
                  / 100
                </span>
              )}
            </div>
          </div>

          {/* Card 4: SENSOR HEALTH */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.75)',
              border: '1px solid rgba(22, 136, 181, 0.18)',
              borderRadius: '4px',
              padding: '8px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span
              className="t-micro"
              style={{ color: 'var(--dust)', fontSize: '0.5625rem', letterSpacing: '0.05em' }}
            >
              SENSOR HEALTH
            </span>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '4px', marginTop: '1px' }}>
              <span
                className="t-mono"
                style={{ fontSize: '0.9375rem', fontWeight: 600, color: sensorHealthColor }}
              >
                {sensorHealth !== null ? `${sensorHealth}%` : 'N/A'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3. RAW HARDWARE SENSOR DATA (Compact 2-col Grid)            */}
      {/* ============================================================ */}
      <div
        style={{
          borderTop: '1px solid rgba(22, 136, 181, 0.15)',
          paddingTop: '10px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px'
        }}
      >
        <span
          className="t-micro"
          style={{
            color: '#00D9FF',
            letterSpacing: '0.08em',
            fontSize: '0.6875rem',
            fontWeight: 600
          }}
        >
          HARDWARE SENSOR CHANNELS
        </span>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
          {/* TEMPERATURE */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.65)',
              border: '1px solid rgba(22, 136, 181, 0.16)',
              borderRadius: '4px',
              padding: '7px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span style={{ color: 'var(--dust)', fontSize: '0.6875rem', fontFamily: 'var(--font-ui)' }}>
              Temperature
            </span>
            <span className="t-mono" style={{ fontSize: '0.875rem', fontWeight: 600, color: tempVal !== null ? '#FFFFFF' : 'var(--dust)' }}>
              {tempVal !== null ? `${tempVal} °C` : 'N/A'}
            </span>
          </div>

          {/* HUMIDITY */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.65)',
              border: '1px solid rgba(22, 136, 181, 0.16)',
              borderRadius: '4px',
              padding: '7px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span style={{ color: 'var(--dust)', fontSize: '0.6875rem', fontFamily: 'var(--font-ui)' }}>
              Humidity
            </span>
            <span className="t-mono" style={{ fontSize: '0.875rem', fontWeight: 600, color: humVal !== null ? '#FFFFFF' : 'var(--dust)' }}>
              {humVal !== null ? `${humVal} %` : 'N/A'}
            </span>
          </div>

          {/* PRESSURE */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.65)',
              border: '1px solid rgba(22, 136, 181, 0.16)',
              borderRadius: '4px',
              padding: '7px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span style={{ color: 'var(--dust)', fontSize: '0.6875rem', fontFamily: 'var(--font-ui)' }}>
              Pressure
            </span>
            <span className="t-mono" style={{ fontSize: '0.875rem', fontWeight: 600, color: pressVal !== null ? '#FFFFFF' : 'var(--dust)' }}>
              {pressVal !== null ? `${pressVal} hPa` : 'N/A'}
            </span>
          </div>

          {/* GAS ADC */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.65)',
              border: '1px solid rgba(22, 136, 181, 0.16)',
              borderRadius: '4px',
              padding: '7px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span style={{ color: 'var(--dust)', fontSize: '0.6875rem', fontFamily: 'var(--font-ui)' }}>
              Gas (ADC)
            </span>
            <span className="t-mono" style={{ fontSize: '0.875rem', fontWeight: 600, color: gasVal !== null ? '#FFFFFF' : 'var(--dust)' }}>
              {gasVal !== null ? gasVal : 'N/A'}
            </span>
          </div>

          {/* RAIN ADC */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.65)',
              border: '1px solid rgba(22, 136, 181, 0.16)',
              borderRadius: '4px',
              padding: '7px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span style={{ color: 'var(--dust)', fontSize: '0.6875rem', fontFamily: 'var(--font-ui)' }}>
              Rain (ADC)
            </span>
            <span className="t-mono" style={{ fontSize: '0.875rem', fontWeight: 600, color: rainVal !== null ? '#FFFFFF' : 'var(--dust)' }}>
              {rainVal !== null ? rainVal : 'N/A'}
            </span>
          </div>

          {/* IMU ACCELERATION */}
          <div
            style={{
              backgroundColor: 'rgba(14, 17, 21, 0.65)',
              border: '1px solid rgba(22, 136, 181, 0.16)',
              borderRadius: '4px',
              padding: '7px 10px',
              display: 'flex',
              flexDirection: 'column',
              gap: '2px'
            }}
          >
            <span style={{ color: 'var(--dust)', fontSize: '0.6875rem', fontFamily: 'var(--font-ui)' }}>
              IMU Motion (X/Y/Z)
            </span>
            <span className="t-mono" style={{ fontSize: '0.8125rem', fontWeight: 600, color: imuObj ? '#FFFFFF' : 'var(--dust)' }}>
              {imuObj ? `${imuObj.x?.toFixed(2) || 0}, ${imuObj.y?.toFixed(2) || 0}, ${imuObj.z?.toFixed(2) || 0} g` : (vibrationVal !== null ? `${vibrationVal} g` : 'N/A')}
            </span>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 4. RELEVANT THRESHOLD REFERENCE                              */}
      {/* ============================================================ */}
      <div
        style={{
          borderTop: '1px solid rgba(22, 136, 181, 0.15)',
          paddingTop: '8px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '0.75rem'
        }}
      >
        <span style={{ color: 'var(--dust)', fontSize: '0.75rem' }}>Convergence Warning</span>
        <span className="t-mono" style={{ color: '#FFB020', fontWeight: 600 }}>
          &le; 17.0 cm
        </span>
      </div>

      {/* ============================================================ */}
      {/* 5. BOTTOM OF SENSOR PANEL: Dynamic Time + Action Controls   */}
      {/* ============================================================ */}
      <div
        style={{
          borderTop: '1px solid rgba(22, 136, 181, 0.15)',
          paddingTop: '10px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.6875rem' }}>
          <span style={{ color: 'var(--dust)' }}>
            System Time: <strong className="t-mono" style={{ color: 'var(--chalk)', fontWeight: 500 }}>{timeStr || '13:34:51'}</strong>
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: statusColor, fontWeight: 600, fontFamily: 'var(--font-mono)' }}>
            <span style={{ width: '5px', height: '5px', borderRadius: '50%', backgroundColor: statusColor, boxShadow: isOnline ? `0 0 6px ${statusColor}` : 'none' }} />
            {statusLabel}
          </span>
        </div>

        {/* Real Functional Navigation Actions */}
        <button
          onClick={() => navigate('/nodes')}
          className="cmd-btn"
          style={{
            width: '100%',
            padding: '7px 12px',
            fontSize: '0.6875rem',
            fontWeight: 600,
            fontFamily: 'var(--font-ui)',
            letterSpacing: '0.06em',
            background: 'rgba(0, 217, 255, 0.08)',
            border: '1px solid rgba(0, 217, 255, 0.35)',
            color: '#00D9FF',
            borderRadius: '4px',
            cursor: 'pointer',
            transition: 'all 0.15s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(0, 217, 255, 0.18)';
            e.currentTarget.style.color = '#FFFFFF';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'rgba(0, 217, 255, 0.08)';
            e.currentTarget.style.color = '#00D9FF';
          }}
          title="Open Sensor Fleet manager for full node diagnostics"
        >
          VIEW SENSOR FLEET
        </button>

        <button
          onClick={() => navigate('/section')}
          className="cmd-btn"
          style={{
            width: '100%',
            padding: '7px 12px',
            fontSize: '0.6875rem',
            fontWeight: 600,
            fontFamily: 'var(--font-ui)',
            letterSpacing: '0.06em',
            background: 'rgba(20, 23, 27, 0.8)',
            border: '1px solid rgba(22, 136, 181, 0.28)',
            color: 'var(--chalk)',
            borderRadius: '4px',
            cursor: 'pointer',
            transition: 'all 0.15s ease'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = 'rgba(0, 217, 255, 0.5)';
            e.currentTarget.style.color = '#00D9FF';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = 'rgba(22, 136, 181, 0.28)';
            e.currentTarget.style.color = 'var(--chalk)';
          }}
          title="Inspect node position in 2D Subterranean Cross-Section"
        >
          OPEN IN DIGITAL TWIN
        </button>
      </div>
    </aside>
  );
}

export default ChannelInspector;
