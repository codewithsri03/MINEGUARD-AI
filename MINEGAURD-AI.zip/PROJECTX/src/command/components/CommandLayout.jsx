import React, { useEffect, useRef } from 'react';
import { NavRail } from './NavRail';
import { TopNavigation } from './TopNavigation';
import { TelemetryTicker } from './TelemetryTicker';
import { OperationalAmbientCanvas } from './OperationalAmbientCanvas';
import { useRouter } from '../../router/Router';
import gsap from 'gsap';
import '../tokens.css';

/**
 * MineGuard Command System — Master Layout
 * Orchestrates:
 * - Fixed 72px left rail
 * - Fixed bottom 40px live ticker
 * - 64px sticky page header inside child page
 * - One orchestrated GSAP load sequence once per session on command views
 * - 180ms route opacity cross-fade
 */

let hasSessionLoaded = false;

export function CommandLayout({ children }) {
  const { path } = useRouter();
  const mainRef = useRef(null);

  useEffect(() => {
    // Only trigger initial orchestrated load sequence once per session
    if (!hasSessionLoaded) {
      hasSessionLoaded = true;

      const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!prefersReducedMotion && mainRef.current) {
        const panels = mainRef.current.querySelectorAll('.panel');
        if (panels && panels.length > 0) {
          gsap.from(panels, {
            opacity: 0.5,
            y: 6,
            duration: 0.25,
            stagger: 0.02,
            ease: 'power2.out'
          });
        }
      }
    }
  }, [path]);

  return (
    <div className="command-scope" style={{ display: 'flex', minHeight: '100vh', width: '100%', position: 'relative' }}>
      {/* 0. Dedicated 2D Operational Ambient Telemetry Canvas */}
      <OperationalAmbientCanvas />

      {/* 1. Left Nav Rail (Fixed 72px, expands to 200px) */}
      <NavRail />

      {/* 2. Main Page Canvas */}
      <div
        ref={mainRef}
        style={{
          flex: 1,
          marginLeft: 'var(--rail-collapsed-width)',
          paddingBottom: 'var(--ticker-height)',
          minWidth: 0,
          display: 'flex',
          flexDirection: 'column',
          transition: 'opacity 180ms ease'
        }}
      >
        <TopNavigation />
        <div style={{ maxWidth: '1800px', width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', flex: 1 }}>
          {children}
        </div>
      </div>

      {/* 3. Global Live Telemetry Ticker (40px) */}
      <TelemetryTicker />
    </div>
  );
}
