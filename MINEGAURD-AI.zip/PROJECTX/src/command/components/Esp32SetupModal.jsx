import React, { useState, useEffect } from 'react';
import {
  Wifi,
  X,
  AlertTriangle,
  CheckCircle2,
  Loader2
} from 'lucide-react';
import { useSim } from '../sim/engine';
import { connectDevice, disconnectDevice } from '../../services/telemetryClient';

/**
 * MineGuard AI — Direct IP-Based ESP32 Connection Modal
 *
 * Requirements:
 * - Simple professional modal: CONNECT ESP32
 * - Field: ESP32 IP ADDRESS
 * - Example: Enter the local IP address assigned to the ESP32.
 * - Action: [ CONNECT ESP32 ]
 * - Never mark connected until backend verifies active reachability
 * - Error: "ESP32 OFFLINE · Unable to reach ESP32 at the supplied address."
 * - Success: "ESP32 CONNECTED"
 * - 3 separate states:
 *     Backend: CONNECTED / OFFLINE
 *     ESP32: CONNECTED / OFFLINE / STALE
 *     Telemetry: LIVE / WAITING
 */
export function Esp32SetupModal({ isOpen, onClose }) {
  const { backendConnected, gatewayState, nodes } = useSim();

  const [ipAddress, setIpAddress] = useState(() => gatewayState?.targetHost || '192.168.1.100');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [nowMs, setNowMs] = useState(() => Date.now());

  // Clock tick for stale detection
  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isOpen) return null;

  // 1. Backend Connection State
  const isBackendOnline = Boolean(backendConnected);
  const backendLabel = isBackendOnline ? 'CONNECTED' : 'OFFLINE';
  const backendColor = isBackendOnline ? '#00D6A3' : '#FF4D4D';

  // 2. ESP32 Connection State
  const isEsp32Connected = isBackendOnline && Boolean(gatewayState?.connected);
  let isEsp32Stale = false;
  if (isEsp32Connected && gatewayState?.lastPacket) {
    const elapsed = nowMs - new Date(gatewayState.lastPacket).getTime();
    if (elapsed >= 5000) {
      isEsp32Stale = true;
    }
  }

  let esp32Label = 'OFFLINE';
  let esp32Color = '#FF4D4D';
  if (!isBackendOnline) {
    esp32Label = 'OFFLINE';
    esp32Color = '#FF4D4D';
  } else if (isEsp32Connected) {
    if (isEsp32Stale) {
      esp32Label = 'STALE';
      esp32Color = '#FFB020';
    } else {
      esp32Label = 'CONNECTED';
      esp32Color = '#00D6A3';
    }
  } else {
    esp32Label = 'OFFLINE';
    esp32Color = '#FF4D4D';
  }

  // 3. Telemetry State
  const isTelemetryLive = isEsp32Connected && !isEsp32Stale && Boolean(gatewayState?.lastPacket);
  const telemetryLabel = isTelemetryLive ? 'LIVE' : 'WAITING';
  const telemetryColor = isTelemetryLive ? '#00D6A3' : 'var(--dust)';

  // Reporting hardware node metadata
  const reportingNodeId = gatewayState?.latestNodeId || Object.keys(nodes).find((id) => nodes[id].isOnline) || 'N-01';
  const reportingNode = nodes[reportingNodeId] || {};
  const reportingDeviceId = gatewayState?.latestDeviceId || reportingNode.deviceId || gatewayState?.gateway || 'ESP32-01';

  // Handle Form Submit
  const handleConnect = async (e) => {
    e?.preventDefault();
    const cleanIp = (ipAddress || '').trim();

    if (!cleanIp) {
      setErrorMessage('Please enter an IP address.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await connectDevice(cleanIp, 80);

      if (res && res.success) {
        setErrorMessage(null);
        if (res.state) {
          useSim.getState().ingestDeviceStatus(res.state);
        }
      } else {
        const errorText = res?.error || 'Unable to reach ESP32 at the supplied address.';
        setErrorMessage(errorText);
        if (res?.state) {
          useSim.getState().ingestDeviceStatus(res.state);
        }
      }
    } catch {
      setErrorMessage('Unable to reach ESP32 at the supplied address.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Disconnect
  const handleDisconnect = async () => {
    setIsLoading(true);
    try {
      const res = await disconnectDevice();
      if (res && res.state) {
        useSim.getState().ingestDeviceStatus(res.state);
      }
      setErrorMessage(null);
    } catch (err) {
      console.warn('Disconnect error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.85)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        boxSizing: 'border-box'
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%',
          maxWidth: '520px',
          backgroundColor: 'rgba(9, 12, 18, 0.98)',
          border: '1px solid rgba(0, 217, 255, 0.35)',
          borderRadius: '8px',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.9), 0 0 30px rgba(0, 217, 255, 0.1)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden'
        }}
      >
        {/* ── Modal Header ── */}
        <div
          style={{
            padding: '16px 20px',
            backgroundColor: 'rgba(14, 18, 26, 0.95)',
            borderBottom: '1px solid rgba(22, 136, 181, 0.25)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div
              style={{
                width: '32px',
                height: '32px',
                borderRadius: '4px',
                backgroundColor: 'rgba(0, 217, 255, 0.12)',
                border: '1px solid rgba(0, 217, 255, 0.35)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#00D9FF'
              }}
            >
              <Wifi size={16} />
            </div>
            <div>
              <h2
                style={{
                  margin: 0,
                  fontFamily: 'var(--font-ui)',
                  fontSize: '0.9375rem',
                  fontWeight: 700,
                  letterSpacing: '0.06em',
                  color: '#FFFFFF'
                }}
              >
                CONNECT ESP32
              </h2>
              <span style={{ fontSize: '0.6875rem', color: 'var(--dust)', fontFamily: 'var(--font-ui)' }}>
                IP-Based Hardware Connection
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--dust)',
              cursor: 'pointer',
              padding: '6px',
              borderRadius: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
            aria-label="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* ── Modal Body ── */}
        <div
          style={{
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '16px',
            boxSizing: 'border-box'
          }}
        >
          {/* Error Banner: ESP32 OFFLINE */}
          {errorMessage && (
            <div
              style={{
                padding: '12px 14px',
                backgroundColor: 'rgba(255, 77, 77, 0.12)',
                border: '1px solid rgba(255, 77, 77, 0.4)',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'flex-start',
                gap: '10px'
              }}
            >
              <AlertTriangle size={18} color="#FF4D4D" style={{ flexShrink: 0, marginTop: '2px' }} />
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <span
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    color: '#FF4D4D',
                    letterSpacing: '0.04em'
                  }}
                >
                  ESP32 OFFLINE
                </span>
                <span
                  style={{
                    fontFamily: 'var(--font-ui)',
                    fontSize: '0.71875rem',
                    color: 'var(--chalk)',
                    lineHeight: 1.4
                  }}
                >
                  {errorMessage}
                </span>
              </div>
            </div>
          )}

          {/* Success Banner: ESP32 CONNECTED */}
          {isEsp32Connected && !errorMessage && (
            <div
              style={{
                padding: '12px 14px',
                backgroundColor: 'rgba(0, 214, 163, 0.12)',
                border: '1px solid rgba(0, 214, 163, 0.4)',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <CheckCircle2 size={18} color="#00D6A3" style={{ flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#00D6A3', fontFamily: 'var(--font-mono)' }}>
                    ESP32 CONNECTED
                  </div>
                  <div style={{ fontSize: '0.6875rem', color: 'var(--chalk)', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>
                    Node: {reportingNodeId} · Device: {reportingDeviceId} · Target: {gatewayState?.targetHost || ipAddress}
                  </div>
                </div>
              </div>

              <button
                onClick={handleDisconnect}
                disabled={isLoading}
                style={{
                  padding: '5px 10px',
                  fontSize: '0.6875rem',
                  fontFamily: 'var(--font-mono)',
                  fontWeight: 600,
                  background: 'rgba(255, 77, 77, 0.15)',
                  border: '1px solid rgba(255, 77, 77, 0.4)',
                  color: '#FF4D4D',
                  borderRadius: '3px',
                  cursor: 'pointer',
                  flexShrink: 0
                }}
              >
                DISCONNECT
              </button>
            </div>
          )}

          {/* ── Connect ESP32 IP Input Form ── */}
          <form onSubmit={handleConnect} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label
                htmlFor="esp32-ip-input"
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.71875rem',
                  fontWeight: 700,
                  color: 'var(--chalk)',
                  letterSpacing: '0.06em'
                }}
              >
                ESP32 IP ADDRESS
              </label>

              <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                <input
                  id="esp32-ip-input"
                  type="text"
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  placeholder="192.168.1.100"
                  disabled={isLoading}
                  autoComplete="off"
                  spellCheck="false"
                  style={{
                    width: '100%',
                    padding: '10px 14px',
                    backgroundColor: 'rgba(6, 8, 12, 0.95)',
                    border: '1px solid rgba(0, 217, 255, 0.4)',
                    borderRadius: '4px',
                    color: '#00D9FF',
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.9375rem',
                    fontWeight: 600,
                    letterSpacing: '0.04em',
                    outline: 'none',
                    boxSizing: 'border-box',
                    transition: 'border-color 0.15s ease'
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = '#00D9FF';
                    e.target.style.boxShadow = '0 0 10px rgba(0, 217, 255, 0.25)';
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = 'rgba(0, 217, 255, 0.4)';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </div>

              <span
                style={{
                  fontFamily: 'var(--font-ui)',
                  fontSize: '0.6875rem',
                  color: 'var(--dust)',
                  lineHeight: 1.4
                }}
              >
                Example: Enter the local IP address assigned to the ESP32.
              </span>
            </div>

            {/* Connect Action Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="cmd-btn"
              style={{
                padding: '10px 16px',
                fontSize: '0.8125rem',
                fontWeight: 700,
                fontFamily: 'var(--font-mono)',
                letterSpacing: '0.06em',
                background: isLoading ? 'rgba(0, 217, 255, 0.2)' : '#00D9FF',
                color: '#000000',
                border: 'none',
                borderRadius: '4px',
                cursor: isLoading ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                boxShadow: '0 0 16px rgba(0, 217, 255, 0.25)',
                transition: 'all 0.15s ease'
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 size={16} className="spin" />
                  <span>PROBING ESP32...</span>
                </>
              ) : (
                <>
                  <Wifi size={15} />
                  <span>CONNECT ESP32</span>
                </>
              )}
            </button>
          </form>

          {/* ── Architecture Pipeline Flow Indicator ── */}
          <div
            style={{
              padding: '10px 14px',
              backgroundColor: 'rgba(12, 16, 24, 0.7)',
              border: '1px solid rgba(22, 136, 181, 0.2)',
              borderRadius: '5px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              fontSize: '0.6875rem',
              fontFamily: 'var(--font-mono)'
            }}
          >
            <span style={{ color: isEsp32Connected ? '#FFFFFF' : 'var(--dust)', fontWeight: 600 }}>ESP32</span>
            <span style={{ color: 'var(--ash)' }}>← Wi-Fi →</span>
            <span style={{ color: isBackendOnline ? '#FFFFFF' : '#FF4D4D', fontWeight: 600 }}>MineGuard Backend</span>
            <span style={{ color: 'var(--ash)' }}>← WS/REST →</span>
            <span style={{ color: '#00D9FF', fontWeight: 600 }}>React</span>
          </div>

          {/* ── 3-Tier Decoupled Connection Status Card ── */}
          <div
            style={{
              padding: '12px 14px',
              backgroundColor: 'rgba(7, 9, 14, 0.95)',
              border: '1px solid rgba(22, 136, 181, 0.25)',
              borderRadius: '6px',
              display: 'flex',
              flexDirection: 'column',
              gap: '8px'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#00D9FF', fontSize: '0.625rem', fontWeight: 700, fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>
                CONNECTION STATUS
              </span>
              <span style={{ fontSize: '0.625rem', color: 'var(--ash)', fontFamily: 'var(--font-mono)' }}>
                Real-time
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
              {/* 1. Backend Status */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)' }}>BACKEND</span>
                <span
                  style={{
                    fontSize: '0.6875rem',
                    fontWeight: 700,
                    fontFamily: 'var(--font-mono)',
                    color: backendColor,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <span style={{ width: '5px', height: '5px', borderRadius: '50%', backgroundColor: backendColor }} />
                  {backendLabel}
                </span>
              </div>

              {/* 2. ESP32 Status */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)' }}>ESP32</span>
                <span
                  style={{
                    fontSize: '0.6875rem',
                    fontWeight: 700,
                    fontFamily: 'var(--font-mono)',
                    color: esp32Color,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <span style={{ width: '5px', height: '5px', borderRadius: '50%', backgroundColor: esp32Color }} />
                  {esp32Label}
                </span>
              </div>

              {/* 3. Telemetry Status */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <span style={{ fontSize: '0.5625rem', color: 'var(--dust)', fontFamily: 'var(--font-mono)' }}>TELEMETRY</span>
                <span
                  style={{
                    fontSize: '0.6875rem',
                    fontWeight: 700,
                    fontFamily: 'var(--font-mono)',
                    color: telemetryColor,
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: '4px'
                  }}
                >
                  <span style={{ width: '5px', height: '5px', borderRadius: '50%', backgroundColor: telemetryColor }} />
                  {telemetryLabel}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* ── Modal Footer ── */}
        <div
          style={{
            padding: '12px 20px',
            backgroundColor: 'rgba(12, 16, 24, 0.95)',
            borderTop: '1px solid rgba(22, 136, 181, 0.2)',
            display: 'flex',
            justifyContent: 'flex-end',
            gap: '10px'
          }}
        >
          <button
            onClick={onClose}
            className="cmd-btn"
            style={{
              padding: '6px 14px',
              fontSize: '0.75rem',
              fontFamily: 'var(--font-mono)',
              fontWeight: 600,
              background: 'transparent',
              border: '1px solid rgba(22, 136, 181, 0.3)',
              color: 'var(--chalk)',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            {isEsp32Connected ? 'VIEW LIVE MONITORING' : 'CLOSE'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Esp32SetupModal;
