import React from 'react';
import { useSim } from '../sim/engine';

/**
 * MineGuard Command System — Telemetry Ticker (40px fixed bottom)
 * The product's continuous heartbeat across all six command routes.
 * Streams all 8 nodes (N-01 to N-08) live in mono tabular-nums.
 */
export function TelemetryTicker() {
  const { nodes, mineRisk, mineRiskTrend } = useSim();

  const nodeEntries = Object.keys(nodes).map((id) => nodes[id]);

  return (
    <div
      style={{
        position: 'fixed',
        left: 0,
        right: 0,
        bottom: 0,
        height: 'var(--ticker-height)',
        backgroundColor: 'var(--rock-900)',
        borderTop: '1px solid var(--seam)',
        display: 'flex',
        alignItems: 'center',
        zIndex: 60,
        overflow: 'hidden',
        paddingLeft: 'var(--rail-collapsed-width)',
        boxSizing: 'border-box'
      }}
      aria-label="Live Telemetry Heartbeat Stream"
    >
      {/* Fixed Left Status Capsule */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '0 16px',
          height: '100%',
          borderRight: '1px solid var(--seam)',
          backgroundColor: 'var(--rock-850)',
          flexShrink: 0,
          zIndex: 2
        }}
      >
        <span
          style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            backgroundColor: mineRisk >= 75 ? 'var(--flare)' : 'var(--lamp)'
          }}
        />
        <span className="t-label" style={{ color: 'var(--chalk)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Telemetry Stream
        </span>
        <span className="t-mono" style={{ color: 'var(--lamp)', fontSize: '0.75rem', fontWeight: 600 }}>
          {mineRisk}/100 ({mineRiskTrend})
        </span>
      </div>

      {/* Continuously Scrolling Node Strip */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '28px',
          whiteSpace: 'nowrap',
          paddingLeft: '20px',
          overflowX: 'auto',
          scrollbarWidth: 'none',
          msOverflowStyle: 'none'
        }}
      >
        {nodeEntries.concat(nodeEntries).map((node, idx) => {
          const isCrit = node.status === 'critical' || node.status === 'CRITICAL';
          const isWarn = (node.status === 'warning' || node.status === 'WARNING') && !isCrit;
          const isStale = (node.status === 'stale' || node.status === 'STALE') && !isCrit && !isWarn;
          const isOffline = !node.isOnline && node.status !== 'ONLINE' && !isCrit && !isWarn && !isStale;

          const tiltStr = node.currentTilt != null ? `${node.currentTilt.toFixed(2)}°` : null;
          const convStr = node.currentConvergence != null ? `${node.currentConvergence.toFixed(1)}cm` : null;
          const distStr = node.distance != null ? `${node.distance.toFixed(1)}cm` : null;
          const readingStr = tiltStr && (convStr || distStr)
            ? `${tiltStr} · ${convStr || distStr}`
            : tiltStr || convStr || distStr || 'STANDBY';

          return (
            <div
              key={`${node.id}-${idx}`}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '0.75rem'
              }}
            >
              <span
                className="t-mono"
                style={{
                  fontWeight: 600,
                  color: isOffline ? 'var(--ash)' : isCrit ? 'var(--flare)' : isWarn ? 'var(--lamp)' : isStale ? '#FF8800' : 'var(--chalk)'
                }}
              >
                {node.id}
              </span>
              {isOffline ? (
                <span className="t-mono" style={{ color: 'var(--ash)' }}>
                  OFFLINE
                </span>
              ) : isStale ? (
                <span className="t-mono" style={{ color: '#FF8800' }}>
                  STALE · {readingStr}
                </span>
              ) : (
                <span className="t-mono" style={{ color: 'var(--dust)' }}>
                  {readingStr}
                </span>
              )}
              <span style={{ color: 'var(--seam)' }}>|</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
