import { create } from 'zustand';
import {
  initTelemetryClient,
  addTelemetryListener,
  fetchDeviceStatus,
  fetchLatestTelemetry,
  fetchRisk,
  fetchAlerts,
  fetchDashboardSummary,
  acknowledgeAlert as apiAcknowledgeAlert,
  BACKEND_STATES
} from '../../services/telemetryClient.js';
import { generateDemoTelemetryPacket } from '../../services/demoStream.js';

/**
 * MineGuard AI Command System — Unified Telemetry & State Engine
 *
 * Architecture:
 * ESP32 sensors -> Wi-Fi -> MineGuard Backend (Port 3001) -> REST + WebSocket -> useSim State Store
 *
 * Canonical Thresholds:
 * Tilt: Warning >= 2.0°, Critical >= 3.0°
 * Convergence: Warning <= 17.0 cm, Critical <= 15.0 cm (HC-SR04 roof distance)
 */

export const INITIAL_THRESHOLDS = {
  tiltWarning: 2.0,
  tiltCritical: 3.0,
  convergenceWarning: 17.0,
  convergenceCritical: 15.0
};

export const ZONES_METADATA = [
  { id: 'z1', name: 'Zone 01 — Main Haulage', shortName: 'Main Haulage', depth: -320, nodes: ['N-01', 'N-02'], baseRisk: 24, status: 'nominal' },
  { id: 'z2', name: 'Zone 02 — North Drift', shortName: 'North Drift', depth: -380, nodes: ['N-03', 'N-04'], baseRisk: 54, status: 'warning' },
  { id: 'z4', name: 'Zone 04 — Ventilation', shortName: 'Ventilation', depth: -410, nodes: ['N-05', 'N-08'], baseRisk: 18, status: 'nominal' },
  { id: 'z3', name: 'Zone 03 — Sub-Level 4', shortName: 'Sub-Level 4', depth: -460, nodes: ['N-06', 'N-07'], baseRisk: 78, status: 'critical' }
];

export const NODES_METADATA = {
  'N-01': { id: 'N-01', zoneId: 'z1', name: 'Main Haulage Entry', depth: -320, battery: 94, rssi: -68, fw: 'v2.4.1', calibrated: '2026-08-12' },
  'N-02': { id: 'N-02', zoneId: 'z1', name: 'Portal Cross-Cut', depth: -320, battery: 91, rssi: -72, fw: 'v2.4.1', calibrated: '2026-08-12' },
  'N-03': { id: 'N-03', zoneId: 'z2', name: 'Central Junction', depth: -380, battery: 88, rssi: -77, fw: 'v2.4.1', calibrated: '2026-08-10' },
  'N-04': { id: 'N-04', zoneId: 'z2', name: 'North Drift Heading', depth: -380, battery: 85, rssi: -81, fw: 'v2.4.0', calibrated: '2026-08-10' },
  'N-05': { id: 'N-05', zoneId: 'z4', name: 'Ventilation Incline', depth: -410, battery: 96, rssi: -75, fw: 'v2.4.2', calibrated: '2026-08-15' },
  'N-06': { id: 'N-06', zoneId: 'z3', name: 'South Access Heading', depth: -460, battery: 82, rssi: -84, fw: 'v2.4.0', calibrated: '2026-08-05' },
  'N-07': { id: 'N-07', zoneId: 'z3', name: 'Active Longwall Face', depth: -460, battery: 94, rssi: -89, fw: 'v2.3.9', calibrated: '2026-07-28' },
  'N-08': { id: 'N-08', zoneId: 'z4', name: 'Drainage Return', depth: -410, battery: 92, rssi: -73, fw: 'v2.4.2', calibrated: '2026-08-15' }
};

const BUFFER_SIZE = 300;

export const INITIAL_DEMO_ALERTS = [
  {
    id: 'alt-001',
    alertId: 'alt-001',
    severity: 'critical',
    nodeId: 'N-07',
    zoneId: 'z3',
    type: 'ROOF_CONVERGENCE_BREACH',
    message: 'Excessive roof convergence detected on N-07 (14.1 cm < 15.0 cm)',
    timestamp: Date.now() - 120000,
    state: 'active',
    assignee: 'Rapid Response Crew Delta',
    threshold: '15.0 cm limit',
    breachAmount: '14.1 cm',
    factors: [
      { parameter: 'distance', label: 'HC-SR04 Roof Clearance', value: 14.1, threshold: 15.0, severity: 'CRITICAL' },
      { parameter: 'gasAdc', label: 'Gas Sensor ADC', value: 2720, threshold: 2200, severity: 'CRITICAL' }
    ],
    timeline: [
      { action: 'Detected by Sensor Node', time: Date.now() - 120000, actor: 'HC-SR04 Ultrasonic' }
    ]
  },
  {
    id: 'alt-002',
    alertId: 'alt-002',
    severity: 'warning',
    nodeId: 'N-08',
    zoneId: 'z4',
    type: 'WATER_INGRESS_DETECTED',
    message: 'Water ingress detected in stope drainage on N-08 (410 ADC)',
    timestamp: Date.now() - 360000,
    state: 'active',
    assignee: 'Drainage Crew',
    threshold: '350 ADC limit',
    breachAmount: '410 ADC',
    factors: [
      { parameter: 'rainAdc', label: 'Drainage Conductivity Sensor', value: 410, threshold: 350, severity: 'WARNING' }
    ],
    timeline: [
      { action: 'Detected by Sensor Node', time: Date.now() - 360000, actor: 'Conductivity Sensor' }
    ]
  },
  {
    id: 'alt-003',
    alertId: 'alt-003',
    severity: 'warning',
    nodeId: 'N-06',
    zoneId: 'z3',
    type: 'STRUCTURAL_TILT_BREACH',
    message: 'Elevated structural roof tilt on N-06 (2.25° > 2.0°)',
    timestamp: Date.now() - 540000,
    state: 'acknowledged',
    assignee: 'Shift Supervisor',
    threshold: '2.00° limit',
    breachAmount: '2.25°',
    factors: [
      { parameter: 'tilt', label: 'MPU9250 Dual-Axis Inclinometer', value: 2.25, threshold: 2.0, severity: 'WARNING' }
    ],
    timeline: [
      { action: 'Detected by Sensor Node', time: Date.now() - 540000, actor: 'MPU9250 Inclinometer' },
      { action: 'Acknowledged', time: Date.now() - 300000, actor: 'Shift Supervisor' }
    ]
  }
];

const DEFAULT_NODE_BASELINES = {
  'N-01': { tilt: 0.45, distance: 18.4, temp: 23.8, hum: 62.5, press: 1012.8, gas: 350, rain: 15, status: 'ONLINE' },
  'N-02': { tilt: 0.32, distance: 19.1, temp: 24.0, hum: 61.8, press: 1012.8, gas: 320, rain: 15, status: 'ONLINE' },
  'N-03': { tilt: 0.68, distance: 18.2, temp: 25.1, hum: 66.2, press: 1012.8, gas: 410, rain: 15, status: 'ONLINE' },
  'N-04': { tilt: 0.95, distance: 18.6, temp: 25.8, hum: 67.5, press: 1012.8, gas: 480, rain: 15, status: 'ONLINE' },
  'N-05': { tilt: 0.55, distance: 18.8, temp: 22.6, hum: 70.4, press: 1014.2, gas: 360, rain: 15, status: 'ONLINE' },
  'N-06': { tilt: 2.25, distance: 16.4, temp: 28.5, hum: 74.0, press: 1012.8, gas: 680, rain: 20, status: 'warning' },
  'N-07': { tilt: 3.35, distance: 14.1, temp: 31.2, hum: 81.5, press: 1008.2, gas: 2720, rain: 25, status: 'critical' },
  'N-08': { tilt: 0.85, distance: 18.1, temp: 21.8, hum: 88.2, press: 1012.8, gas: 380, rain: 410, status: 'warning' }
};

// Initialize rich baseline node state dictionary
function buildInitialNodes() {
  const map = {};
  const now = Date.now();
  Object.keys(NODES_METADATA).forEach((id) => {
    const meta = NODES_METADATA[id];
    const base = DEFAULT_NODE_BASELINES[id] || { tilt: 0.5, distance: 18.0, temp: 24, hum: 60, press: 1013, gas: 350, rain: 10, status: 'ONLINE' };

    const history = [];
    for (let i = 10; i >= 0; i--) {
      history.push({
        timestamp: now - i * 60000,
        tilt: Number((base.tilt + (Math.sin(i) * 0.05)).toFixed(2)),
        convergence: Number((base.distance + (Math.cos(i) * 0.08)).toFixed(1))
      });
    }

    map[id] = {
      ...meta,
      deviceId: 'ESP32-SIM-01',
      currentTilt: base.tilt,
      currentConvergence: base.distance,
      deltaRate: id === 'N-07' ? -0.15 : 0.01,
      temperature: base.temp,
      humidity: base.hum,
      pressure: base.press,
      gasAdc: base.gas,
      rainAdc: base.rain,
      imu: { x: 0.02, y: 0.01, z: 0.99 },
      imuMotion: null,
      displacement: Number((20.0 - base.distance).toFixed(2)),
      displacementTrend: id === 'N-07' ? '+4.2cm' : '0.0cm',
      vibration: 0.02,
      vibrationTrend: 'stable',
      strataRisk: id === 'N-07' ? 95 : id === 'N-06' ? 68 : id === 'N-08' ? 54 : 15,
      sensorHealth: meta.battery,
      status: base.status,
      isOnline: true,
      isRealHardware: false,
      source: 'simulator',
      lastSeen: now,
      history
    };
  });
  return map;
}

export const useSim = create((set, get) => ({
  // Backend & Gateway Connection State
  backendConnected: false,
  backendState: BACKEND_STATES.DISCONNECTED,
  gatewayState: {
    connected: true,
    gateway: 'ESP32-SIM-01',
    nodesOnline: 8,
    nodesStale: 0,
    nodesOffline: 0,
    totalNodes: 8,
    lastPacket: new Date().toISOString(),
    signal: 94,
    latestNodeId: 'N-07',
    latestDeviceId: 'ESP32-SIM-01',
    latestSource: 'simulator'
  },

  // Simulator Isolation Flag (Strictly Demo/Dev only)
  simulatorMode: true,

  // Selected Views & Navigation Focus
  selectedZoneId: 'z3',
  selectedNodeId: 'N-01',
  timeWindow: '1h',
  metricMode: 'both',
  displacementExaggeration: 20,
  thresholds: INITIAL_THRESHOLDS,

  // Nodes & Zones
  nodes: buildInitialNodes(),
  zones: ZONES_METADATA,
  mineRisk: 78,
  mineRiskStatus: 'CRITICAL',
  mineRiskTrend: 'escalating',
  mineRiskFactors: [
    { parameter: 'distance', label: 'HC-SR04 Roof Clearance', value: 14.1, threshold: 15.0, severity: 'CRITICAL' },
    { parameter: 'gasAdc', label: 'Gas Sensor ADC', value: 2720, threshold: 2200, severity: 'CRITICAL' }
  ],
  mineRiskHistory: [62, 65, 68, 70, 72, 75, 76, 78],

  // Alerts
  alerts: INITIAL_DEMO_ALERTS,
  activeAlertsCount: 3,

  // Consolidated Dashboard Summary
  dashboardSummary: null,

  // Tracking Real Telemetry Timestamps
  hardwareNodes: {},

  // =========================================================================
  // ACTIONS: Backend Synchronization & Live Stream Ingestion
  // =========================================================================

  /**
   * Synchronize complete application state from backend REST endpoints
   */
  syncFromBackend: async () => {
    try {
      // 1. Fetch real device & fleet status
      const deviceRes = await fetchDeviceStatus();
      if (deviceRes && deviceRes.nodes) {
        get().ingestDeviceStatus(deviceRes);
      }

      // 2. Fetch latest telemetry snapshot for all stations
      const telemetryRes = await fetchLatestTelemetry();
      if (telemetryRes && telemetryRes.success && telemetryRes.telemetry) {
        const packets = telemetryRes.telemetry;
        // Could be a map or single packet
        if (typeof packets === 'object' && !packets.nodeId) {
          Object.values(packets).forEach((packet) => {
            get().ingestRealTelemetry(packet);
          });
        } else if (packets.nodeId) {
          get().ingestRealTelemetry(packets);
        }
      }

      // 3. Fetch active hazard alerts
      const alertsRes = await fetchAlerts({ limit: 50 });
      if (alertsRes && alertsRes.success && Array.isArray(alertsRes.alerts)) {
        get().setAlertsFromBackend(alertsRes.alerts);
      }

      // 4. Fetch mine geotechnical risk evaluation
      const riskRes = await fetchRisk();
      if (riskRes && riskRes.success) {
        get().ingestRiskEvaluation(riskRes);
      }

      // 5. Fetch consolidated dashboard summary
      const dashboardRes = await fetchDashboardSummary();
      if (dashboardRes && dashboardRes.success && dashboardRes.summary) {
        set({ dashboardSummary: dashboardRes.summary });
      }
    } catch (err) {
      console.warn('[STORE] Backend sync warning:', err);
    }
  },

  /**
   * Ingest device fleet status update from REST or WebSocket event
   */
  ingestDeviceStatus: (statusData) => {
    if (!statusData) return;

    set((state) => {
      const updatedGateway = {
        connected: Boolean(statusData.connected),
        gateway: statusData.gateway || state.gatewayState.gateway,
        nodesOnline: statusData.nodesOnline ?? state.gatewayState.nodesOnline,
        nodesStale: statusData.nodesStale ?? state.gatewayState.nodesStale,
        nodesOffline: statusData.nodesOffline ?? state.gatewayState.nodesOffline,
        totalNodes: statusData.totalNodes ?? state.gatewayState.totalNodes,
        lastPacket: statusData.lastPacket ?? state.gatewayState.lastPacket,
        signal: statusData.signal ?? state.gatewayState.signal,
        latestNodeId: state.gatewayState.latestNodeId,
        latestDeviceId: statusData.gateway || state.gatewayState.latestDeviceId,
        latestSource: state.gatewayState.latestSource
      };

      const updatedNodes = { ...state.nodes };

      if (Array.isArray(statusData.nodes)) {
        statusData.nodes.forEach((n) => {
          const id = n.nodeId;
          const existing = updatedNodes[id] || { id, history: [] };

          const isOnline = n.status === 'ONLINE' || n.status === 'STALE';
          const isReal = n.source === 'hardware';

          updatedNodes[id] = {
            ...existing,
            deviceId: n.deviceId || existing.deviceId,
            name: n.name || existing.name,
            zoneId: n.zoneId || existing.zoneId,
            zoneName: n.zoneName || existing.zoneName,
            depth: n.depth !== undefined ? n.depth : existing.depth,
            status: n.status || (isOnline ? 'ONLINE' : 'OFFLINE'),
            isOnline,
            isRealHardware: isReal,
            source: n.source || existing.source,
            lastSeen: n.lastSeen || existing.lastSeen
          };

          // If node contains latest telemetry snapshot
          if (n.latestTelemetry) {
            const t = n.latestTelemetry;
            const tilt = t.tilt !== null && t.tilt !== undefined ? Number(t.tilt) : updatedNodes[id].currentTilt;
            const distance = t.distance !== null && t.distance !== undefined ? Number(t.distance) : updatedNodes[id].currentConvergence;

            updatedNodes[id] = {
              ...updatedNodes[id],
              currentTilt: tilt,
              currentConvergence: distance,
              temperature: t.temperature ?? updatedNodes[id].temperature,
              humidity: t.humidity ?? updatedNodes[id].humidity,
              pressure: t.pressure ?? updatedNodes[id].pressure,
              gasAdc: t.gasAdc ?? updatedNodes[id].gasAdc,
              rainAdc: t.rainAdc ?? updatedNodes[id].rainAdc,
              displacement: distance !== null ? Number((20.0 - distance).toFixed(2)) : null,
              vibration: t.imu ? Number(Math.sqrt((t.imu.x||0)**2 + (t.imu.y||0)**2 + (t.imu.z||0)**2).toFixed(2)) : null
            };
          }
        });
      }

      return {
        gatewayState: updatedGateway,
        nodes: updatedNodes
      };
    });
  },

  /**
   * Ingest real telemetry packet broadcast by backend WebSocket or loaded via REST
   */
  ingestRealTelemetry: (packet) => {
    if (!packet || !packet.nodeId) return;
    const { nodeId } = packet;
    const nowMs = Date.now();
    const packetTime = packet.timestamp ? new Date(packet.timestamp).getTime() : nowMs;

    set((state) => {
      const existing = state.nodes[nodeId] || {
        id: nodeId,
        zoneId: 'z1',
        battery: 95,
        history: []
      };

      const tilt = packet.tilt !== undefined && packet.tilt !== null ? Number(packet.tilt) : existing.currentTilt;
      const conv = packet.distance !== undefined && packet.distance !== null ? Number(packet.distance) : existing.currentConvergence;

      // Actual backend risk or local threshold fallback
      let status = 'nominal';
      if (packet.risk && packet.risk.level) {
        status = packet.risk.level.toLowerCase();
      } else {
        const gas = packet.gasAdc ?? existing.gasAdc ?? 0;
        const rain = packet.rainAdc ?? existing.rainAdc ?? 0;
        if (
          (tilt !== null && tilt >= state.thresholds.tiltCritical) ||
          (conv !== null && conv <= state.thresholds.convergenceCritical) ||
          gas >= 2600
        ) {
          status = 'critical';
        } else if (
          (tilt !== null && tilt >= state.thresholds.tiltWarning) ||
          (conv !== null && conv <= state.thresholds.convergenceWarning) ||
          gas >= 2200 ||
          rain >= 350
        ) {
          status = 'warning';
        }
      }

      // Delta rate calculation over previous history samples
      let deltaRate = existing.deltaRate || 0;
      if (existing.history && existing.history.length >= 2 && conv !== null) {
        const prev = existing.history[existing.history.length - 1];
        if (prev && prev.convergence !== null && prev.convergence !== undefined) {
          deltaRate = Number((conv - prev.convergence).toFixed(3));
        }
      }

      // Append verified history point
      const newHistoryPoint = {
        timestamp: packetTime,
        tilt,
        convergence: conv
      };

      const updatedHistory = [
        ...(existing.history || []).slice(-BUFFER_SIZE + 1),
        newHistoryPoint
      ];

      // Derived displacement and vibration
      const displacement = conv !== null ? Number((20.0 - conv).toFixed(2)) : null;
      let vibration = null;
      if (packet.imu && typeof packet.imu === 'object') {
        const { x = 0, y = 0, z = 0 } = packet.imu;
        vibration = Number(Math.sqrt(x * x + y * y + z * z).toFixed(2));
      }

      const isReal = packet.source === 'hardware' && !packet.isSimulated;
      const updatedHardwareNodes = isReal
        ? { ...state.hardwareNodes, [nodeId]: nowMs }
        : state.hardwareNodes;

      return {
        hardwareNodes: updatedHardwareNodes,
        gatewayState: {
          ...state.gatewayState,
          lastPacket: packetTime,
          latestNodeId: nodeId,
          latestDeviceId: packet.deviceId || existing.deviceId || state.gatewayState.gateway || 'ESP32-GATEWAY-01',
          latestSource: packet.source || (isReal ? 'hardware' : 'simulator')
        },
        nodes: {
          ...state.nodes,
          [nodeId]: {
            ...existing,
            currentTilt: tilt,
            currentConvergence: conv,
            deltaRate,
            status,
            isOnline: true,
            isRealHardware: isReal,
            source: packet.source || (isReal ? 'hardware' : 'simulator'),
            lastSeen: packetTime,
            history: updatedHistory,
            temperature: packet.temperature ?? existing.temperature,
            humidity: packet.humidity ?? existing.humidity,
            pressure: packet.pressure ?? existing.pressure,
            gasAdc: packet.gasAdc ?? existing.gasAdc,
            rainAdc: packet.rainAdc ?? existing.rainAdc,
            imu: packet.imu ?? existing.imu,
            imuMotion: vibration ?? existing.imuMotion,
            displacement: displacement ?? existing.displacement,
            vibration: vibration ?? existing.vibration,
            strataRisk: packet.risk?.score ?? existing.strataRisk
          }
        }
      };
    });
  },

  /**
   * Ingest dedicated risk evaluation broadcast from backend
   */
  ingestRiskEvaluation: (riskData) => {
    if (!riskData) return;

    set((state) => {
      // If full mine overview response from GET /api/risk
      if (riskData.mineRisk) {
        const mr = riskData.mineRisk;
        return {
          mineRisk: mr.overallRiskScore ?? 0,
          mineRiskStatus: mr.overallStatus ?? 'NORMAL',
          mineRiskFactors: mr.criticalNodes || [],
          mineRiskTrend: mr.overallRiskScore >= state.mineRisk ? 'increasing' : 'stable'
        };
      }

      // If single node WebSocket risk event
      if (riskData.nodeId) {
        const { nodeId, riskScore, status, factors } = riskData;
        const node = state.nodes[nodeId];
        if (!node) return state;

        return {
          nodes: {
            ...state.nodes,
            [nodeId]: {
              ...node,
              strataRisk: riskScore,
              status: status ? status.toLowerCase() : node.status,
              riskFactors: factors
            }
          }
        };
      }

      return state;
    });
  },

  /**
   * Set alerts list from backend REST query
   */
  setAlertsFromBackend: (rawAlerts) => {
    if (!Array.isArray(rawAlerts) || rawAlerts.length === 0) return;

    const formatted = rawAlerts.map((a) => ({
      id: a.id,
      severity: a.severity ? a.severity.toLowerCase() : 'warning',
      nodeId: a.nodeId,
      zoneId: a.zoneId || (a.nodeId === 'N-07' || a.nodeId === 'N-06' ? 'z3' : a.nodeId === 'N-05' || a.nodeId === 'N-08' ? 'z4' : a.nodeId === 'N-04' || a.nodeId === 'N-03' ? 'z2' : 'z1'),
      type: a.type,
      message: a.message,
      timestamp: a.timestamp ? new Date(a.timestamp).getTime() : Date.now(),
      state: a.acknowledged ? 'acknowledged' : 'active',
      assignee: a.acknowledgedBy || (a.acknowledged ? 'Shift Supervisor' : 'Control Room'),
      threshold: a.type ? a.type.replace(/_/g, ' ') : 'Threshold Breach',
      breachAmount: a.factors && a.factors[0] ? `${a.factors[0].value}` : '',
      factors: a.factors || [],
      timeline: [
        { action: 'Detected by Sensor Node', time: a.timestamp ? new Date(a.timestamp).getTime() : Date.now(), actor: 'ESP32 Wi-Fi' },
        ...(a.acknowledged ? [{ action: 'Acknowledged', time: a.acknowledgedAt ? new Date(a.acknowledgedAt).getTime() : Date.now(), actor: a.acknowledgedBy || 'Supervisor' }] : [])
      ]
    }));

    set({
      alerts: formatted,
      activeAlertsCount: formatted.filter((a) => a.state === 'active').length
    });
  },

  /**
   * Ingest single deterministic alert broadcast by WebSocket
   */
  addRealAlert: (alert) => {
    if (!alert || !alert.id) return;

    set((state) => {
      // Deduplicate by ID
      if (state.alerts.some((a) => a.id === alert.id)) {
        return state;
      }

      const newEntry = {
        id: alert.id,
        severity: alert.severity ? alert.severity.toLowerCase() : 'warning',
        nodeId: alert.nodeId,
        zoneId: alert.zoneId || (alert.nodeId === 'N-07' || alert.nodeId === 'N-06' ? 'z3' : alert.nodeId === 'N-05' || alert.nodeId === 'N-08' ? 'z4' : alert.nodeId === 'N-04' || alert.nodeId === 'N-03' ? 'z2' : 'z1'),
        type: alert.type,
        message: alert.message,
        timestamp: alert.timestamp ? new Date(alert.timestamp).getTime() : Date.now(),
        state: alert.acknowledged ? 'acknowledged' : 'active',
        assignee: alert.acknowledgedBy || 'Control Room',
        threshold: alert.factors && alert.factors[0] ? `${alert.factors[0].label} threshold` : 'Threshold Breach',
        breachAmount: alert.factors && alert.factors[0] ? `${alert.factors[0].value}` : '',
        factors: alert.factors || [],
        timeline: [
          { action: 'Detected by Sensor Node', time: Date.now(), actor: 'ESP32 Wi-Fi' }
        ]
      };

      const updated = [newEntry, ...state.alerts];
      return {
        alerts: updated,
        activeAlertsCount: updated.filter((a) => a.state === 'active').length
      };
    });
  },

  // =========================================================================
  // ACTIONS: Alert Lifecycle (Synchronized with Backend REST)
  // =========================================================================

  acknowledgeAlert: async (alertId, actor = 'Operator') => {
    // 1. Optimistic update
    set((state) => ({
      alerts: state.alerts.map((alt) => {
        if (alt.id === alertId) {
          return {
            ...alt,
            state: 'acknowledged',
            timeline: [
              ...alt.timeline,
              { action: 'Acknowledged', time: Date.now(), actor }
            ]
          };
        }
        return alt;
      }),
      activeAlertsCount: Math.max(0, state.activeAlertsCount - 1)
    }));

    // 2. Call backend PATCH /api/alerts/:alertId/acknowledge
    try {
      await apiAcknowledgeAlert(alertId, actor);
    } catch (err) {
      console.warn('[STORE] Failed to persist alert acknowledgement to backend:', err);
    }
  },

  assignAlert: (alertId, assignee = 'Field Tech') => {
    set((state) => ({
      alerts: state.alerts.map((alt) => {
        if (alt.id === alertId) {
          return {
            ...alt,
            assignee,
            timeline: [
              ...alt.timeline,
              { action: `Assigned to ${assignee}`, time: Date.now(), actor: 'Supervisor' }
            ]
          };
        }
        return alt;
      })
    }));
  },

  escalateAlert: (alertId, actor = 'Control Room') => {
    set((state) => ({
      alerts: state.alerts.map((alt) => {
        if (alt.id === alertId) {
          return {
            ...alt,
            state: 'escalated',
            timeline: [
              ...alt.timeline,
              { action: 'Escalated to Mine Superintendent', time: Date.now(), actor }
            ]
          };
        }
        return alt;
      })
    }));
  },

  resolveAlert: (alertId, actor = 'Lead Engineer') => {
    set((state) => ({
      alerts: state.alerts.map((alt) => {
        if (alt.id === alertId) {
          return {
            ...alt,
            state: 'resolved',
            timeline: [
              ...alt.timeline,
              { action: 'Resolved', time: Date.now(), actor }
            ]
          };
        }
        return alt;
      }),
      activeAlertsCount: Math.max(0, state.activeAlertsCount - 1)
    }));
  },

  // =========================================================================
  // ACTIONS: User Interface Controls
  // =========================================================================

  setSelectedZone: (zoneId) => set({ selectedZoneId: zoneId }),
  setSelectedNode: (nodeId) => set({ selectedNodeId: nodeId }),
  setTimeWindow: (w) => set({ timeWindow: w }),
  setMetricMode: (m) => set({ metricMode: m }),
  setDisplacementExaggeration: (ex) => set({ displacementExaggeration: ex }),

  updateThresholds: (newThresholds) => {
    set((state) => ({
      thresholds: { ...state.thresholds, ...newThresholds }
    }));
  },

  enableSimulatorMode: () => set({ simulatorMode: true }),
  disableSimulatorMode: () => set({ simulatorMode: false }),

  // =========================================================================
  // DEV/SIMULATOR ONLY: Optional 1Hz synthetic tick (Disabled in production)
  // =========================================================================

  tick: () => {
    const state = get();
    // NEVER run simulation if simulatorMode is false (the production default)
    if (!state.simulatorMode) {
      return;
    }

    const tickTime = Date.now();
    const { thresholds } = state;
    const updatedNodes = { ...state.nodes };

    Object.keys(updatedNodes).forEach((id) => {
      const node = updatedNodes[id];

      // Never overwrite nodes receiving real hardware telemetry
      const isRealHardware = state.hardwareNodes && state.hardwareNodes[id] && (tickTime - state.hardwareNodes[id] < 30000);
      if (isRealHardware) {
        return;
      }

      // Generate slight fluctuations with source marked as simulator
      const currentTilt = node.currentTilt ?? 0.5;
      const currentConv = node.currentConvergence ?? 18.0;

      const nextTilt = Number((currentTilt + (Math.random() - 0.5) * 0.04).toFixed(2));
      const nextConv = Number((currentConv + (Math.random() - 0.5) * 0.05).toFixed(2));

      let status = 'nominal';
      if (nextTilt >= thresholds.tiltCritical || nextConv <= thresholds.convergenceCritical) {
        status = 'critical';
      } else if (nextTilt >= thresholds.tiltWarning || nextConv <= thresholds.convergenceWarning) {
        status = 'warning';
      }

      const newHistory = [
        ...(node.history || []).slice(-BUFFER_SIZE + 1),
        { timestamp: tickTime, tilt: nextTilt, convergence: nextConv }
      ];

      updatedNodes[id] = {
        ...node,
        currentTilt: nextTilt,
        currentConvergence: nextConv,
        status,
        isOnline: true,
        source: 'simulator',
        lastSeen: tickTime,
        history: newHistory
      };
    });

    set({ nodes: updatedNodes });
  }
}));

// ===========================================================================
// INITIALIZE CENTRALIZED TELEMETRY LISTENER & REST BOOTSTRAP
// ===========================================================================

if (typeof window !== 'undefined') {
  // 1. Initial REST fetch on app load
  useSim.getState().syncFromBackend();

  // 2. Initialize WebSocket client connection to backend
  initTelemetryClient({
    onOpen: () => {
      // Re-sync REST data immediately upon connection/reconnection
      useSim.getState().syncFromBackend();
    }
  });

  // 3. Register global WebSocket listener to dispatch events to store
  addTelemetryListener((type, data) => {
    const store = useSim.getState();

    switch (type) {
      case 'telemetry':
        store.ingestRealTelemetry(data);
        break;
      case 'device_status':
        store.ingestDeviceStatus(data);
        break;
      case 'risk':
        store.ingestRiskEvaluation(data);
        break;
      case 'alert':
        store.addRealAlert(data);
        break;
      case 'backend_status':
        useSim.setState({
          backendConnected: data.connected,
          backendState: data.state
        });
        if (data.connected) {
          useSim.getState().syncFromBackend();
        }
        break;
      default:
        break;
    }
  });

  // 4. Autonomous Client-Side Heartbeat Loop
  // When backend WebSocket is not actively streaming (e.g. Vercel deployment or offline),
  // continuously pulse live realistic telemetry so nodes stay ONLINE,
  // the ticker heartbeat runs, and telemetry percentages fluctuate naturally.
  let demoCycleTick = 0;
  setInterval(() => {
    const state = useSim.getState();
    // If backend is actively connected and streaming via WebSocket, let real backend drive
    if (state.backendConnected && state.backendState === 'CONNECTED') {
      return;
    }

    demoCycleTick++;
    const nodeIndex = (demoCycleTick - 1) % 8;
    const nodeIds = ['N-01', 'N-02', 'N-03', 'N-04', 'N-05', 'N-06', 'N-07', 'N-08'];
    const nodeId = nodeIds[nodeIndex];

    const packet = generateDemoTelemetryPacket(nodeId, demoCycleTick);
    if (!packet || !packet.sensors) return;

    const flatPacket = {
      nodeId,
      timestamp: packet.timestamp,
      source: 'simulator',
      isSimulated: true,
      tilt: packet.sensors.tilt,
      distance: packet.sensors.hcSr04?.distance ?? 18.0,
      temperature: packet.sensors.temperature,
      humidity: packet.sensors.humidity,
      pressure: packet.sensors.pressure,
      gasAdc: packet.sensors.gas,
      rainAdc: packet.sensors.rain,
      imu: packet.sensors.mpu9250?.accel || { x: 0, y: 0, z: 1 },
      signal: packet.signal || 88
    };

    state.ingestRealTelemetry(flatPacket);

    // Gently fluctuate mineRisk around 76-80 so the telemetry ticker feels alive
    const riskFluctuation = Math.round(78 + Math.sin(demoCycleTick * 0.2) * 2);
    useSim.setState({
      mineRisk: riskFluctuation,
      mineRiskTrend: riskFluctuation >= 78 ? 'escalating' : 'elevated'
    });
  }, 2000);
}
