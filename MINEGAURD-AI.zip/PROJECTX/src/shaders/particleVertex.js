export const particleVertexShader = /* glsl */ `
  attribute vec3 posB;
  attribute float aSize;
  attribute float aRandom;
  varying vec3 vColor;
  varying float vAlpha;
  uniform float uTime;
  uniform float uMorph;
  uniform float uPixelRatio;
  uniform float uDirectionalFlow;
  uniform float uConcentration;
  uniform float uTurbulence;
  uniform float uNetworkDrift;

  // Simplex noise helper
  vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec4 permute(vec4 x) { return mod289(((x*34.0)+1.0)*x); }
  vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }
  
  float snoise(vec3 v) { 
    const vec2 C = vec2(1.0/6.0, 1.0/3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i  = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i); 
    vec4 p = permute(permute(permute( 
              i.z + vec4(0.0, i1.z, i2.z, 1.0 ))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0 )) 
            + i.x + vec4(0.0, i1.x, i2.x, 1.0 ));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_ );
    vec4 x = x_ *ns.x + ns.yyyy;
    vec4 y = y_ *ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4( x.xy, y.xy );
    vec4 b1 = vec4( x.zw, y.zw );
    vec4 s0 = floor(b0)*2.0 + 1.0;
    vec4 s1 = floor(b1)*2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
    vec3 p0 = vec3(a0.xy,h.x);
    vec3 p1 = vec3(a0.zw,h.y);
    vec3 p2 = vec3(a1.xy,h.z);
    vec3 p3 = vec3(a1.zw,h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2, p2), dot(p3,p3)));
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot( m*m, vec4( dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3) ) );
  }

  void main() {
    vColor = color;
    
    // Interpolate between states based on scroll
    vec3 p = mix(position, posB, uMorph);

    // Subtle concentration for Risk Analysis (slightly denser/more concentrated areas)
    p *= (1.0 - 0.12 * uConcentration);

    // Subtle directional movement for Live Monitoring
    float time = uTime * 0.15;
    p.x += sin(time * 0.5 + p.y * 0.15) * 0.4 * uDirectionalFlow;
    p.y += cos(time * 0.4 + p.x * 0.15) * 0.3 * uDirectionalFlow;

    // Subtle network-like movement for Sensor Nodes
    p.x += cos(uTime * 0.2 + aRandom * 6.28) * 0.3 * uNetworkDrift;
    p.z += sin(uTime * 0.2 + aRandom * 6.28) * 0.3 * uNetworkDrift;

    // Organic fluid flow
    vec3 noisePos = p * 0.3 + time;
    
    // Apply layered turbulence (with subtle localized disturbance for Alerts)
    float turb = 1.5 + 0.35 * uTurbulence;
    float nx = snoise(noisePos);
    float ny = snoise(noisePos + vec3(100.0));
    float nz = snoise(noisePos + vec3(200.0));
    
    p.x += nx * turb;
    p.y += ny * turb;
    p.z += nz * turb;

    // Breathe effect
    p *= 1.0 + sin(uTime * 0.5 + aRandom * 6.28) * 0.05;

    vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);
    
    float dist = -mvPosition.z;
    
    // Depth-based sizing & cinematic scale (capped to ensure particles remain fine and crisp, never giant blobs)
    gl_PointSize = clamp(aSize * uPixelRatio * (35.0 / max(dist, 3.5)), 1.0, 7.5);
    
    // Atmospheric depth fading: spec-compliant smoothsteps (edge0 < edge1)
    // Softly fades out particles that get too close to the lens (<2.5) or drift far into the void (>32.0)
    float alphaNear = smoothstep(0.4, 2.5, dist);
    float alphaFar = 1.0 - smoothstep(6.0, 32.0, dist);
    vAlpha = alphaNear * alphaFar * (0.32 + 0.68 * aRandom);
    
    gl_Position = projectionMatrix * mvPosition;
  }
`;
