export const particleFragmentShader = /* glsl */ `
  varying vec3 vColor;
  varying float vAlpha;
  
  void main() {
    // Soft Luminous Particle with bright core and halo
    vec2 xy = gl_PointCoord.xy - vec2(0.5);
    float d = length(xy);
    
    if (d > 0.5) discard;
    
    // Core & halo using specification-compliant smoothstep (edge0 < edge1)
    float shape = 1.0 - smoothstep(0.0, 0.5, d);
    
    // Core (tight, bright)
    float core = pow(shape, 3.0);
    
    // Halo (soft, wide)
    float halo = pow(shape, 1.2);
    
    float alpha = (core * 0.8 + halo * 0.3) * vAlpha;
    
    gl_FragColor = vec4(vColor, alpha);
  }
`;
