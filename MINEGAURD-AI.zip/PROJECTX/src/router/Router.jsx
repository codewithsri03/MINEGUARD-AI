import React, { createContext, useContext, useState, useEffect } from 'react';

const RouterContext = createContext({
  path: '/',
  navigate: () => {}
});

/**
 * Lightweight, production-grade router designed specifically for React 19 + Vite.
 * Eliminates duplicate React dependency conflicts and provides seamless history pushState navigation.
 */
export function Router({ children }) {
  const [path, setPath] = useState(window.location.pathname || '/');

  useEffect(() => {
    const handlePopState = () => {
      setPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (to) => {
    if (to !== window.location.pathname) {
      window.history.pushState({}, '', to);
      setPath(to);
      window.scrollTo(0, 0);
    }
  };

  return (
    <RouterContext.Provider value={{ path, navigate }}>
      {children}
    </RouterContext.Provider>
  );
}

/**
 * Hook to access current route path and navigation function.
 */
export function useRouter() {
  return useContext(RouterContext);
}

/**
 * Route component that renders its element when the path matches exactly.
 */
export function Route({ path: routePath, element }) {
  const { path } = useRouter();
  if (path === routePath) {
    return element;
  }
  return null;
}

/**
 * Link component for smooth client-side transitions.
 */
export function Link({ to, children, className, ...props }) {
  const { navigate } = useRouter();

  const handleClick = (e) => {
    e.preventDefault();
    navigate(to);
  };

  return (
    <a href={to} onClick={handleClick} className={className} {...props}>
      {children}
    </a>
  );
}
