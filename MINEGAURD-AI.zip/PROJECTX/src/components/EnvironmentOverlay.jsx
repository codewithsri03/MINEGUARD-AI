import React, { forwardRef } from 'react';

export const EnvironmentOverlay = forwardRef(function EnvironmentOverlay(props, ref) {
  return (
    <>
      {/* Radial vignette for cinematic edge falloff */}
      <div className="vignette-overlay" aria-hidden="true" />
      
      {/* Procedural micro-grain for filmic texture */}
      <div className="grain-overlay" aria-hidden="true" />

      {/* Subtle bottom scroll guide */}
      <div className="scroll-indicator" id="scroll-prompt" ref={ref} aria-hidden="true">
        <span className="scroll-indicator-text">Scroll to explore</span>
        <div className="scroll-indicator-line" />
      </div>
    </>
  );
});
