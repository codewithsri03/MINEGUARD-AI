import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * HowItWorksScene
 * Lightweight, technical WebGL visualization (~3,500 particles total)
 * dynamically transitioning across 7 stages:
 *   01. SENSORS (Sparse spatial nodes + pulsing beacons)
 *   02. ESP32 (Hardware gateway ingestion + signal lines)
 *   03. PROCESS (Chaotic jitter -> filtered parallel data streams)
 *   04. AI ENGINE (Abstract concentric rotating rings & tensor lattice)
 *   05. RISK SCORE (Clean multi-zone stratification: Normal / Warning / Critical)
 *   06. DIGITAL TWIN (Spatial wireframe tunnel drift & crown sensors)
 *   07. EARLY WARNING (Precise restrained alert beacon + complete pipeline)
 */
export function HowItWorksScene({ progress = 0 }) {
  const mountRef = useRef(null);
  const progressRef = useRef(progress);

  useEffect(() => {
    progressRef.current = progress;
  }, [progress]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // --- Renderer ---
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // --- Scene & Camera ---
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 11);

    // ============================================================
    // STAGE 01 & 02: SENSOR NODES & ESP32 HARDWARE HUBS
    // ============================================================
    const sensorNodesGroup = new THREE.Group();
    scene.add(sensorNodesGroup);

    const sensorPositions = [
      new THREE.Vector3(-3.2, 1.8, -0.5),
      new THREE.Vector3(-2.8, -1.6, 0.4),
      new THREE.Vector3(-1.6, 2.2, -0.2),
      new THREE.Vector3(-1.2, -2.0, 0.2),
      new THREE.Vector3(0.2, 2.4, -0.6),
      new THREE.Vector3(0.5, -2.2, 0.3)
    ];

    const espPositions = [
      new THREE.Vector3(-1.8, 0.0, 0.0),
      new THREE.Vector3(0.0, 0.0, 0.0)
    ];

    // Sensor Node Points
    const nodeGeometry = new THREE.SphereGeometry(0.08, 12, 12);
    const nodeMaterial = new THREE.MeshBasicMaterial({ color: 0x00E5FF });
    const pulseRingGeo = new THREE.RingGeometry(0.12, 0.14, 24);
    const pulseRingMat = new THREE.MeshBasicMaterial({
      color: 0x4FD8FF,
      transparent: true,
      opacity: 0.6,
      side: THREE.DoubleSide
    });

    sensorPositions.forEach((pos) => {
      const mesh = new THREE.Mesh(nodeGeometry, nodeMaterial);
      mesh.position.copy(pos);
      sensorNodesGroup.add(mesh);

      const ring = new THREE.Mesh(pulseRingGeo, pulseRingMat);
      ring.position.copy(pos);
      sensorNodesGroup.add(ring);
    });

    // ESP32 Hub Nodes
    const espGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.08, 6);
    const espMat = new THREE.MeshBasicMaterial({ color: 0x2B58FF });
    espPositions.forEach((pos) => {
      const mesh = new THREE.Mesh(espGeo, espMat);
      mesh.position.copy(pos);
      mesh.rotation.x = Math.PI / 2;
      sensorNodesGroup.add(mesh);
    });

    // Sensor -> ESP32 Connection Lines
    const linePositions = [];
    sensorPositions.forEach((sPos, idx) => {
      const targetEsp = idx < 3 ? espPositions[0] : espPositions[1];
      linePositions.push(sPos.x, sPos.y, sPos.z);
      linePositions.push(targetEsp.x, targetEsp.y, targetEsp.z);
    });

    const lineGeometry = new THREE.BufferGeometry();
    lineGeometry.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
    const lineMaterial = new THREE.LineBasicMaterial({
      color: 0x4FD8FF,
      transparent: true,
      opacity: 0.25
    });
    const connectionLines = new THREE.LineSegments(lineGeometry, lineMaterial);
    sensorNodesGroup.add(connectionLines);

    // Data packets traveling along lines
    const PACKET_COUNT = 48;
    const packetGeo = new THREE.BufferGeometry();
    const packetPos = new Float32Array(PACKET_COUNT * 3);
    packetGeo.setAttribute('position', new THREE.BufferAttribute(packetPos, 3));
    const packetMat = new THREE.PointsMaterial({
      color: 0xFFFFFF,
      size: 4,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending
    });
    const packetPoints = new THREE.Points(packetGeo, packetMat);
    sensorNodesGroup.add(packetPoints);

    // ============================================================
    // STAGE 03: DATA PROCESSING / FILTERING MATRIX
    // ============================================================
    const filterGroup = new THREE.Group();
    scene.add(filterGroup);

    const FILTER_PARTICLES = 1200;
    const filterGeo = new THREE.BufferGeometry();
    const filterOrigPos = new Float32Array(FILTER_PARTICLES * 3);
    const filterLivePos = new Float32Array(FILTER_PARTICLES * 3);
    const filterColors = new Float32Array(FILTER_PARTICLES * 3);

    for (let i = 0; i < FILTER_PARTICLES; i++) {
      const i3 = i * 3;
      const streamIdx = i % 8; // 8 parallel channels
      const x = -3.5 + (i / FILTER_PARTICLES) * 7.0;
      const y = (streamIdx - 3.5) * 0.45;
      const z = (Math.random() - 0.5) * 0.8;

      filterOrigPos[i3] = x;
      filterOrigPos[i3 + 1] = y;
      filterOrigPos[i3 + 2] = z;

      filterLivePos[i3] = x;
      filterLivePos[i3 + 1] = y;
      filterLivePos[i3 + 2] = z;

      filterColors[i3] = 0.2;
      filterColors[i3 + 1] = 0.7;
      filterColors[i3 + 2] = 1.0;
    }

    filterGeo.setAttribute('position', new THREE.BufferAttribute(filterLivePos, 3));
    filterGeo.setAttribute('color', new THREE.BufferAttribute(filterColors, 3));

    const filterMat = new THREE.PointsMaterial({
      size: 3,
      vertexColors: true,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending
    });
    const filterPoints = new THREE.Points(filterGeo, filterMat);
    filterGroup.add(filterPoints);

    // Subtle horizontal channel guides
    const guideLinesPos = [];
    for (let s = 0; s < 8; s++) {
      const y = (s - 3.5) * 0.45;
      guideLinesPos.push(-3.5, y, 0, 3.5, y, 0);
    }
    const guideLinesGeo = new THREE.BufferGeometry();
    guideLinesGeo.setAttribute('position', new THREE.Float32BufferAttribute(guideLinesPos, 3));
    const guideLinesMat = new THREE.LineBasicMaterial({
      color: 0x2B58FF,
      transparent: true,
      opacity: 0.0
    });
    const guideLines = new THREE.LineSegments(guideLinesGeo, guideLinesMat);
    filterGroup.add(guideLines);

    // ============================================================
    // STAGE 04: AI / ML COMPUTATIONAL CORE (Concentric Rings & Lattice)
    // ============================================================
    const aiCoreGroup = new THREE.Group();
    scene.add(aiCoreGroup);

    // 3 Nested Concentric Technical Rings
    const ringMat1 = new THREE.LineBasicMaterial({ color: 0x4FD8FF, transparent: true, opacity: 0.0 });
    const ringMat2 = new THREE.LineBasicMaterial({ color: 0x9B2BFF, transparent: true, opacity: 0.0 });
    const ringMat3 = new THREE.LineBasicMaterial({ color: 0x2B58FF, transparent: true, opacity: 0.0 });

    const ringMesh1 = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(new THREE.EllipseCurve(0, 0, 1.3, 1.3).getPoints(64)), ringMat1);
    const ringMesh2 = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(new THREE.EllipseCurve(0, 0, 2.0, 2.0).getPoints(64)), ringMat2);
    const ringMesh3 = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(new THREE.EllipseCurve(0, 0, 2.6, 2.6).getPoints(64)), ringMat3);

    aiCoreGroup.add(ringMesh1);
    aiCoreGroup.add(ringMesh2);
    aiCoreGroup.add(ringMesh3);

    // Geodesic / Tensor Lattice Nodes
    const CORE_POINTS = 800;
    const corePointsGeo = new THREE.BufferGeometry();
    const corePointsPos = new Float32Array(CORE_POINTS * 3);
    for (let i = 0; i < CORE_POINTS; i++) {
      const i3 = i * 3;
      const phi = Math.acos(2 * Math.random() - 1);
      const theta = Math.random() * Math.PI * 2;
      const r = 0.6 + Math.random() * 1.8;
      corePointsPos[i3] = r * Math.sin(phi) * Math.cos(theta);
      corePointsPos[i3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      corePointsPos[i3 + 2] = r * Math.cos(phi);
    }
    corePointsGeo.setAttribute('position', new THREE.BufferAttribute(corePointsPos, 3));
    const corePointsMat = new THREE.PointsMaterial({
      color: 0x9B2BFF,
      size: 2.8,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending
    });
    const corePoints = new THREE.Points(corePointsGeo, corePointsMat);
    aiCoreGroup.add(corePoints);

    // ============================================================
    // STAGE 05: SUBSIDENCE RISK SCORE (3-State Stratification)
    // ============================================================
    const riskGroup = new THREE.Group();
    scene.add(riskGroup);

    // 3 Technical Radial Arcs
    const createArc = (radius, startAngle, endAngle, color) => {
      const points = [];
      const steps = 36;
      for (let i = 0; i <= steps; i++) {
        const theta = startAngle + (endAngle - startAngle) * (i / steps);
        points.push(new THREE.Vector3(radius * Math.cos(theta), radius * Math.sin(theta), 0));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      const mat = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.0, linewidth: 2 });
      return new THREE.Line(geo, mat);
    };

    // NORMAL (Green/Cyan): Bottom arc
    const arcNormal = createArc(2.2, Math.PI * 0.85, Math.PI * 1.25, 0x00E5A3);
    // WARNING (Amber): Top-left arc
    const arcWarning = createArc(2.2, Math.PI * 1.35, Math.PI * 1.75, 0xFFB703);
    // CRITICAL (Red): Right focal arc
    const arcCritical = createArc(2.2, Math.PI * 1.85, Math.PI * 2.25, 0xFF3366);

    riskGroup.add(arcNormal);
    riskGroup.add(arcWarning);
    riskGroup.add(arcCritical);

    // ============================================================
    // STAGE 06: DIGITAL TWIN / UNDERGROUND SPATIAL REPRESENTATION
    // ============================================================
    const twinGroup = new THREE.Group();
    scene.add(twinGroup);

    // Wireframe Tunnel Profile: series of arched ribs along Z-axis
    const tunnelRibs = [];
    const ribCount = 9;
    for (let r = 0; r < ribCount; r++) {
      const zPos = -3.5 + r * 0.85;
      const ribPoints = [];
      // Floor
      ribPoints.push(new THREE.Vector3(-1.8, -1.5, zPos));
      ribPoints.push(new THREE.Vector3(1.8, -1.5, zPos));
      // Right sidewall
      ribPoints.push(new THREE.Vector3(1.8, 0.4, zPos));
      // Crown arch
      for (let a = 0; a <= 12; a++) {
        const angle = (a / 12) * Math.PI;
        ribPoints.push(new THREE.Vector3(1.8 * Math.cos(angle), 0.4 + 1.2 * Math.sin(angle), zPos));
      }
      // Left sidewall
      ribPoints.push(new THREE.Vector3(-1.8, 0.4, zPos));
      ribPoints.push(new THREE.Vector3(-1.8, -1.5, zPos));

      const ribGeo = new THREE.BufferGeometry().setFromPoints(ribPoints);
      const isDisplacementZone = r >= 4 && r <= 6;
      const ribMat = new THREE.LineBasicMaterial({
        color: isDisplacementZone ? 0xFFB703 : 0x2B58FF,
        transparent: true,
        opacity: 0.0
      });
      const ribLine = new THREE.Line(ribGeo, ribMat);
      twinGroup.add(ribLine);
      tunnelRibs.push(ribLine);
    }

    // Tunnel Crown Sensor Nodes
    const twinSensorGeo = new THREE.BufferGeometry();
    const twinSensorPos = new Float32Array(ribCount * 3);
    for (let r = 0; r < ribCount; r++) {
      const zPos = -3.5 + r * 0.85;
      twinSensorPos[r * 3] = 0;
      twinSensorPos[r * 3 + 1] = 1.6;
      twinSensorPos[r * 3 + 2] = zPos;
    }
    twinSensorGeo.setAttribute('position', new THREE.BufferAttribute(twinSensorPos, 3));
    const twinSensorMat = new THREE.PointsMaterial({
      color: 0x4FD8FF,
      size: 4,
      transparent: true,
      opacity: 0.0
    });
    const twinSensorPoints = new THREE.Points(twinSensorGeo, twinSensorMat);
    twinGroup.add(twinSensorPoints);

    // ============================================================
    // STAGE 07: ALERT ENGINE BEACON
    // ============================================================
    const alertGroup = new THREE.Group();
    scene.add(alertGroup);

    // Precision Crosshair & Focused Beacon
    const crossPoints = [
      new THREE.Vector3(-0.6, 0, 0), new THREE.Vector3(0.6, 0, 0),
      new THREE.Vector3(0, -0.6, 0), new THREE.Vector3(0, 0.6, 0)
    ];
    const crossGeo = new THREE.BufferGeometry().setFromPoints(crossPoints);
    const crossMat = new THREE.LineBasicMaterial({ color: 0xFF3366, transparent: true, opacity: 0.0 });
    const crossLine = new THREE.LineSegments(crossGeo, crossMat);
    alertGroup.add(crossLine);

    const alertBeaconGeo = new THREE.RingGeometry(0.75, 0.82, 32);
    const alertBeaconMat = new THREE.MeshBasicMaterial({
      color: 0xFF3366,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide
    });
    const alertBeaconMesh = new THREE.Mesh(alertBeaconGeo, alertBeaconMat);
    alertGroup.add(alertBeaconMesh);

    // ============================================================
    // ANIMATION & SCROLL STATE RENDER LOOP
    // ============================================================
    const clock = new THREE.Clock();
    let animId = null;
    let isVisible = true;

    const onVisibility = () => {
      isVisible = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', onVisibility);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const animate = () => {
      animId = requestAnimationFrame(animate);
      if (!isVisible) return;

      const time = clock.getElapsedTime();
      const p = progressRef.current; // 0.0 -> 1.0

      // --- 1. Stage Opacity Calculation based on scroll progress ---
      // Stage 1 & 2: p in [0.0, 0.35]
      const s12Opacity = THREE.MathUtils.clamp(1.0 - (p - 0.25) / 0.15, 0.0, 1.0);
      nodeMaterial.opacity = s12Opacity;
      pulseRingMat.opacity = s12Opacity * 0.45;
      espMat.opacity = s12Opacity;
      lineMaterial.opacity = THREE.MathUtils.clamp(p / 0.15, 0.0, 1.0) * s12Opacity * 0.3;
      packetMat.opacity = THREE.MathUtils.clamp(p / 0.15, 0.0, 1.0) * s12Opacity * 0.85;

      // Pulse ring scaling
      const pulseScale = 1.0 + (time * 1.5) % 1.5;
      pulseRingGeo.parameters && pulseRingMat;
      sensorNodesGroup.children.forEach((child) => {
        if (child.geometry instanceof THREE.RingGeometry) {
          child.scale.set(pulseScale, pulseScale, 1);
        }
      });

      // Data packets travel along line vectors
      if (s12Opacity > 0.05) {
        const pPositions = packetGeo.attributes.position.array;
        for (let k = 0; k < PACKET_COUNT; k++) {
          const pairIdx = k % sensorPositions.length;
          const sPos = sensorPositions[pairIdx];
          const ePos = pairIdx < 3 ? espPositions[0] : espPositions[1];
          const tP = ((time * 0.8 + k / PACKET_COUNT) % 1.0);
          pPositions[k * 3] = THREE.MathUtils.lerp(sPos.x, ePos.x, tP);
          pPositions[k * 3 + 1] = THREE.MathUtils.lerp(sPos.y, ePos.y, tP);
          pPositions[k * 3 + 2] = THREE.MathUtils.lerp(sPos.z, ePos.z, tP);
        }
        packetGeo.attributes.position.needsUpdate = true;
      }

      // --- 2. Stage 3 (Data Processing / Filtering): p in [0.25, 0.48] ---
      const s3FadeIn = THREE.MathUtils.clamp((p - 0.22) / 0.08, 0.0, 1.0);
      const s3FadeOut = THREE.MathUtils.clamp(1.0 - (p - 0.44) / 0.08, 0.0, 1.0);
      const s3Opacity = Math.min(s3FadeIn, s3FadeOut);
      filterMat.opacity = s3Opacity * 0.85;
      guideLinesMat.opacity = s3Opacity * 0.25;

      // Noise filtration: high jitter at p=0.28, perfectly clean at p=0.40
      const filterNoise = THREE.MathUtils.clamp(1.0 - (p - 0.28) / 0.12, 0.0, 1.0);
      const fPos = filterGeo.attributes.position.array;
      for (let i = 0; i < FILTER_PARTICLES; i++) {
        const i3 = i * 3;
        const origY = filterOrigPos[i3 + 1];
        const jitter = Math.sin(time * 6.0 + i * 0.5) * 0.45 * filterNoise;
        fPos[i3] = filterOrigPos[i3] + Math.sin(time * 2.0 + i) * 0.08;
        fPos[i3 + 1] = origY + jitter;
      }
      filterGeo.attributes.position.needsUpdate = true;

      // --- 3. Stage 4 (AI Engine Concentric Rings): p in [0.40, 0.62] ---
      const s4FadeIn = THREE.MathUtils.clamp((p - 0.38) / 0.08, 0.0, 1.0);
      const s4FadeOut = THREE.MathUtils.clamp(1.0 - (p - 0.58) / 0.08, 0.0, 1.0);
      const s4Opacity = Math.min(s4FadeIn, s4FadeOut);
      ringMat1.opacity = s4Opacity * 0.7;
      ringMat2.opacity = s4Opacity * 0.55;
      ringMat3.opacity = s4Opacity * 0.4;
      corePointsMat.opacity = s4Opacity * 0.75;

      ringMesh1.rotation.x = time * 0.35;
      ringMesh1.rotation.y = time * 0.25;
      ringMesh2.rotation.y = -time * 0.3;
      ringMesh2.rotation.z = time * 0.2;
      ringMesh3.rotation.x = -time * 0.2;
      ringMesh3.rotation.z = -time * 0.25;
      corePoints.rotation.y = time * 0.15;

      // --- 4. Stage 5 (Subsidence Risk Score): p in [0.55, 0.74] ---
      const s5FadeIn = THREE.MathUtils.clamp((p - 0.53) / 0.08, 0.0, 1.0);
      const s5FadeOut = THREE.MathUtils.clamp(1.0 - (p - 0.70) / 0.08, 0.0, 1.0);
      const s5Opacity = Math.min(s5FadeIn, s5FadeOut);
      arcNormal.material.opacity = s5Opacity * 0.8;
      arcWarning.material.opacity = s5Opacity * 0.85;
      arcCritical.material.opacity = s5Opacity * 0.9;
      riskGroup.rotation.z = Math.sin(time * 0.5) * 0.08;

      // --- 5. Stage 6 (Digital Twin Tunnel): p in [0.68, 0.88] ---
      const s6FadeIn = THREE.MathUtils.clamp((p - 0.66) / 0.08, 0.0, 1.0);
      const s6FadeOut = THREE.MathUtils.clamp(1.0 - (p - 0.86) / 0.08, 0.0, 1.0);
      const s6Opacity = Math.min(s6FadeIn, s6FadeOut);
      tunnelRibs.forEach((rib, idx) => {
        const isDisplaced = idx >= 4 && idx <= 6;
        rib.material.opacity = s6Opacity * (isDisplaced ? 0.75 : 0.35);
      });
      twinSensorMat.opacity = s6Opacity * 0.85;
      twinGroup.rotation.y = -0.35 + Math.sin(time * 0.3) * 0.08;
      twinGroup.rotation.x = 0.15;

      // --- 6. Stage 7 (Alert Engine & Unified Pipeline): p in [0.82, 1.0] ---
      const s7Opacity = THREE.MathUtils.clamp((p - 0.80) / 0.08, 0.0, 1.0);
      crossMat.opacity = s7Opacity * 0.9;
      alertBeaconMat.opacity = s7Opacity * (0.4 + 0.3 * Math.sin(time * 3.5));
      alertBeaconMesh.scale.setScalar(1.0 + 0.08 * Math.sin(time * 3.5));

      // At Stage 7: all pipeline components fade back in faintly connected
      if (p > 0.85) {
        const finalBlend = (p - 0.85) / 0.15;
        nodeMaterial.opacity = Math.max(nodeMaterial.opacity, finalBlend * 0.35);
        lineMaterial.opacity = Math.max(lineMaterial.opacity, finalBlend * 0.15);
        ringMat1.opacity = Math.max(ringMat1.opacity, finalBlend * 0.25);
        tunnelRibs.forEach((rib) => {
          rib.material.opacity = Math.max(rib.material.opacity, finalBlend * 0.2);
        });
      }

      // --- Camera Cinematic Orbiting ---
      camera.position.x = Math.sin(p * Math.PI * 0.8) * 0.8;
      camera.position.y = Math.cos(p * Math.PI * 0.5) * 0.4;
      camera.position.z = THREE.MathUtils.lerp(10.5, 8.5, p);
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);

      // Clean up WebGL resources
      nodeGeometry.dispose();
      nodeMaterial.dispose();
      pulseRingGeo.dispose();
      pulseRingMat.dispose();
      espGeo.dispose();
      espMat.dispose();
      lineGeometry.dispose();
      lineMaterial.dispose();
      packetGeo.dispose();
      packetMat.dispose();
      filterGeo.dispose();
      filterMat.dispose();
      guideLinesGeo.dispose();
      guideLinesMat.dispose();
      ringMat1.dispose();
      ringMat2.dispose();
      ringMat3.dispose();
      corePointsGeo.dispose();
      corePointsMat.dispose();
      arcNormal.geometry.dispose();
      arcNormal.material.dispose();
      arcWarning.geometry.dispose();
      arcWarning.material.dispose();
      arcCritical.geometry.dispose();
      arcCritical.material.dispose();
      tunnelRibs.forEach((r) => {
        r.geometry.dispose();
        r.material.dispose();
      });
      twinSensorGeo.dispose();
      twinSensorMat.dispose();
      crossGeo.dispose();
      crossMat.dispose();
      alertBeaconGeo.dispose();
      alertBeaconMat.dispose();
      renderer.dispose();

      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className="hiw-visualization-panel">
      <div className="hiw-canvas-wrapper" ref={mountRef}>
        <div className="hiw-canvas-grid-overlay" aria-hidden="true" />
        <div className="hiw-canvas-corner-brackets" aria-hidden="true">
          <div className="hiw-corner-tl" />
          <div className="hiw-corner-tr" />
          <div className="hiw-corner-bl" />
          <div className="hiw-corner-br" />
        </div>
        <div className="hiw-canvas-telemetry-tag">
          <span className="hiw-telemetry-dot" />
          <span>MG-AI PIPELINE [ACTIVE]</span>
        </div>
      </div>
    </div>
  );
}
