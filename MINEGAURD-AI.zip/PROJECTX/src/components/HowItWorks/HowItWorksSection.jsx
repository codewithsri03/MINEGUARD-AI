import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { HowItWorksStages, STAGES_DATA } from './HowItWorksStages';
import { HowItWorksScene } from './HowItWorksScene';
import '../../styles/howItWorks.css';

gsap.registerPlugin(ScrollTrigger);

/**
 * HowItWorksSection
 * Page 2 of PROJECTX: Continuous scroll-driven technical pipeline assembly
 * explaining: HOW MINEGUARD TURNS SENSOR READINGS INTO EARLY-WARNING INTELLIGENCE
 */
export function HowItWorksSection() {
  const sectionRef = useRef(null);
  const trackRef = useRef(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [currentStageIndex, setCurrentStageIndex] = useState(0);

  useEffect(() => {
    const section = sectionRef.current;
    const track = trackRef.current;
    if (!section || !track) return;

    // --- 1. Transition: Smoothly fade Home's fixed canvas as How It Works enters ---
    const homeCanvasTween = gsap.to('.canvas-container', {
      opacity: 0,
      ease: 'none',
      scrollTrigger: {
        trigger: section,
        start: 'top 85%',
        end: 'top 20%',
        scrub: true
      }
    });

    // --- 2. 7-Stage Scroll Progression Timeline ---
    const scrollTriggerInstance = ScrollTrigger.create({
      trigger: track,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1.2,
      onUpdate: (self) => {
        const p = self.progress; // 0.0 -> 1.0
        setScrollProgress(p);

        // Map progress to 0-6 stage index
        // Each stage gets approximately 1/7 (~0.142) of the runway
        const stageIdx = Math.min(
          STAGES_DATA.length - 1,
          Math.floor(p * STAGES_DATA.length)
        );
        setCurrentStageIndex(stageIdx);
      }
    });

    return () => {
      if (homeCanvasTween.scrollTrigger) {
        homeCanvasTween.scrollTrigger.kill();
      }
      homeCanvasTween.kill();
      scrollTriggerInstance.kill();
    };
  }, []);

  return (
    <section className="hiw-section" id="how-it-works" ref={sectionRef}>
      {/* Header Introduction */}
      <div className="hiw-header-container">
        <div className="hiw-badge">
          <span className="hiw-badge-dot" aria-hidden="true" />
          <span>System Architecture</span>
        </div>

        <h2 className="hiw-main-heading">
          <span>FROM GROUND MOVEMENT</span>
          <span>TO EARLY WARNING</span>
        </h2>

        <p className="hiw-supporting-text">
          MineGuard collects sensor readings through ESP32, processes the incoming data,
          evaluates subsidence risk, and presents the result through risk zones and alerts.
        </p>
      </div>

      {/* Pinned 650vh Scroll Runway */}
      <div className="hiw-scroll-track" ref={trackRef}>
        <div className="hiw-sticky-viewport">
          <div className="hiw-inner-layout">
            {/* Left Column: Stage Text Progression */}
            <HowItWorksStages currentStageIndex={currentStageIndex} />

            {/* Right Column: 3D Technical Visualization */}
            <HowItWorksScene progress={scrollProgress} />
          </div>
        </div>
      </div>

      {/* Complete Connected Pipeline Summary */}
      <div className="hiw-pipeline-summary">
        <div className="hiw-badge">
          <span className="hiw-badge-dot" aria-hidden="true" />
          <span>Complete Pipeline</span>
        </div>

        <div className="hiw-pipeline-flow">
          <span className="hiw-flow-step">SENSORS</span>
          <span className="hiw-flow-arrow" aria-hidden="true">→</span>
          <span className="hiw-flow-step">ESP32</span>
          <span className="hiw-flow-arrow" aria-hidden="true">→</span>
          <span className="hiw-flow-step">DATA FILTERING</span>
          <span className="hiw-flow-arrow" aria-hidden="true">→</span>
          <span className="hiw-flow-step">AI/ML RISK ENGINE</span>
          <span className="hiw-flow-arrow" aria-hidden="true">→</span>
          <span className="hiw-flow-step">RISK SCORE</span>
          <span className="hiw-flow-arrow" aria-hidden="true">→</span>
          <span className="hiw-flow-step">DIGITAL TWIN</span>
          <span className="hiw-flow-arrow" aria-hidden="true">→</span>
          <span className="hiw-flow-step">EARLY WARNING</span>
        </div>
      </div>
    </section>
  );
}

export default HowItWorksSection;
