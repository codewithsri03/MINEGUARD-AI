import React from 'react';

export const STAGES_DATA = [
  {
    id: 1,
    label: '01 / SENSE',
    title: 'SENSE THE GROUND',
    description: 'Tilt and distance sensors capture changes associated with ground movement.',
    status: 'SURFACE & DRIFT SENSORS ACTIVE',
    statusType: 'normal'
  },
  {
    id: 2,
    label: '02 / ACQUIRE',
    title: 'COLLECT THE SIGNAL',
    description: 'ESP32 nodes collect sensor readings for continuous data acquisition.',
    status: 'ESP32 HARDWARE BUS INGESTION',
    statusType: 'normal'
  },
  {
    id: 3,
    label: '03 / PROCESS',
    title: 'FILTER THE DATA',
    description: 'Incoming readings are processed and filtered before risk analysis.',
    status: 'NOISE REDUCTION & DATA VECTORING',
    statusType: 'normal'
  },
  {
    id: 4,
    label: '04 / ANALYZE',
    title: 'TURN DATA INTO RISK',
    description: 'The AI/ML risk engine analyzes processed readings to produce a subsidence risk assessment.',
    status: 'AI/ML RISK ENGINE COMPUTATION',
    statusType: 'normal'
  },
  {
    id: 5,
    label: '05 / ASSESS',
    title: 'IDENTIFY THE RISK',
    description: 'Processed sensor information is converted into a subsidence risk score and zone-wise risk information.',
    status: 'RISK STRATIFICATION: NORMAL / WARNING / CRITICAL',
    statusType: 'warning'
  },
  {
    id: 6,
    label: '06 / VISUALIZE',
    title: 'SEE THE RISK ZONE',
    description: 'Risk information is represented through the digital twin to provide zone-wise visibility of underground conditions.',
    status: 'DIGITAL TWIN UNDERGROUND RECONSTRUCTION',
    statusType: 'warning'
  },
  {
    id: 7,
    label: '07 / RESPOND',
    title: 'TRIGGER AN EARLY WARNING',
    description: 'When risk conditions require attention, MineGuard surfaces an early warning for mine authorities.',
    status: 'EARLY WARNING INTELLIGENCE DISPATCHED',
    statusType: 'critical'
  }
];

export function HowItWorksStages({ currentStageIndex }) {
  return (
    <div className="hiw-left-panel">
      {/* 7-Step Progress Indicator */}
      <div className="hiw-stepper" aria-label="Pipeline Progress">
        {STAGES_DATA.map((stage, idx) => {
          const isActive = idx === currentStageIndex;
          const isPassed = idx < currentStageIndex;
          return (
            <div
              key={stage.id}
              className={`hiw-step-tick ${isActive ? 'active' : ''} ${isPassed ? 'passed' : ''}`}
              title={stage.label}
            />
          );
        })}
      </div>

      {/* Stage Cards with Smooth Fade / Blur Transitions */}
      <div className="hiw-stage-card-stack">
        {STAGES_DATA.map((stage, idx) => {
          let cardState = '';
          if (idx === currentStageIndex) cardState = 'active';
          else if (idx < currentStageIndex) cardState = 'prev';

          return (
            <div
              key={stage.id}
              className={`hiw-stage-card ${cardState}`}
              aria-hidden={idx !== currentStageIndex}
            >
              <div className="hiw-stage-label">{stage.label}</div>
              <h3 className="hiw-stage-title">{stage.title}</h3>
              <p className="hiw-stage-description">{stage.description}</p>
              
              <div className={`hiw-status-pill status-${stage.statusType}`}>
                <span className="hiw-badge-dot" style={{
                  backgroundColor: stage.statusType === 'critical' ? '#FF3366' : stage.statusType === 'warning' ? '#FFB703' : '#00E5A3',
                  boxShadow: `0 0 8px ${stage.statusType === 'critical' ? '#FF3366' : stage.statusType === 'warning' ? '#FFB703' : '#00E5A3'}`
                }} />
                <span>{stage.status}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
