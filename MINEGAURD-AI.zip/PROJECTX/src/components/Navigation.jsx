import React, { useState, useEffect } from 'react';

const NAV_ITEMS = [
  { id: 'monitoring', label: 'MONITORING' },
  { id: 'risk-analysis', label: 'RISK' },
  { id: 'digital-twin', label: 'DIGITAL TWIN' },
  { id: 'alerts', label: 'ALERTS' },
  { id: 'nodes', label: 'NODES' }
];

export function Navigation() {
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      const sectionIds = ['home', 'monitoring', 'risk-analysis', 'digital-twin', 'alerts', 'nodes'];

      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const el = document.getElementById(sectionIds[i]);
        if (el && el.offsetTop <= scrollPos) {
          setActiveSection(sectionIds[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="floating-nav" aria-label="Main Navigation">
      {/* Brand logo scrolling to Home */}
      <button 
        className="nav-brand nav-brand-btn" 
        onClick={() => scrollToSection('home')}
        title="MineGuard AI Home"
      >
        <span className="brand-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path 
              d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" 
              stroke="#4FD8FF" 
              strokeWidth="2" 
              strokeLinejoin="round" 
            />
          </svg>
        </span>
        <span>MINEGUARD AI</span>
      </button>

      {/* Floating Section Links */}
      <div className="nav-links-wrap">
        {NAV_ITEMS.map((item) => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              className={`nav-link-btn ${isActive ? 'active' : ''}`}
              onClick={() => scrollToSection(item.id)}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
