import React, { forwardRef } from 'react';

export const Hero = forwardRef(function Hero(props, ref) {
  return (
    <section className="hero-fixed" id="hero-block" ref={ref} aria-label="Hero">
      <div className="hero-interactive">
        <div className="hero-badge">
          <span className="badge-dot" aria-hidden="true"></span>
          <span>Welcome to a new era</span>
        </div>

        <h1 className="hero-title" id="hero-title">
          <span className="hero-line">TECHNOLOGY THAT SEES</span>
          <span className="hero-line">THE GROUND BEFORE</span>
          <span className="hero-line">IT MOVES</span>
        </h1>

        <p className="hero-subtitle" id="hero-sub">
          Real-time mine subsidence monitoring,<br />
          AI-powered risk prediction,<br />
          and early warning intelligence.
        </p>

        <div className="hero-actions" id="hero-actions">
          <a href="#explore" className="btn btn-primary">
            <span>Explore MineGuard</span>
            <svg 
              className="btn-arrow" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </a>
          <a href="#how-it-works" className="btn">
            <span>See how it works</span>
          </a>
        </div>
      </div>
    </section>
  );
});
