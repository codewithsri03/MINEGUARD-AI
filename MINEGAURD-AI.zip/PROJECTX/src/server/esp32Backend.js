import net from 'net';

/**
 * MineGuard AI — ESP32 Hardware Integration Backend Service
 *
 * Implements real hardware reachability probing and telemetry ingestion:
 * ESP32 + sensors -> Wi-Fi -> MineGuard Backend -> React Frontend
 *
 * Real Endpoints:
 * - GET  /api/devices/status      -> current device connection state & statistics
 * - POST /api/devices/connect     -> probe ESP32 network reachability at given IP/port
 * - POST /api/devices/disconnect  -> terminate connection state
 * - POST /api/telemetry           -> ingest real telemetry packet from ESP32
 * - GET  /api/telemetry/latest    -> retrieve latest verified telemetry payload
 */

// In-memory backend connection & telemetry state
let deviceState = {
  connected: false,
  status: 'disconnected', // 'disconnected' | 'connecting' | 'connected' | 'error'
  device: null, // e.g. { host: '192.168.1.100', port: 80, model: 'ESP32-GATEWAY-01', connectedAt: ... }
  error: null,
  nodesOnline: 0,
  lastPacket: null,
  signal: null,
  latestTelemetry: null
};

// Timeout constants for network probing & stale packet detection
export const PROBE_TIMEOUT_MS = 2500;
export const STALE_TIMEOUT_MS = 5000;
export const DISCONNECT_TIMEOUT_MS = 15000;

/**
 * Probe real TCP socket reachability on target ESP32 host/port.
 * Does not fake success. Only resolves true if a socket handshake completes.
 */
export function probeEsp32Reachability(host, port = 80, timeout = PROBE_TIMEOUT_MS) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let hasResponded = false;

    socket.setTimeout(timeout);

    socket.on('connect', () => {
      hasResponded = true;
      socket.destroy();
      resolve({ reachable: true, error: null });
    });

    socket.on('timeout', () => {
      if (!hasResponded) {
        hasResponded = true;
        socket.destroy();
        resolve({ reachable: false, error: 'Connection timed out (Host unreachable)' });
      }
    });

    socket.on('error', (err) => {
      if (!hasResponded) {
        hasResponded = true;
        socket.destroy();
        resolve({ reachable: false, error: err.message || 'Unable to connect to host' });
      }
    });

    try {
      socket.connect(port, host);
    } catch (err) {
      resolve({ reachable: false, error: err.message });
    }
  });
}

/**
 * Connect to an ESP32 device at the given host.
 */
export async function handleConnectDevice(host, port = 80) {
  if (!host || typeof host !== 'string') {
    return {
      success: false,
      error: 'Invalid IP address or hostname provided.',
      state: deviceState
    };
  }

  deviceState.status = 'connecting';
  deviceState.error = null;

  const probe = await probeEsp32Reachability(host.trim(), Number(port) || 80);

  if (probe.reachable) {
    deviceState.connected = true;
    deviceState.status = 'connected';
    deviceState.device = {
      host: host.trim(),
      port: Number(port) || 80,
      model: 'ESP32-GATEWAY-01',
      connectedAt: Date.now()
    };
    deviceState.error = null;
    return { success: true, state: deviceState };
  } else {
    deviceState.connected = false;
    deviceState.status = 'error';
    deviceState.device = null;
    deviceState.nodesOnline = 0;
    deviceState.signal = null;
    deviceState.lastPacket = null;
    deviceState.error = `Unable to reach ESP32 at ${host.trim()} (${probe.error})`;
    return { success: false, error: deviceState.error, state: deviceState };
  }
}

/**
 * Disconnect current device.
 */
export function handleDisconnectDevice() {
  deviceState = {
    connected: false,
    status: 'disconnected',
    device: null,
    error: null,
    nodesOnline: 0,
    lastPacket: null,
    signal: null,
    latestTelemetry: null
  };
  return { success: true, state: deviceState };
}

/**
 * Ingest real telemetry from ESP32 device.
 */
export function handleIngestTelemetry(payload) {
  if (!payload || typeof payload !== 'object') {
    return { success: false, error: 'Invalid telemetry payload.' };
  }

  const timestamp = payload.timestamp ? Number(payload.timestamp) : Date.now();
  const nodes = Array.isArray(payload.nodes) ? payload.nodes : [];

  deviceState.connected = true;
  deviceState.status = 'connected';
  deviceState.lastPacket = timestamp;
  deviceState.nodesOnline = nodes.length;
  deviceState.signal = payload.signal !== undefined ? Number(payload.signal) : (payload.rssi ? Math.min(100, Math.max(0, 100 + Number(payload.rssi))) : null);
  deviceState.latestTelemetry = payload;

  return { success: true, state: deviceState };
}

/**
 * Return current device state with stale packet inspection.
 */
export function getDeviceState() {
  if (deviceState.connected && deviceState.lastPacket) {
    const elapsed = Date.now() - deviceState.lastPacket;
    if (elapsed > DISCONNECT_TIMEOUT_MS) {
      deviceState.status = 'disconnected';
      deviceState.connected = false;
      deviceState.error = 'Telemetry timed out (No packets received in 15s)';
    }
  }
  return deviceState;
}

/**
 * Middleware handler for Vite dev server / Connect / Express.
 */
export function esp32ApiMiddleware(req, res, next) {
  const url = req.url || '';

  if (!url.startsWith('/api/devices') && !url.startsWith('/api/telemetry')) {
    return next();
  }

  res.setHeader('Content-Type', 'application/json');

  // GET /api/devices/status
  if (url === '/api/devices/status' && req.method === 'GET') {
    res.statusCode = 200;
    return res.end(JSON.stringify(getDeviceState()));
  }

  // POST /api/devices/connect
  if (url === '/api/devices/connect' && req.method === 'POST') {
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', async () => {
      try {
        const data = body ? JSON.parse(body) : {};
        const result = await handleConnectDevice(data.host, data.port);
        res.statusCode = result.success ? 200 : 503;
        res.end(JSON.stringify(result));
      } catch (err) {
        res.statusCode = 400;
        res.end(JSON.stringify({ success: false, error: err.message, state: deviceState }));
      }
    });
    return;
  }

  // POST /api/devices/disconnect
  if (url === '/api/devices/disconnect' && req.method === 'POST') {
    const result = handleDisconnectDevice();
    res.statusCode = 200;
    return res.end(JSON.stringify(result));
  }

  // POST /api/telemetry
  if (url === '/api/telemetry' && req.method === 'POST') {
    let body = '';
    req.on('data', (chunk) => { body += chunk; });
    req.on('end', () => {
      try {
        const data = body ? JSON.parse(body) : {};
        const result = handleIngestTelemetry(data);
        res.statusCode = result.success ? 200 : 400;
        res.end(JSON.stringify(result));
      } catch (err) {
        res.statusCode = 400;
        res.end(JSON.stringify({ success: false, error: err.message }));
      }
    });
    return;
  }

  // GET /api/telemetry/latest
  if (url === '/api/telemetry/latest' && req.method === 'GET') {
    res.statusCode = 200;
    return res.end(JSON.stringify({
      telemetry: deviceState.latestTelemetry,
      lastPacket: deviceState.lastPacket,
      nodesOnline: deviceState.nodesOnline
    }));
  }

  return next();
}
