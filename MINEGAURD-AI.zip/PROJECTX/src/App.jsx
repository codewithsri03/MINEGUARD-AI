import React, { useEffect } from 'react';
import { Router, Route, useRouter } from './router/Router';
import { Navigation } from './components/Navigation';
import { HomePage } from './pages/HomePage';
import { MonitoringPage } from './command/pages/MonitoringPage';
import { RiskPage } from './command/pages/RiskPage';
import { SectionPage } from './command/pages/SectionPage';
import { AlertsPage } from './command/pages/AlertsPage';
import { NodesPage } from './command/pages/NodesPage';

/**
 * Redirect /digital-twin -> /section as specified in brief §1
 */
function RedirectToSection() {
  const { navigate } = useRouter();
  useEffect(() => {
    navigate('/section');
  }, [navigate]);
  return null;
}

function AppContent() {
  const { path } = useRouter();
  const isLanding = path === '/';

  return (
    <div className="app-root">
      {/* Floating Pill Nav is ONLY rendered on the public landing page */}
      {isLanding && <Navigation />}

      {/* Public Landing Page */}
      <Route path="/" element={<HomePage />} />

      {/* Command System Routes (No Three.js, Pure SVG + DOM) */}
      <Route path="/monitoring" element={<MonitoringPage />} />
      <Route path="/dashboard" element={<MonitoringPage />} />
      <Route path="/risk" element={<RiskPage />} />
      <Route path="/section" element={<SectionPage />} />
      <Route path="/digital-twin" element={<RedirectToSection />} />
      <Route path="/alerts" element={<AlertsPage />} />
      <Route path="/nodes" element={<NodesPage />} />
    </div>
  );
}

export function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
