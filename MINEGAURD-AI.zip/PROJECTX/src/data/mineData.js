import { useState, useEffect } from 'react';

/**
 * MINEGUARD CENTRAL SIMULATED DATA LAYER
 * Structured for direct future integration with real ESP32 telemetry hardware.
 */
export const INITIAL_NODES = [
  {
    id: 'N-01',
    name: 'Haulage Drift Entry',
    zone: 'ZONE-01',
    position: [-3.2, -0.6, -1.5],
    tilt: 0.42,
    distance: 18.4,
    riskScore: 22,
    status: 'NORMAL',
    lastUpdate: '2 sec ago'
  },
  {
    id: 'N-02',
    name: 'Portal Cross-Cut A',
    zone: 'ZONE-01',
    position: [-1.8, -0.6, -0.8],
    tilt: 0.31,
    distance: 19.1,
    riskScore: 18,
    status: 'NORMAL',
    lastUpdate: '2 sec ago'
  },
  {
    id: 'N-03',
    name: 'Central Junction B',
    zone: 'ZONE-02',
    position: [0.0, -0.6, -0.5],
    tilt: 0.56,
    distance: 18.2,
    riskScore: 34,
    status: 'NORMAL',
    lastUpdate: '1 sec ago'
  },
  {
    id: 'N-04',
    name: 'North Drift Heading',
    zone: 'ZONE-02',
    position: [1.8, 0.4, 0.8],
    tilt: 2.42,
    distance: 16.3,
    riskScore: 62,
    status: 'WARNING',
    lastUpdate: '2 sec ago'
  },
  {
    id: 'N-05',
    name: 'Ventilation Incline',
    zone: 'ZONE-04',
    position: [-2.4, 1.2, 1.2],
    tilt: 0.38,
    distance: 18.5,
    riskScore: 26,
    status: 'NORMAL',
    lastUpdate: '3 sec ago'
  },
  {
    id: 'N-06',
    name: 'South Access Gallery',
    zone: 'ZONE-03',
    position: [0.8, -1.2, -1.8],
    tilt: 0.41,
    distance: 18.9,
    riskScore: 29,
    status: 'NORMAL',
    lastUpdate: '1 sec ago'
  },
  {
    id: 'N-07',
    name: 'Sub-Level 4 Stope',
    zone: 'ZONE-03',
    position: [2.8, -1.0, 1.6],
    tilt: 3.15,
    distance: 14.8,
    riskScore: 76,
    status: 'CRITICAL',
    lastUpdate: 'Just now'
  },
  {
    id: 'N-08',
    name: 'Drainage Cross-Cut',
    zone: 'ZONE-04',
    position: [-0.6, -1.6, 2.0],
    tilt: 0.29,
    distance: 19.4,
    riskScore: 15,
    status: 'NORMAL',
    lastUpdate: '4 sec ago'
  }
];

export const MINE_ZONES = [
  {
    id: 'ZONE-01',
    name: 'Main Haulage',
    label: 'ZONE 01',
    fullName: 'ZONE 01 — MAIN HAULAGE',
    depth: '-320m',
    status: 'NORMAL',
    riskScore: 22,
    nodes: ['N-01', 'N-02'],
    center: [-2.5, -0.6, -1.0],
    lastUpdate: '2 sec ago'
  },
  {
    id: 'ZONE-02',
    name: 'North Drift',
    label: 'ZONE 02',
    fullName: 'ZONE 02 — NORTH DRIFT',
    depth: '-380m',
    status: 'WARNING',
    riskScore: 62,
    nodes: ['N-03', 'N-04'],
    center: [1.8, 0.4, 0.8],
    lastUpdate: '2 sec ago'
  },
  {
    id: 'ZONE-03',
    name: 'Sub-Level 4',
    label: 'ZONE 03',
    fullName: 'ZONE 03 — SUB-LEVEL 4',
    depth: '-460m',
    status: 'CRITICAL',
    riskScore: 78,
    nodes: ['N-06', 'N-07'],
    center: [2.6, -1.0, 1.6],
    lastUpdate: '2 sec ago'
  },
  {
    id: 'ZONE-04',
    name: 'Ventilation',
    label: 'ZONE 04',
    fullName: 'ZONE 04 — VENTILATION',
    depth: '-410m',
    status: 'NORMAL',
    riskScore: 24,
    nodes: ['N-05', 'N-08'],
    center: [-2.0, 0.8, 1.2],
    lastUpdate: '3 sec ago'
  }
];

export const INITIAL_ALERTS = [
  {
    id: 'ALT-109',
    nodeId: 'N-07',
    zoneId: 'ZONE-03',
    event: 'EXCESSIVE ROOF CONVERGENCE DETECTED',
    timestamp: '2 min ago',
    severity: 'CRITICAL',
    state: 'DISPATCHED'
  },
  {
    id: 'ALT-108',
    nodeId: 'N-04',
    zoneId: 'ZONE-02',
    event: 'ELEVATED TILT ANGLE (+2.42°)',
    timestamp: '4 min ago',
    severity: 'WARNING',
    state: 'ACKNOWLEDGED'
  },
  {
    id: 'ALT-107',
    nodeId: 'ZONE-02',
    zoneId: 'ZONE-02',
    event: 'RISK THRESHOLD APPROACHING',
    timestamp: '7 min ago',
    severity: 'WARNING',
    state: 'MONITORING'
  },
  {
    id: 'ALT-106',
    nodeId: 'N-02',
    zoneId: 'ZONE-01',
    event: 'ROUTINE SENSOR CALIBRATION',
    timestamp: '12 min ago',
    severity: 'NORMAL',
    state: 'MONITORING'
  }
];

export const INITIAL_TREND = [42, 44, 43, 47, 50, 49, 53, 56, 58, 62, 61, 62];

/**
 * Hook providing live simulated telemetry and overall operational states.
 */
export function useMineData() {
  const [nodes, setNodes] = useState(INITIAL_NODES);
  const [trendData, setTrendData] = useState(INITIAL_TREND);
  const [activeAlerts, setActiveAlerts] = useState(INITIAL_ALERTS);
  const [elapsedSeconds, setElapsedSeconds] = useState(1);
  const [selectedNodeId, setSelectedNodeId] = useState('N-04');
  const [selectedZoneId, setSelectedZoneId] = useState('ZONE-03');

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => (prev % 59) + 1);

      setNodes((prevNodes) =>
        prevNodes.map((node) => {
          const tiltDrift = (Math.random() - 0.5) * 0.02;
          const distDrift = (Math.random() - 0.5) * 0.05;
          const newTilt = parseFloat((node.tilt + tiltDrift).toFixed(2));
          const newDist = parseFloat((node.distance + distDrift).toFixed(1));

          return {
            ...node,
            tilt: Math.max(0.1, newTilt),
            distance: Math.max(10, newDist)
          };
        })
      );
    }, 2500);

    return () => clearInterval(timer);
  }, []);

  // KPI calculations matching specification
  const kpis = {
    monitoredNodes: '08',
    activeZones: '04',
    warningZones: '01',
    criticalZones: '01'
  };

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[3];
  const selectedZone = MINE_ZONES.find((z) => z.id === selectedZoneId) || MINE_ZONES[2];

  return {
    nodes,
    zones: MINE_ZONES,
    activeAlerts,
    trendData,
    elapsedSeconds,
    overallRisk: 62,
    overallStatus: 'WARNING',
    kpis,
    selectedNodeId,
    setSelectedNodeId,
    selectedNode,
    selectedZoneId,
    setSelectedZoneId,
    selectedZone
  };
}
