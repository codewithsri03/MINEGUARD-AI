import React, { useRef } from 'react';
import { Hero } from '../components/Hero';
import { EnvironmentOverlay } from '../components/EnvironmentOverlay';
import { ParticleScene } from '../scenes/ParticleScene';
import { useRouter } from '../router/Router';

/**
 * MINEGUARD AI CONTINUOUS SCROLL ARCHITECTURE
 * 01 — HOME (#home) [LOCKED BASELINE]
 * 02 — LIVE MONITORING (#monitoring)
 * 03 — RISK ANALYSIS (#risk-analysis)
 * 04 — DIGITAL TWIN (#digital-twin)
 * 05 — ALERTS (#alerts)
 * 06 — SENSOR NODES (#nodes)
 */
export function HomePage() {
  const heroRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const { navigate } = useRouter();

  return (
    <>
      {/* SECTION 01: HOME (#home) - FIXED WEBGL PARTICLE FIELD [LOCKED BASELINE] */}
      <ParticleScene heroRef={heroRef} scrollContainerRef={scrollContainerRef} />

      {/* Atmospheric Overlays (Vignette, Noise Grain, Scroll Indicator) */}
      <EnvironmentOverlay />

      {/* Home 400vh Scroll Runway */}
      <main className="scroll-container" id="home" ref={scrollContainerRef}>
        <Hero ref={heroRef} />
      </main>

      {/* SECTION 02: LIVE MONITORING (#monitoring) */}
      <section className="mg-scroll-section" id="monitoring" aria-label="Live Monitoring">
        <div className="mg-scroll-section-content">
          <div className="hero-badge">
            <span className="badge-dot" aria-hidden="true" />
            <span>02 — Live Monitoring</span>
          </div>

          <h2 className="mg-scroll-section-title">
            REAL-TIME TELEMETRY WAVEFORMS
          </h2>

          <p className="mg-scroll-section-desc">
            Continuous multi-channel sensor feeds streaming tilt angle (degrees) and roof convergence (centimetres)
            at 1 Hz across all active subterranean excavation headings.
          </p>

          <div className="mg-scroll-section-actions">
            <button onClick={() => navigate('/monitoring')} className="btn btn-primary">
              <span>Open Telemetry Bank</span>
              <svg className="btn-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 03: RISK ANALYSIS (#risk-analysis) */}
      <section className="mg-scroll-section" id="risk-analysis" aria-label="Risk Analysis">
        <div className="mg-scroll-section-content">
          <div className="hero-badge">
            <span className="badge-dot" aria-hidden="true" />
            <span>03 — Risk Analysis</span>
          </div>

          <h2 className="mg-scroll-section-title">
            AI-POWERED SUBSIDENCE INTELLIGENCE
          </h2>

          <p className="mg-scroll-section-desc">
            Multi-variable Bayesian fusion decomposing convergence velocity, angular shear acceleration,
            and geological baseline weights into calibrated rockfall probability indices.
          </p>

          <div className="mg-scroll-section-actions">
            <button onClick={() => navigate('/risk')} className="btn btn-primary">
              <span>Inspect Risk Model</span>
              <svg className="btn-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 04: DIGITAL TWIN (#digital-twin) */}
      <section className="mg-scroll-section" id="digital-twin" aria-label="Digital Twin">
        <div className="mg-scroll-section-content">
          <div className="hero-badge">
            <span className="badge-dot" aria-hidden="true" />
            <span>04 — Digital Twin</span>
          </div>

          <h2 className="mg-scroll-section-title">
            SUBTERRANEAN MINE CROSS-SECTION
          </h2>

          <p className="mg-scroll-section-desc">
            Hand-drawn side-elevation cross-section from surface (0 m) to deep rock (−500 m).
            Visualises live roof sag deflection, tilt vector needles, and subterranean LoRa mesh packet flow.
          </p>

          <div className="mg-scroll-section-actions">
            <button onClick={() => navigate('/section')} className="btn btn-primary">
              <span>View Mine Section</span>
              <svg className="btn-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 05: ALERTS (#alerts) */}
      <section className="mg-scroll-section" id="alerts" aria-label="Alerts">
        <div className="mg-scroll-section-content">
          <div className="hero-badge">
            <span className="badge-dot" aria-hidden="true" />
            <span>05 — Alerts</span>
          </div>

          <h2 className="mg-scroll-section-title">
            INCIDENT TRIAGE & ESCALATION PROTOCOLS
          </h2>

          <p className="mg-scroll-section-desc">
            Autonomous threshold breach detection with sub-minute mean time to acknowledge,
            paging dispatches, and immutable chronological audit trails.
          </p>

          <div className="mg-scroll-section-actions">
            <button onClick={() => navigate('/alerts')} className="btn btn-primary">
              <span>Open Alert Dispatch</span>
              <svg className="btn-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* SECTION 06: SENSOR NODES (#nodes) */}
      <section className="mg-scroll-section" id="nodes" aria-label="Sensor Nodes">
        <div className="mg-scroll-section-content">
          <div className="hero-badge">
            <span className="badge-dot" aria-hidden="true" />
            <span>06 — Sensor Nodes</span>
          </div>

          <h2 className="mg-scroll-section-title">
            ESP32 + LORA HARDWARE MESH FLEET
          </h2>

          <p className="mg-scroll-section-desc">
            Autonomous battery management, RF link quality diagnostics, and remote calibration
            for wireless sensor nodes mounted directly on active roof bolts and pillar faces.
          </p>

          <div className="mg-scroll-section-actions">
            <button onClick={() => navigate('/nodes')} className="btn btn-primary">
              <span>Manage Sensor Fleet</span>
              <svg className="btn-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </button>
          </div>
        </div>
      </section>
    </>
  );
}

export default HomePage;
