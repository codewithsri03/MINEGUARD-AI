import * as THREE from 'three';

/**
 * Generates the geometry for the 150k particle system with two morph states,
 * custom colors, sizes, and random variations.
 * 
 * @param {number} count Particle count (default 150,000)
 * @returns {THREE.BufferGeometry}
 */
export function createParticleGeometry(count = 150000) {
  const geometry = new THREE.BufferGeometry();

  const posA = new Float32Array(count * 3);
  const posB = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  const randoms = new Float32Array(count);

  // Reference Palette
  const colorBlue = new THREE.Color(0x2B58FF);    // Deep electric blue
  const colorCyan = new THREE.Color(0x4FD8FF);    // Luminous cyan
  const colorOrange = new THREE.Color(0xFF5A2B);  // Luminous warm orange
  const colorMagenta = new THREE.Color(0x9B2BFF); // Electric violet/magenta
  const colorWhite = new THREE.Color(0xFFFFFF);   // High-energy white cores

  const c = new THREE.Color();

  for (let i = 0; i < count; i++) {
    const i3 = i * 3;

    // --- State A: The Reference Vortex / Intersecting Rings ---
    // Twisted torus knot distribution matching the reference shape
    const u = Math.random() * Math.PI * 2;
    const v = Math.random() * Math.PI * 2;
    const radius = 4.5;
    const tube = 1.8 * Math.random(); // soft inner volume

    // Core shape offset with procedural look
    let x = (radius + tube * Math.cos(v)) * Math.cos(u);
    let y = (radius + tube * Math.cos(v)) * Math.sin(u);
    let z = tube * Math.sin(v) * 2.0;

    // Twist and distort to match the sweeping diagonal composition of the reference
    const twist = u * 0.5;
    const tx = x * Math.cos(twist) - z * Math.sin(twist);
    const tz = x * Math.sin(twist) + z * Math.cos(twist);
    x = tx;
    z = tz;

    // Flatten and angle
    y *= 0.6;

    posA[i3] = x;
    posA[i3 + 1] = y;
    posA[i3 + 2] = z;

    // --- State B: Expanded Organic Flow ---
    const spread = 15.0;
    posB[i3] = (Math.random() - 0.5) * spread;
    posB[i3 + 1] = (Math.random() - 0.5) * spread;
    posB[i3 + 2] = (Math.random() - 0.5) * spread;

    // --- Colors matching reference ---
    // The reference has orange on the top right, blue on the bottom left.
    if (x > 0 && y > -1) {
      c.copy(colorOrange).lerp(colorMagenta, Math.random() * 0.4);
    } else {
      c.copy(colorBlue).lerp(colorCyan, Math.random() * 0.5);
    }

    // Add bright energy particles randomly
    if (Math.random() > 0.95) {
      c.lerp(colorWhite, 0.8);
    }

    colors[i3] = c.r;
    colors[i3 + 1] = c.g;
    colors[i3 + 2] = c.b;

    // Base size variation (very fine)
    sizes[i] = Math.random() * 0.8 + 0.2;
    randoms[i] = Math.random();
  }

  geometry.setAttribute('position', new THREE.BufferAttribute(posA, 3));
  geometry.setAttribute('posB', new THREE.BufferAttribute(posB, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
  geometry.setAttribute('aRandom', new THREE.BufferAttribute(randoms, 1));

  return geometry;
}
