import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { particleVertexShader } from '../shaders/particleVertex';
import { particleFragmentShader } from '../shaders/particleFragment';
import { createParticleGeometry } from '../utils/particleGenerator';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

/**
 * ParticleScene renders the WebGL 150k particle field and coordinates
 * mouse parallax and the GSAP scroll-driven morph timeline.
 */
export function ParticleScene({ heroRef, scrollContainerRef }) {
  const containerRef = useRef(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // --- Responsive particle sizing ---
    const isMobile = window.innerWidth < 768;
    const particleCount = isMobile ? 80000 : 150000;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);

    // --- WebGL Renderer ---
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true
    });
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x020204, 1);
    container.appendChild(renderer.domElement);

    // --- Scene & Camera ---
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      45,
      window.innerWidth / window.innerHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 12);

    // --- Particle System ---
    const geometry = createParticleGeometry(particleCount);
    const material = new THREE.ShaderMaterial({
      vertexShader: particleVertexShader,
      fragmentShader: particleFragmentShader,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexColors: true,
      uniforms: {
        uTime: { value: 0 },
        uMorph: { value: 0 },
        uPixelRatio: { value: pixelRatio },
        uDirectionalFlow: { value: 0 },
        uConcentration: { value: 0 },
        uTurbulence: { value: 0 },
        uNetworkDrift: { value: 0 }
      }
    });

    const particles = new THREE.Points(geometry, material);
    // Initial framing rotation to match reference angle
    particles.rotation.x = 0.3;
    particles.rotation.y = 0.1;
    scene.add(particles);

    // --- Mouse & Touch Parallax Interaction ---
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const onMouseMove = (e) => {
      targetX = (e.clientX / window.innerWidth - 0.5) * 2;
      targetY = -(e.clientY / window.innerHeight - 0.5) * 2;
    };

    const onTouchMove = (e) => {
      if (e.touches.length > 0) {
        targetX = (e.touches[0].clientX / window.innerWidth - 0.5) * 2;
        targetY = -(e.touches[0].clientY / window.innerHeight - 0.5) * 2;
      }
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });

    // --- Window Resize Handling ---
    const onResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      material.uniforms.uPixelRatio.value = Math.min(window.devicePixelRatio || 1, 2);
    };

    window.addEventListener('resize', onResize);

    // --- Animation Loop ---
    const clock = new THREE.Clock();
    let animationFrameId = null;
    let isTabActive = true;

    const onVisibilityChange = () => {
      isTabActive = document.visibilityState === 'visible';
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (!isTabActive) return;

      const elapsedTime = clock.getElapsedTime();
      material.uniforms.uTime.value = elapsedTime;

      // Continuous slow organic rotation
      particles.rotation.y += 0.001;
      particles.rotation.z += 0.0005;

      // Smooth camera parallax interpolation
      mouseX += (targetX - mouseX) * 0.05;
      mouseY += (targetY - mouseY) * 0.05;

      camera.position.x += (mouseX * 1.5 - camera.position.x) * 0.05;
      camera.position.y += (mouseY * 1.5 - camera.position.y) * 0.05;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    // --- GSAP ScrollTrigger Cinematic Timelines ---
    const scrollContainer = scrollContainerRef?.current || document.querySelector('.scroll-container');
    const heroElement = heroRef?.current || document.getElementById('hero-block');

    const createdTriggers = [];

    // 1. Home 400vh Runway Timeline (Unchanged Baseline)
    const homeTimeline = gsap.timeline({
      scrollTrigger: {
        trigger: scrollContainer,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 1.5
      }
    });

    // Morph particles from torus knot to expanded cosmic flow
    homeTimeline.to(material.uniforms.uMorph, {
      value: 1.0,
      ease: 'power2.inOut',
      duration: 1
    }, 0);

    // Cinematic Camera Push
    homeTimeline.to(camera.position, {
      z: 5.6,
      ease: 'power1.inOut',
      duration: 1
    }, 0);

    // Hero typography upward translation & fade
    if (heroElement) {
      homeTimeline.to(heroElement, {
        opacity: 0,
        y: -110,
        scale: 0.94,
        ease: 'power1.inOut',
        duration: 0.45
      }, 0);
    }

    // Fade out scroll prompt promptly
    homeTimeline.to('#scroll-prompt', {
      opacity: 0,
      ease: 'power1.out',
      duration: 0.15
    }, 0);

    if (homeTimeline.scrollTrigger) {
      createdTriggers.push(homeTimeline.scrollTrigger);
    }

    // 2. Section 02: Live Monitoring (#monitoring)
    const monitoringEl = document.getElementById('monitoring');
    if (monitoringEl) {
      const st = ScrollTrigger.create({
        trigger: monitoringEl,
        start: 'top 85%',
        end: 'bottom 15%',
        scrub: 1.2,
        onUpdate: (self) => {
          const factor = Math.sin(self.progress * Math.PI);
          material.uniforms.uDirectionalFlow.value = factor;
        }
      });
      createdTriggers.push(st);
    }

    // 3. Section 03: Risk Analysis (#risk-analysis)
    const riskEl = document.getElementById('risk-analysis');
    if (riskEl) {
      const st = ScrollTrigger.create({
        trigger: riskEl,
        start: 'top 85%',
        end: 'bottom 15%',
        scrub: 1.2,
        onUpdate: (self) => {
          const factor = Math.sin(self.progress * Math.PI);
          material.uniforms.uConcentration.value = factor;
        }
      });
      createdTriggers.push(st);
    }

    // 4. Section 04: Digital Twin (#digital-twin)
    const dtEl = document.getElementById('digital-twin');
    if (dtEl) {
      const st = ScrollTrigger.create({
        trigger: dtEl,
        start: 'top 85%',
        end: 'bottom 15%',
        scrub: 1.2,
        onUpdate: (self) => {
          const factor = Math.sin(self.progress * Math.PI);
          camera.position.z = 5.6 + factor * 1.6; // Deeper spatial depth
        }
      });
      createdTriggers.push(st);
    }

    // 5. Section 05: Alerts (#alerts)
    const alertsEl = document.getElementById('alerts');
    if (alertsEl) {
      const st = ScrollTrigger.create({
        trigger: alertsEl,
        start: 'top 85%',
        end: 'bottom 15%',
        scrub: 1.2,
        onUpdate: (self) => {
          const factor = Math.sin(self.progress * Math.PI);
          material.uniforms.uTurbulence.value = factor;
        }
      });
      createdTriggers.push(st);
    }

    // 6. Section 06: Sensor Nodes (#nodes)
    const nodesEl = document.getElementById('nodes');
    if (nodesEl) {
      const st = ScrollTrigger.create({
        trigger: nodesEl,
        start: 'top 85%',
        end: 'bottom 15%',
        scrub: 1.2,
        onUpdate: (self) => {
          const factor = Math.sin(self.progress * Math.PI);
          material.uniforms.uNetworkDrift.value = factor;
        }
      });
      createdTriggers.push(st);
    }

    // --- Cleanup Lifecycle ---
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibilityChange);

      createdTriggers.forEach((st) => st.kill());
      homeTimeline.kill();

      scene.remove(particles);
      geometry.dispose();
      material.dispose();
      renderer.dispose();

      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
  }, [heroRef, scrollContainerRef]);

  return <div className="canvas-container" ref={containerRef} aria-hidden="true" />;
}
