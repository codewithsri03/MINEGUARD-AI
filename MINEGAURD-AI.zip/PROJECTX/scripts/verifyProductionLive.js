import WebSocket from 'ws';

const PROD_API_URL = 'https://present-ink-soldiers-parts.trycloudflare.com';
const PROD_WS_URL = 'wss://present-ink-soldiers-parts.trycloudflare.com/ws';
const VERCEL_FRONTEND = 'https://mineguard-ai-ten.vercel.app';

console.log('================================================================');
console.log(' MineGuard AI — Production Demo Telemetry Connection Suite');
console.log(' Production Frontend:', VERCEL_FRONTEND);
console.log(' Production Backend: ', PROD_API_URL);
console.log(' Production WS Stream:', PROD_WS_URL);
console.log('================================================================\n');

async function runVerification() {
  let passed = 0;
  let total = 10;

  // 1. Health check & CORS
  console.log('1. Verifying Production Backend Health & CORS...');
  const healthRes = await fetch(`${PROD_API_URL}/api/health`, {
    headers: { Origin: VERCEL_FRONTEND }
  });
  if (healthRes.status !== 200) throw new Error(`Health returned ${healthRes.status}`);
  const corsHeader = healthRes.headers.get('access-control-allow-origin');
  const healthData = await healthRes.json();
  console.log(`✅ PASS: Backend returned HTTP 200 OK (${healthData.service})`);
  console.log(`✅ PASS: CORS allows Vercel origin (${corsHeader})`);
  passed++;

  // 2. Device status & Hardware Safety
  console.log('\n2. Verifying Device Status & Hardware Safety Isolation...');
  const devRes = await fetch(`${PROD_API_URL}/api/devices/status`, {
    headers: { Origin: VERCEL_FRONTEND }
  });
  const devStatus = await devRes.json();
  if (devStatus.connected !== false) throw new Error('ESP32 connected must be FALSE during simulation');
  if (devStatus.latestSource !== 'simulator') throw new Error(`Source must be simulator, got ${devStatus.latestSource}`);
  if (!devStatus.simulatorActive) throw new Error('simulatorActive must be TRUE');
  console.log('✅ PASS: ESP32 connection state is strictly FALSE (Hardware Safety preserved)');
  console.log('✅ PASS: Reporting source is explicitly "simulator"');
  console.log('✅ PASS: Simulator active flag is TRUE');
  passed++;

  // 3. Node Fleet Status
  console.log('\n3. Verifying Node Fleet Status...');
  if (devStatus.nodesCount !== 8) throw new Error(`Expected 8 nodes, got ${devStatus.nodesCount}`);
  console.log(`✅ PASS: Node fleet initialized with all ${devStatus.nodesCount} canonical stations`);
  passed++;

  // 4. Latest Telemetry
  console.log('\n4. Verifying Latest Telemetry Retrieval...');
  const telRes = await fetch(`${PROD_API_URL}/api/telemetry/latest?nodeId=N-01`, {
    headers: { Origin: VERCEL_FRONTEND }
  });
  const telData = await telRes.json();
  if (!telData.success || !telData.data) throw new Error('Failed to retrieve latest telemetry');
  console.log(`✅ PASS: Station N-01 telemetry retrieved: Temp: ${telData.data.temperature}°C, Distance: ${telData.data.distance}cm`);
  passed++;

  // 5. Dashboard Summary
  console.log('\n5. Verifying Consolidated Dashboard Summary...');
  const dashRes = await fetch(`${PROD_API_URL}/api/dashboard/summary`, {
    headers: { Origin: VERCEL_FRONTEND }
  });
  const dashData = await dashRes.json();
  const summaryObj = dashData.summary || dashData;
  if (!summaryObj.totalNodes) throw new Error('Dashboard summary missing totalNodes');
  console.log(`✅ PASS: Dashboard summary: Total Nodes ${summaryObj.totalNodes}, Mine Status: ${summaryObj.overallMineStatus}`);
  passed++;

  // 6. Risk Engine
  console.log('\n6. Verifying Backend Geotechnical Risk Engine...');
  const riskRes = await fetch(`${PROD_API_URL}/api/risk`, {
    headers: { Origin: VERCEL_FRONTEND }
  });
  const riskData = await riskRes.json();
  const riskObj = riskData.data || riskData;
  if (!riskObj.nodes) throw new Error('Risk response missing nodes');
  console.log(`✅ PASS: Risk evaluation active: ${riskObj.criticalStations?.length || 0} critical, ${riskObj.warningStations?.length || 0} warning stations`);
  passed++;

  // 7. Alert Engine
  console.log('\n7. Verifying Alert Engine Breaches...');
  const alertRes = await fetch(`${PROD_API_URL}/api/alerts`, {
    headers: { Origin: VERCEL_FRONTEND }
  });
  const alertData = await alertRes.json();
  console.log(`✅ PASS: Alert engine active: ${alertData.length} alerts in log`);
  passed++;

  // 8. WebSocket Connection & Stream Ingestion
  console.log('\n8. Verifying Production WebSocket Stream (WSS)...');
  const wsPackets = [];
  const ws = new WebSocket(PROD_WS_URL, {
    headers: { Origin: VERCEL_FRONTEND }
  });

  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      ws.close();
      if (wsPackets.length >= 3) resolve();
      else reject(new Error(`WebSocket stream timed out. Received ${wsPackets.length} packets.`));
    }, 10000);

    ws.on('open', () => {
      console.log('✅ PASS: WebSocket handshake connected successfully over WSS');
    });

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'telemetry') {
          wsPackets.push(msg.data);
        }
      } catch (e) {}
      if (wsPackets.length >= 4) {
        clearTimeout(timeout);
        ws.close();
        resolve();
      }
    });

    ws.on('error', (err) => {
      clearTimeout(timeout);
      reject(err);
    });
  });

  console.log(`✅ PASS: Received ${wsPackets.length} telemetry packets over WebSocket`);
  passed++;

  // 9. Hardware Channels Verification
  console.log('\n9. Verifying All Hardware Channels in Telemetry Stream...');
  const distances = new Set();
  const temps = new Set();
  const hums = new Set();
  const pressures = new Set();
  const gases = new Set();
  const rains = new Set();
  const tilts = new Set();

  wsPackets.forEach(p => {
    if (p.distance != null) distances.add(p.distance);
    if (p.temperature != null) temps.add(p.temperature);
    if (p.humidity != null) hums.add(p.humidity);
    if (p.pressure != null) pressures.add(p.pressure);
    if (p.gasAdc != null) gases.add(p.gasAdc);
    if (p.rainAdc != null) rains.add(p.rainAdc);
    if (p.tilt != null) tilts.add(p.tilt);
  });

  console.log(`   - HC-SR04 distances:  [${Array.from(distances).join(', ')}] cm`);
  console.log(`   - Temperatures:       [${Array.from(temps).join(', ')}] °C`);
  console.log(`   - Humidity:           [${Array.from(hums).join(', ')}] %`);
  console.log(`   - Pressure:           [${Array.from(pressures).join(', ')}] hPa`);
  console.log(`   - Gas:                [${Array.from(gases).join(', ')}] ADC`);
  console.log(`   - Rain:               [${Array.from(rains).join(', ')}] ADC`);
  console.log(`   - MPU9250 Tilt:       [${Array.from(tilts).join(', ')}] °`);

  if (distances.size < 2 || temps.size < 2 || gases.size < 2) {
    throw new Error('Telemetry channels are static; expected naturally varying values');
  }
  console.log('✅ PASS: All hardware sensor channels producing changing values');
  passed++;

  // 10. Vercel Production Asset Verification
  console.log('\n10. Verifying Vercel Production HTML & JS Delivery...');
  const vercelHtmlRes = await fetch(VERCEL_FRONTEND);
  const vercelHtml = await vercelHtmlRes.text();
  if (!vercelHtml.includes('MineGuard AI')) {
    throw new Error('Vercel homepage HTML does not include expected title');
  }
  console.log('✅ PASS: Vercel production frontend is LIVE and serving correctly');
  passed++;

  console.log('\n================================================================');
  console.log(`🎉 ALL ${passed}/${total} PRODUCTION CONNECTION CHECKS PASSED!`);
  console.log('================================================================');
}

runVerification().catch(err => {
  console.error('\n❌ VERIFICATION FAILED:', err);
  process.exit(1);
});
