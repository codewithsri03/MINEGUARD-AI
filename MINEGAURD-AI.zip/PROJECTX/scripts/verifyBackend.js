import { WebSocket } from 'ws';

/**
 * MineGuard AI — Full 16-Point Automated Backend Verification Suite
 *
 * Checks:
 * 1.  Health endpoint (GET /api/health)
 * 2.  Device status endpoint (GET /api/devices/status)
 * 3.  Telemetry ingestion (POST /api/telemetry)
 * 4.  Latest telemetry retrieval (GET /api/telemetry/latest)
 * 5.  Multi-node tracking (N-01, N-07, etc.)
 * 6.  Historical storage in SQLite (GET /api/telemetry/history/:nodeId)
 * 7.  Geotechnical risk calculation (NORMAL, WARNING, CRITICAL)
 * 8.  Alert generation from threshold breach
 * 9.  Alert acknowledgement (PATCH /api/alerts/:alertId/acknowledge)
 * 10. Dashboard summary (GET /api/dashboard/summary)
 * 11. Risk API (GET /api/risk & GET /api/risk/:nodeId)
 * 12. Digital Twin API (GET /api/digital-twin/nodes)
 * 13. WebSocket telemetry stream
 * 14. WebSocket risk event stream
 * 15. WebSocket alert event stream
 * 16. Simulator vs hardware distinction
 */

const BASE_URL = process.env.TEST_URL || 'http://localhost:3001';
const WS_URL = process.env.TEST_WS_URL || 'ws://localhost:3001/ws';

async function runCompleteVerification() {
  console.log('================================================================');
  console.log('  MineGuard AI — Full 16-Point Backend Verification Suite');
  console.log(`  HTTP Target: ${BASE_URL}`);
  console.log(`  WS Target:   ${WS_URL}`);
  console.log('================================================================\n');

  let passedSteps = 0;
  const totalSteps = 16;
  const wsMessages = [];
  let ws = null;

  // ----------------------------------------------------
  // Check 1: Health endpoint
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/health`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (data.status !== 'ok' || data.service !== 'mineguard-backend') {
      throw new Error(`Unexpected health payload: ${JSON.stringify(data)}`);
    }
    console.log('[PASS] Check 1: Health endpoint works (GET /api/health)');
    console.log(`       status: "${data.status}", service: "${data.service}"\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 1: Health endpoint failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Connect WebSocket early to capture all event broadcasts
  // ----------------------------------------------------
  try {
    ws = new WebSocket(WS_URL);
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('WebSocket timed out')), 3000);
      ws.on('open', () => {
        clearTimeout(timeout);
        resolve();
      });
      ws.on('error', (err) => {
        clearTimeout(timeout);
        reject(err);
      });
    });

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        wsMessages.push(msg);
      } catch {
        // ignore
      }
    });

    // Wait for initial device_status
    await new Promise((r) => setTimeout(r, 300));
  } catch (err) {
    console.error('[FAIL] WebSocket connection failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 2: Device status endpoint works
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/devices/status`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const status = await res.json();
    if (typeof status.connected !== 'boolean' || !Array.isArray(status.nodes)) {
      throw new Error(`Invalid device status shape: ${JSON.stringify(status)}`);
    }
    console.log('[PASS] Check 2: Device status endpoint works (GET /api/devices/status)');
    console.log(`       connected=${status.connected}, nodesOnline=${status.nodesOnline}, totalNodes=${status.totalNodes}\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 2: Device status endpoint failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 3: Telemetry Ingestion (Node N-01 Nominal)
  // ----------------------------------------------------
  const packetN01 = {
    nodeId: 'N-01',
    timestamp: new Date().toISOString(),
    temperature: 23.4,
    humidity: 68.2,
    pressure: 1013.8,
    distance: 18.4,
    gasAdc: 1840,
    rainAdc: 150,
    imu: { x: 0.01, y: 0.01, z: 0.99 },
    source: 'hardware'
  };

  try {
    const res = await fetch(`${BASE_URL}/api/telemetry`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(packetN01)
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (!data.success || data.nodeId !== 'N-01') {
      throw new Error(`Unexpected response: ${JSON.stringify(data)}`);
    }
    console.log('[PASS] Check 3: Telemetry ingestion works (POST /api/telemetry for N-01)');
    console.log(`       Ingested N-01 [HARDWARE] (receivedAt: ${data.receivedAt})\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 3: Telemetry ingestion failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 4: Latest Telemetry retrieval
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/telemetry/latest?nodeId=N-01`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const packet = data.telemetry || data.data;
    if (!packet || packet.nodeId !== 'N-01' || packet.temperature !== 23.4) {
      throw new Error(`Packet mismatch: ${JSON.stringify(data)}`);
    }
    console.log('[PASS] Check 4: Latest telemetry retrieval works (GET /api/telemetry/latest?nodeId=N-01)');
    console.log(`       N-01 Temp: ${packet.temperature}°C, Distance: ${packet.distance}cm\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 4: Latest telemetry retrieval failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 5: Multi-node tracking (Ingest N-07 Critical)
  // ----------------------------------------------------
  const packetN07 = {
    nodeId: 'N-07',
    timestamp: new Date().toISOString(),
    temperature: 27.2,
    humidity: 78.9,
    pressure: 1010.3,
    distance: 14.0, // Roof compression breach (<15cm)
    gasAdc: 2321,   // Elevated gas (>2200)
    rainAdc: 208,
    imu: { x: 0.02, y: 0.03, z: 0.98 },
    isSimulated: true,
    source: 'simulator'
  };

  try {
    const res = await fetch(`${BASE_URL}/api/telemetry`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(packetN07)
    });
    const postData = await res.json();
    if (!postData.success) throw new Error(`POST failed for N-07: ${JSON.stringify(postData)}`);

    // Verify both N-01 and N-07 are registered
    const node1Res = await fetch(`${BASE_URL}/api/devices/N-01`);
    const node7Res = await fetch(`${BASE_URL}/api/devices/N-07`);
    const n1 = (await node1Res.json()).node;
    const n7 = (await node7Res.json()).node;

    if (!n1 || !n7 || n1.nodeId !== 'N-01' || n7.nodeId !== 'N-07') {
      throw new Error(`Multi-node registry failure. N-01: ${!!n1}, N-07: ${!!n7}`);
    }

    console.log('[PASS] Check 5: Multi-node tracking works (N-01 & N-07 active)');
    console.log(`       N-01: "${n1.name}" (${n1.zoneName}), N-07: "${n7.name}" (${n7.zoneName})\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 5: Multi-node tracking failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 6: Historical storage in SQLite
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/telemetry/history/N-07?limit=10`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (!data.success || !Array.isArray(data.history) || data.history.length === 0) {
      throw new Error(`History empty for N-07: ${JSON.stringify(data)}`);
    }

    const latest = data.history[0];
    if (latest.distance !== 14.0 || latest.gasAdc !== 2321) {
      throw new Error(`Data mismatch in SQLite history: ${JSON.stringify(latest)}`);
    }

    console.log('[PASS] Check 6: Historical storage in SQLite works (GET /api/telemetry/history/N-07)');
    console.log(`       Stored points: ${data.count}, Latest raw distance: ${latest.distance}cm, Gas: ${latest.gasAdc} ADC\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 6: SQLite historical storage failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 7: Geotechnical Risk Calculation
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/risk/N-07`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const risk = await res.json();

    if (risk.status !== 'CRITICAL' || risk.riskScore < 70 || risk.factors.length === 0) {
      throw new Error(`Unexpected risk calculation for N-07: ${JSON.stringify(risk)}`);
    }

    console.log('[PASS] Check 7: Geotechnical risk calculation works');
    console.log(`       N-07 Status: ${risk.status}, RiskScore: ${risk.riskScore}/100, Breached Factors: ${risk.factors.length}\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 7: Risk calculation failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 8: Alert Generation from threshold breach
  // ----------------------------------------------------
  let generatedAlertId = null;
  try {
    const res = await fetch(`${BASE_URL}/api/alerts?nodeId=N-07&severity=CRITICAL`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (!data.success || !Array.isArray(data.alerts) || data.alerts.length === 0) {
      throw new Error(`No alerts found for N-07: ${JSON.stringify(data)}`);
    }

    const alert = data.alerts[0];
    generatedAlertId = alert.id;

    if (alert.severity !== 'CRITICAL' || alert.type !== 'ROOF_CONVERGENCE_BREACH') {
      throw new Error(`Alert attributes mismatch: ${JSON.stringify(alert)}`);
    }

    console.log('[PASS] Check 8: Alert generation works from threshold breach');
    console.log(`       Alert ID: "${alert.id}", Type: "${alert.type}", Message: "${alert.message}"\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 8: Alert generation failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 9: Alert Acknowledgement (PATCH /api/alerts/:alertId/acknowledge)
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/alerts/${generatedAlertId}/acknowledge`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ actor: 'Lead Geotechnical Engineer' })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (!data.success || !data.alert?.acknowledged || data.alert.acknowledgedBy !== 'Lead Geotechnical Engineer') {
      throw new Error(`Alert acknowledgement mismatch: ${JSON.stringify(data)}`);
    }

    console.log('[PASS] Check 9: Alert acknowledgement works (PATCH /api/alerts/:alertId/acknowledge)');
    console.log(`       Acknowledged by: "${data.alert.acknowledgedBy}" at ${data.alert.acknowledgedAt}\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 9: Alert acknowledgement failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 10: Dashboard Summary API
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/dashboard/summary`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const summary = data.summary;

    if (!summary || typeof summary.totalNodes !== 'number' || typeof summary.overallRiskScore !== 'number') {
      throw new Error(`Invalid dashboard summary: ${JSON.stringify(data)}`);
    }

    console.log('[PASS] Check 10: Dashboard summary API works (GET /api/dashboard/summary)');
    console.log(`       Total Nodes: ${summary.totalNodes}, Online: ${summary.onlineNodes}, Mine Status: ${summary.overallMineStatus}, Mine Risk: ${summary.overallRiskScore}\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 10: Dashboard summary failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 11: Risk API (GET /api/risk)
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/risk`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (!data.success || !data.mineRisk || !Array.isArray(data.nodes)) {
      throw new Error(`Invalid risk API response: ${JSON.stringify(data)}`);
    }

    console.log('[PASS] Check 11: Risk API works (GET /api/risk)');
    console.log(`       Mine Status: ${data.mineRisk.overallStatus}, Critical Stations: [${data.mineRisk.criticalNodes.join(', ')}]\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 11: Risk API failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 12: Digital Twin API (GET /api/digital-twin/nodes)
  // ----------------------------------------------------
  try {
    const res = await fetch(`${BASE_URL}/api/digital-twin/nodes`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    if (!data.success || !Array.isArray(data.nodes) || data.nodes.length === 0) {
      throw new Error(`Invalid digital twin response: ${JSON.stringify(data)}`);
    }

    const dtNode = data.nodes.find((n) => n.nodeId === 'N-07');
    if (!dtNode || !dtNode.coords || typeof dtNode.depth !== 'number') {
      throw new Error(`Missing digital twin metadata for N-07: ${JSON.stringify(dtNode)}`);
    }

    console.log('[PASS] Check 12: Digital Twin API works (GET /api/digital-twin/nodes)');
    console.log(`       N-07 Depth: ${dtNode.depth}m, 2D Coords: (${dtNode.coords.x}, ${dtNode.coords.y}), Risk: ${dtNode.riskStatus}\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 12: Digital Twin API failed:', err.message);
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 13, 14, 15: WebSocket Event Streams
  // ----------------------------------------------------
  try {
    // Wait brief moment for any pending socket events
    await new Promise((r) => setTimeout(r, 400));

    const telemetryEvent = wsMessages.find((m) => m.type === 'telemetry' && m.data?.nodeId === 'N-07');
    const riskEvent = wsMessages.find((m) => m.type === 'risk' && m.data?.nodeId === 'N-07');
    const alertEvent = wsMessages.find((m) => m.type === 'alert' && m.data?.nodeId === 'N-07');

    if (!telemetryEvent) throw new Error('Missing WebSocket "telemetry" event');
    console.log('[PASS] Check 13: WebSocket telemetry stream works (type: "telemetry")');
    console.log(`       Node: ${telemetryEvent.data.nodeId}, Temp: ${telemetryEvent.data.temperature}°C, Distance: ${telemetryEvent.data.distance}cm\n`);
    passedSteps++;

    if (!riskEvent) throw new Error('Missing WebSocket "risk" event');
    console.log('[PASS] Check 14: WebSocket risk event stream works (type: "risk")');
    console.log(`       Node: ${riskEvent.data.nodeId}, Risk: ${riskEvent.data.status} (${riskEvent.data.riskScore}/100)\n`);
    passedSteps++;

    if (!alertEvent) throw new Error('Missing WebSocket "alert" event');
    console.log('[PASS] Check 15: WebSocket alert event stream works (type: "alert")');
    console.log(`       Alert Type: "${alertEvent.data.type}", Severity: "${alertEvent.data.severity}"\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 13-15: WebSocket event verification failed:', err.message);
    if (ws) ws.close();
    process.exit(1);
  }

  // ----------------------------------------------------
  // Check 16: Simulator vs Hardware distinction
  // ----------------------------------------------------
  try {
    const node1Res = await fetch(`${BASE_URL}/api/devices/N-01`);
    const node7Res = await fetch(`${BASE_URL}/api/devices/N-07`);
    const n1 = (await node1Res.json()).node;
    const n7 = (await node7Res.json()).node;

    if (n1.source !== 'hardware') {
      throw new Error(`N-01 expected source "hardware", got: "${n1.source}"`);
    }
    if (n7.source !== 'simulator') {
      throw new Error(`N-07 expected source "simulator", got: "${n7.source}"`);
    }

    console.log('[PASS] Check 16: Simulator vs Hardware distinction strictly preserved');
    console.log(`       N-01 Source: "${n1.source}" (Physical Hardware)`);
    console.log(`       N-07 Source: "${n7.source}" (Controlled Simulator)\n`);
    passedSteps++;
  } catch (err) {
    console.error('[FAIL] Check 16: Source distinction failed:', err.message);
    if (ws) ws.close();
    process.exit(1);
  }

  if (ws) ws.close();

  console.log('================================================================');
  console.log(`  COMPLETE VERIFICATION PASSED: ${passedSteps}/${totalSteps} CHECKS SUCCESSFUL`);
  console.log('================================================================');
}

runCompleteVerification().catch((err) => {
  console.error('Fatal execution failure:', err);
  process.exit(1);
});
