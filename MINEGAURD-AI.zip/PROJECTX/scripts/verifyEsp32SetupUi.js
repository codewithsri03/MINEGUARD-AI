import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, '..');

function runChecks() {
  console.log('=== VERIFYING ESP32 PROVISIONING & SETUP IMPLEMENTATION ===\n');

  let passed = 0;
  let total = 0;

  function check(desc, condition) {
    total++;
    if (condition) {
      console.log(`✅ [PASS] ${desc}`);
      passed++;
    } else {
      console.error(`❌ [FAIL] ${desc}`);
    }
  }

  const monitoringPath = path.join(root, 'src', 'command', 'pages', 'MonitoringPage.jsx');
  const modalPath = path.join(root, 'src', 'command', 'components', 'Esp32SetupModal.jsx');

  check('MonitoringPage.jsx exists', fs.existsSync(monitoringPath));
  check('Esp32SetupModal.jsx exists', fs.existsSync(modalPath));

  const monitoringCode = fs.readFileSync(monitoringPath, 'utf8');
  const modalCode = fs.readFileSync(modalPath, 'utf8');

  // Check 1: Connect ESP32 button exists in MonitoringPage.jsx
  check('Connect ESP32 button exists in MonitoringPage.jsx', monitoringCode.includes('Connect ESP32') || monitoringCode.includes('CONNECT ESP32'));

  // Check 2: Esp32SetupModal imported and used in MonitoringPage.jsx
  check('Esp32SetupModal is imported in MonitoringPage.jsx', monitoringCode.includes("import { Esp32SetupModal } from '../components/Esp32SetupModal'"));
  check('Esp32SetupModal component is rendered with isOpen and onClose', monitoringCode.includes('<Esp32SetupModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />'));

  // Check 3: No manual IP entry exists
  check('No manual IP input or label in MonitoringPage.jsx', !monitoringCode.includes('ESP32 IP ADDRESS') && !monitoringCode.includes('placeholder="192.168.1.100"'));
  check('No manual IP input in Esp32SetupModal.jsx', !modalCode.includes('<input') && !modalCode.includes('placeholder='));

  // Check 4: Three distinct states separated
  check('1. MINEGUARD BACKEND layer present in UI', monitoringCode.includes('1. MINEGUARD BACKEND'));
  check('2. ESP32 WI-FI / DEVICE layer present in UI', monitoringCode.includes('2. ESP32 WI-FI / DEVICE'));
  check('3. SENSOR TELEMETRY layer present in UI', monitoringCode.includes('3. SENSOR TELEMETRY'));

  // Check 5: No fake connected state when backend online but no telemetry
  check('Shows No hardware telemetry received when waiting', monitoringCode.includes('No hardware telemetry received'));
  check('Shows ESP32 WAITING when not connected', monitoringCode.includes("text: 'ESP32 WAITING'"));
  check('Shows BACKEND OFFLINE when backend unreachable', monitoringCode.includes("text: 'BACKEND OFFLINE'"));
  check('Shows ESP32 STALE when telemetry stops', monitoringCode.includes("text: 'ESP32 STALE'"));

  // Check 6: Hardware details display when connected
  check('Displays NODE ID when hardware connected', monitoringCode.includes('NODE ID'));
  check('Displays DEVICE ID when hardware connected', monitoringCode.includes('DEVICE ID'));
  check('Displays LAST TELEMETRY when hardware connected', monitoringCode.includes('LAST TELEMETRY'));
  check('Displays HARDWARE SOURCE when hardware connected', monitoringCode.includes('HARDWARE SOURCE'));
  check('Displays LAST UPDATE when hardware connected', monitoringCode.includes('LAST UPDATE'));

  // Check 7: Modal has the 5 provisioning steps
  check('Step 1: Power on the ESP32. present', modalCode.includes('Power on the ESP32.'));
  check('Step 2: Connect your laptop/phone to the ESP32 setup Wi-Fi. present', modalCode.includes('Connect your laptop/phone to the ESP32 setup Wi-Fi.'));
  check('Setup SSID MINEGUARD-SETUP present', modalCode.includes('MINEGUARD-SETUP'));
  check('Step 3: Configure the Wi-Fi network for the ESP32. present', modalCode.includes('Configure the Wi-Fi network for the ESP32.'));
  check('Step 4: ESP32 joins the configured Wi-Fi. present', modalCode.includes('ESP32 joins the configured Wi-Fi.'));
  check('Step 5: ESP32 sends telemetry to the MineGuard backend. present', modalCode.includes('ESP32 sends telemetry to the MineGuard backend.'));

  // Check 8: Browser limitation notice
  check('Browser limitation notice documented in modal', modalCode.includes('BROWSER LIMITATION') && modalCode.includes('cannot safely scan or switch operating system Wi-Fi'));

  // Check 9: Visual Wi-Fi pipeline indicator
  check('Architecture flow indicator present in modal (ESP32 -> Wi-Fi -> Backend -> Live Monitoring)', modalCode.includes('Live Monitoring') && modalCode.includes('Backend') && modalCode.includes('Wi-Fi') && modalCode.includes('ESP32'));

  // Check 10: Clear separation of READY FOR ESP32 SETUP and ESP32 CONNECTED
  check('READY FOR ESP32 SETUP banner present in modal', modalCode.includes('READY FOR ESP32 SETUP'));
  check('Start ESP32 Setup action button present in modal', modalCode.includes('Start ESP32 Setup'));

  console.log(`\nVerification complete: ${passed}/${total} checks passed.`);
  if (passed === total) {
    console.log('🎉 ALL ESP32 PROVISIONING & SETUP CHECKS PASSED!\n');
    process.exit(0);
  } else {
    process.exit(1);
  }
}

runChecks();
