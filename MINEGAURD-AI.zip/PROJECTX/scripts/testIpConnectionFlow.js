import http from 'http';
import WebSocket from 'ws';

const BACKEND_URL = 'http://localhost:3001';
const WS_URL = 'ws://localhost:3001/ws';
const ESP32_TEST_PORT = 8999;

let failed = false;

function assert(condition, message) {
  if (!condition) {
    console.error(`❌ FAIL: ${message}`);
    failed = true;
  } else {
    console.log(`✅ PASS: ${message}`);
  }
}

async function runTests() {
  console.log('====================================================');
  console.log(' MineGuard AI — IP-Based ESP32 Flow Verification');
  console.log('====================================================\n');

  // ----------------------------------------------------
  // Test 1: Health Check
  // ----------------------------------------------------
  console.log('1. Verifying Backend Health...');
  const healthRes = await fetch(`${BACKEND_URL}/api/health`);
  assert(healthRes.ok, 'Backend /api/health returned 200 OK');
  const healthData = await healthRes.json();
  assert(healthData.status === 'ok', 'Backend health status is "ok"');

  // ----------------------------------------------------
  // Test 2: Invalid IP Rejected
  // ----------------------------------------------------
  console.log('\n2. Testing Invalid IP Address Rejection...');
  const invalidRes1 = await fetch(`${BACKEND_URL}/api/devices/connect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host: '999.999.999.999' })
  });
  assert(invalidRes1.status === 400, 'Invalid octet IP rejected with HTTP 400');
  const invalidData1 = await invalidRes1.json();
  assert(!invalidData1.success, 'Response success is false');
  assert(invalidData1.error.includes('Invalid IP'), 'Error message specifies invalid IP format');

  const invalidRes2 = await fetch(`${BACKEND_URL}/api/devices/connect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host: 'not-a-valid-ip' })
  });
  assert(invalidRes2.status === 400, 'Gibberish host rejected with HTTP 400');

  // ----------------------------------------------------
  // Test 3: Unreachable IP Probing & Rejection
  // ----------------------------------------------------
  console.log('\n3. Testing Unreachable IP Address Probing...');
  const unreachableRes = await fetch(`${BACKEND_URL}/api/devices/connect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host: '192.0.2.1', port: 80 }) // TEST-NET-1 non-routable blackhole IP
  });
  assert(unreachableRes.status === 502, 'Unreachable ESP32 returned HTTP 502');
  const unreachableData = await unreachableRes.json();
  assert(!unreachableData.success, 'Response success is false');
  assert(
    unreachableData.error === 'Unable to reach ESP32 at the supplied address.',
    'Error matches exact contract: "Unable to reach ESP32 at the supplied address."'
  );

  const statusAfterFail = await fetch(`${BACKEND_URL}/api/devices/status`).then(r => r.json());
  assert(statusAfterFail.connected === false, 'Backend NEVER marks ESP32 as connected when unreachable');

  // ----------------------------------------------------
  // Test 4: Setup Simulated ESP32 Web Server
  // ----------------------------------------------------
  console.log('\n4. Starting Simulated ESP32 Hardware Web Server on port 8999...');
  const simulatedTelemetry = {
    nodeId: 'N-01',
    deviceId: 'ESP32-01',
    source: 'hardware',
    timestamp: new Date().toISOString(),
    sensors: {
      mpu9250: {
        accel: { x: 0.04, y: 0.02, z: 0.99 },
        gyro: { x: 0.1, y: 0.0, z: 0.2 },
        mag: { x: 18.2, y: -4.5, z: 42.1 },
        x: 0.04,
        y: 0.02,
        z: 0.99
      },
      hcSr04: {
        distance: 184.6
      },
      temperature: 25.3,
      humidity: 62.8,
      pressure: 1012.4,
      gas: 415,
      rain: 0
    },
    signal: 94
  };

  let pollCount = 0;
  const esp32Server = http.createServer((req, res) => {
    if (req.url === '/api/telemetry' && req.method === 'GET') {
      pollCount++;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ...simulatedTelemetry, timestamp: new Date().toISOString() }));
    } else if (req.url === '/status' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'ok', deviceId: 'ESP32-01' }));
    } else {
      res.writeHead(404);
      res.end();
    }
  });

  await new Promise((resolve) => esp32Server.listen(ESP32_TEST_PORT, '127.0.0.1', resolve));
  console.log(`   Simulated ESP32 running on http://127.0.0.1:${ESP32_TEST_PORT}`);

  // ----------------------------------------------------
  // Test 5: WebSocket Listener
  // ----------------------------------------------------
  console.log('\n5. Connecting WebSocket to verify real-time event dispatching...');
  const wsEvents = [];
  const ws = new WebSocket(WS_URL);

  await new Promise((resolve, reject) => {
    ws.on('open', resolve);
    ws.on('error', reject);
    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        wsEvents.push(msg);
      } catch {
        // ignore raw
      }
    });
  });
  assert(ws.readyState === WebSocket.OPEN, 'WebSocket connected to /ws');

  // ----------------------------------------------------
  // Test 6: Connect to Reachable ESP32 IP
  // ----------------------------------------------------
  console.log('\n6. Connecting to Reachable ESP32 IP...');
  const connectRes = await fetch(`${BACKEND_URL}/api/devices/connect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ host: '127.0.0.1', port: ESP32_TEST_PORT })
  });
  assert(connectRes.status === 200, 'Reachable ESP32 returned HTTP 200 OK');
  const connectData = await connectRes.json();
  assert(connectData.success === true, 'Response success is true');
  assert(connectData.state.connected === true, 'State reports connected: true');
  assert(connectData.state.targetHost === '127.0.0.1', 'State records targetHost');

  // Wait 2.5 seconds for initial packet ingestion & polling
  await new Promise((r) => setTimeout(r, 2500));

  // ----------------------------------------------------
  // Test 7: Verify Telemetry Ingestion & Normalization
  // ----------------------------------------------------
  console.log('\n7. Verifying Hardware Telemetry Normalization...');
  const latestRes = await fetch(`${BACKEND_URL}/api/telemetry/latest?nodeId=N-01`);
  assert(latestRes.ok, 'GET /api/telemetry/latest returned 200');
  const latestJson = await latestRes.json();
  const latest = latestJson.data || latestJson.telemetry || {};

  assert(latest.nodeId === 'N-01', 'Node ID is N-01');
  assert(latest.source === 'hardware', 'Source is correctly identified as hardware');
  assert(latest.raw && latest.raw.distance === 184.6, 'HC-SR04 distance correctly extracted (184.6 cm)');
  assert(latest.raw && latest.raw.temperature === 25.3, 'Temperature correctly extracted (25.3 °C)');
  assert(latest.raw && latest.raw.humidity === 62.8, 'Humidity correctly extracted (62.8 %)');
  assert(latest.raw && latest.raw.pressure === 1012.4, 'Pressure correctly extracted (1012.4 hPa)');
  assert(latest.raw && latest.raw.gasAdc === 415, 'Gas sensor correctly extracted (415 ADC)');
  assert(latest.raw && latest.raw.rainAdc === 0, 'Rain sensor correctly extracted (0 ADC)');
  assert(latest.raw && latest.raw.imu && latest.raw.imu.z === 0.99, 'MPU9250 IMU correctly extracted');
  assert(latest.raw && latest.raw.signal === 94, 'Signal strength extracted (94%)');

  // ----------------------------------------------------
  // Test 8: Verify WebSocket Broadcasts
  // ----------------------------------------------------
  console.log('\n8. Verifying WebSocket Broadcast Events...');
  const telemetryEvents = wsEvents.filter((e) => e.type === 'telemetry');
  const deviceEvents = wsEvents.filter((e) => e.type === 'device_status');

  assert(telemetryEvents.length > 0, `Received ${telemetryEvents.length} telemetry WebSocket broadcast(s)`);
  if (telemetryEvents.length > 0) {
    const lastTelemetry = telemetryEvents[telemetryEvents.length - 1].data;
    assert(lastTelemetry.source === 'hardware', 'Broadcast identifies source as hardware');
    assert(lastTelemetry.distance === 184.6, 'Broadcast includes HC-SR04 distance 184.6');
  }

  assert(deviceEvents.length > 0, `Received ${deviceEvents.length} device_status WebSocket broadcast(s)`);
  if (deviceEvents.length > 0) {
    const lastDevice = deviceEvents[deviceEvents.length - 1].data;
    assert(lastDevice.connected === true, 'device_status broadcast reports connected: true');
  }

  assert(pollCount >= 2, `Continuous polling confirmed (${pollCount} requests received by simulated ESP32)`);

  // ----------------------------------------------------
  // Test 9: Verify Simulator Override Protection
  // ----------------------------------------------------
  console.log('\n9. Verifying Simulator Isolation (Simulator cannot overwrite Hardware)...');
  await fetch(`${BACKEND_URL}/api/telemetry`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      nodeId: 'N-01',
      source: 'simulator',
      isSimulated: true,
      distance: 999.0
    })
  });

  const nodeRes = await fetch(`${BACKEND_URL}/api/devices/N-01`).then(r => r.json());
  assert(nodeRes.node.source === 'hardware', 'Node source remains "hardware" despite simulated packet');

  // ----------------------------------------------------
  // Test 10: Disconnect
  // ----------------------------------------------------
  console.log('\n10. Testing Disconnect Command...');
  const disconnectRes = await fetch(`${BACKEND_URL}/api/devices/disconnect`, { method: 'POST' });
  assert(disconnectRes.ok, 'POST /api/devices/disconnect returned 200 OK');
  const disconnectData = await disconnectRes.json();
  assert(disconnectData.state.connected === false, 'State reports connected: false');

  // Clean up
  ws.close();
  await new Promise((r) => esp32Server.close(r));
  console.log('   Simulated ESP32 server shut down.');

  console.log('\n====================================================');
  if (failed) {
    console.error('❌ SOME CHECKS FAILED!');
    process.exit(1);
  } else {
    console.log('🎉 ALL 10/10 IP CONNECTION FLOW CHECKS PASSED!');
    console.log('====================================================');
    process.exit(0);
  }
}

runTests().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
});
