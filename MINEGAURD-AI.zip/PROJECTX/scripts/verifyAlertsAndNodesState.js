import { useSim, ZONES_METADATA, NODES_METADATA } from '../src/command/sim/engine.js';

console.log('================================================================');
console.log(' MineGuard AI — Verification of Store State & Alerts Deduplication');
console.log('================================================================\n');

const state = useSim.getState();

// 1. Check nodes online status
console.log('1. Checking Sensor Nodes Status:');
const nodeEntries = Object.values(state.nodes);
console.log(`Total nodes in store: ${nodeEntries.length}`);

let onlineCount = 0;
nodeEntries.forEach((n) => {
  const isOnline = n.isOnline;
  if (isOnline) onlineCount++;
  console.log(`  - ${n.id} (${n.name}): Status=${n.status}, Online=${isOnline}, Tilt=${n.currentTilt}°, Conv=${n.currentConvergence}cm, Gas=${n.gasAdc} ADC, Rain=${n.rainAdc} ADC`);
});

if (onlineCount !== 8) {
  console.error(`❌ FAILED: Expected 8 nodes online, found ${onlineCount}`);
  process.exit(1);
}
console.log(`✅ PASS: All ${onlineCount}/8 nodes are ONLINE with real physical telemetry.\n`);

// 2. Check telemetry stream metrics
console.log('2. Checking Telemetry Ticker Metrics:');
console.log(`  Mine Risk: ${state.mineRisk}/100`);
console.log(`  Mine Risk Status: ${state.mineRiskStatus}`);
console.log(`  Mine Risk Trend: ${state.mineRiskTrend}`);
if (state.mineRisk === 0 || state.mineRiskTrend === 'stable') {
  console.error('❌ FAILED: Telemetry ticker shows 0/100 stable');
  process.exit(1);
}
console.log(`✅ PASS: Telemetry stream shows dynamic risk: ${state.mineRisk}/100 (${state.mineRiskTrend})\n`);

// 3. Check alerts in store
console.log('3. Checking Alerts in Store:');
console.log(`Total alerts in store: ${state.alerts.length}`);
state.alerts.forEach((alt) => {
  console.log(`  - [${alt.severity.toUpperCase()}] ${alt.id} on ${alt.nodeId} (${alt.type}): "${alt.message}"`);
});

if (state.alerts.length === 0) {
  console.error('❌ FAILED: Alerts array is empty!');
  process.exit(1);
}
console.log(`✅ PASS: Found ${state.alerts.length} active alerts in store.\n`);

// 4. Test Deduplication / Grouping Logic
console.log('4. Testing Deduplication / Grouping Logic:');

// Helper from AlertsPage
function getPlainLanguageAlert(alert, node) {
  const msg = (alert?.message || '').toLowerCase();
  const threshold = (alert?.threshold || '').toLowerCase();
  const type = (alert?.type || alert?.eventType || alert?.event || '').toLowerCase();
  const rawDist = node?.currentConvergence ?? (alert?.factors?.[0]?.parameter === 'distance' ? alert?.factors[0]?.value : null);
  const rawTilt = node?.currentTilt ?? (alert?.factors?.[0]?.parameter === 'tilt' ? alert?.factors[0]?.value : null);
  const rawGas = node?.gasAdc ?? (alert?.factors?.[0]?.parameter === 'gasAdc' ? alert?.factors[0]?.value : null);
  const rawRain = node?.rainAdc ?? (alert?.factors?.[0]?.parameter === 'rainAdc' ? alert?.factors[0]?.value : null);

  if (msg.includes('roof') || msg.includes('convergence') || msg.includes('clearance') || threshold.includes('roof') || threshold.includes('convergence') || type.includes('roof') || type.includes('convergence')) {
    const currCm = rawDist !== null ? Number(rawDist).toFixed(1) : '14.3';
    return {
      headline: 'The roof is shifting downward and at risk of collapse',
      category: 'Roof & Strata Structural Hazard',
      iconType: 'roof'
    };
  }
  if (msg.includes('gas') || msg.includes('methane') || threshold.includes('gas') || type.includes('gas')) {
    return {
      headline: 'Hazardous gas concentration detected in active tunnel corridor',
      category: 'Atmospheric Safety Hazard',
      iconType: 'gas'
    };
  }
  if (msg.includes('tilt') || msg.includes('structural') || threshold.includes('tilt') || type.includes('tilt')) {
    return {
      headline: 'Structural support pillar is tilting under heavy rock displacement',
      category: 'Geotechnical Pillar Movement',
      iconType: 'tilt'
    };
  }
  if (msg.includes('water') || msg.includes('rain') || msg.includes('ingress') || threshold.includes('water') || type.includes('water') || type.includes('rain')) {
    return {
      headline: 'Water ingress detected in stope drainage corridor',
      category: 'Flooding & Sump Hazard',
      iconType: 'water'
    };
  }
  return {
    headline: alert?.message || 'Geotechnical anomaly',
    category: 'Operational Alert',
    iconType: 'general'
  };
}

const groupsMap = new Map();
state.alerts.forEach((alt) => {
  const node = state.nodes[alt.nodeId];
  const info = getPlainLanguageAlert(alt, node);
  const groupKey = `${alt.nodeId}__${info.iconType}`;
  const altTime = new Date(alt.timestamp || 0).getTime();
  const altZone = alt.zoneId || (alt.nodeId ? NODES_METADATA[alt.nodeId]?.zoneId : null);
  const altSev = (alt.severity || 'warning').toLowerCase();

  if (!groupsMap.has(groupKey)) {
    groupsMap.set(groupKey, {
      key: groupKey,
      nodeId: alt.nodeId,
      iconType: info.iconType,
      headline: info.headline,
      category: info.category,
      zoneId: altZone,
      primaryAlert: alt,
      alerts: [alt],
      firstTimestamp: altTime,
      latestTimestamp: altTime,
      count: 1,
      severity: altSev,
      state: alt.state
    });
  } else {
    const grp = groupsMap.get(groupKey);
    grp.alerts.push(alt);
    grp.count += 1;
  }
});

const distinctProblems = Array.from(groupsMap.values());
console.log(`Distinct Problems Grouped: ${distinctProblems.length}`);
distinctProblems.forEach((p) => {
  console.log(`  - Station ${p.nodeId} [${p.iconType.toUpperCase()}]: "${p.headline}" (Severity: ${p.severity}, Triggered: ${p.count}x)`);
});

const hasN07 = distinctProblems.some((p) => p.nodeId === 'N-07' && p.iconType === 'roof');
const hasN08 = distinctProblems.some((p) => p.nodeId === 'N-08' && p.iconType === 'water');
const hasN06 = distinctProblems.some((p) => p.nodeId === 'N-06' && p.iconType === 'tilt');

if (!hasN07 || !hasN08) {
  console.error('❌ FAILED: Missing N-07 roof risk or N-08 water ingress in grouped problems!');
  process.exit(1);
}

console.log('✅ PASS: N-07 roof risk and N-08 water ingress are correctly deduplicated and grouped!');
console.log('\n================================================================');
console.log(' ALL VERIFICATION CHECKS PASSED SUCCESSFULLY!');
console.log('================================================================');
process.exit(0);
