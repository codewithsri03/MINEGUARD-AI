# MineGuard AI — Hardware Integration Specification

## 1. Overview & Architecture

MineGuard AI connects physical IoT sensor nodes deployed across underground mine stopes and haulage tunnels to the central command dashboard over standard Wi-Fi (802.11 b/g/n).

```
   ┌─────────────────────────────────────────────────────────────┐
   │                  PHYSICAL UNDERGROUND SENSORS               │
   │                                                             │
   │   [MPU9250]   [HC-SR04]   [BME280/Temp]   [MQ Gas]  [Rain]  │
   │   (9-DOF IMU) (Ultrasonic) (Temperature)  (Hazard)  (Water) │
   └──────────────────────────────┬──────────────────────────────┘
                                  │ I2C / Analog / GPIO
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │                     ESP32 MICROCONTROLLER                   │
   │         (Wi-Fi Station / Gateway Firmware Client)           │
   └──────────────────────────────┬──────────────────────────────┘
                                  │ HTTP POST /api/telemetry (Wi-Fi)
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │                   MINEGUARD REAL BACKEND                    │
   │                 (Node.js + Express + SQLite)                │
   │                                                             │
   │  • Sensor Processing (Raw vs Derived Isolation)             │
   │  • Geotechnical Multi-Factor Risk Engine                    │
   │  • Deduplicated Alert Engine                                │
   │  • SQLite Persistent Storage                                │
   │  • WebSocket Broadcaster (/ws)                              │
   └──────────────────────────────┬──────────────────────────────┘
                                  │ WebSocket Events & REST APIs
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │              MINEGUARD COMMAND CENTER FRONTEND              │
   │          (Live Monitoring • Digital Twin • Alerts)          │
   └─────────────────────────────────────────────────────────────┘
```

---

## 2. Sensor Suite & Pinout Mapping

| Sensor | Physical Metric | Interface | Pins / Protocol | Operational Range |
|---|---|---|---|---|
| **MPU9250** | 9-DOF IMU: 3-Axis Accel, Gyro, Mag | I2C | SDA (GPIO 21), SCL (GPIO 22) | Accel ±2g to ±16g, Gyro ±250 to ±2000°/s |
| **HC-SR04** | Roof Convergence Clearance / Distance | Digital GPIO | TRIG (GPIO 5), ECHO (GPIO 18) | 2 cm – 400 cm (Accuracy ±3mm) |
| **Temp/Humidity** | Ambient Stope Air Temperature & Relative Humidity | I2C / OneWire | Data (GPIO 4 or shared I2C) | -40°C to +85°C, 0–100% RH |
| **Pressure** | Barometric Pressure (Ventilation Flow) | I2C | Shared I2C (0x76 / 0x77) | 300 – 1100 hPa |
| **MQ Gas Sensor** | Combustible Methane ($CH_4$) / Toxic CO | Analog ADC | AOUT (GPIO 34 / ADC1_CH6) | 0 – 4095 ADC (100 – 10,000 ppm) |
| **Rain / Water** | Sump Water Ingress / Inflow Accumulation | Analog ADC | AOUT (GPIO 35 / ADC1_CH7) | 0 – 4095 ADC |

---

## 3. Telemetry Ingestion Contract

The MineGuard backend accepts hardware telemetry in two equivalent formats:
1. **Nested Sensor Schema (Recommended for ESP32 Firmware)**:
```json
{
  "nodeId": "N-01",
  "deviceId": "ESP32-01",
  "source": "hardware",
  "timestamp": "2026-09-22T00:00:00.000Z",
  "sensors": {
    "mpu9250": {
      "accel": { "x": 0.02, "y": 0.01, "z": 0.99 },
      "gyro": { "x": 0.1, "y": 0.0, "z": 0.2 },
      "mag": { "x": 18.2, "y": -4.5, "z": 42.1 },
      "x": 0.02,
      "y": 0.01,
      "z": 0.99
    },
    "hcSr04": {
      "distance": 184.5
    },
    "temperature": 24.8,
    "humidity": 62.4,
    "pressure": 1013.2,
    "gas": 412,
    "rain": 0
  },
  "signal": 88
}
```

2. **Flat Schema (Backward Compatible)**:
```json
{
  "nodeId": "N-01",
  "deviceId": "ESP32-01",
  "source": "hardware",
  "timestamp": "2026-09-22T00:00:00.000Z",
  "temperature": 24.8,
  "humidity": 62.4,
  "pressure": 1013.2,
  "gasAdc": 412,
  "rainAdc": 0,
  "distance": 184.5,
  "imu": {
    "x": 0.02,
    "y": 0.01,
    "z": 0.99
  },
  "signal": 88
}
```

---

## 4. Hardware Communication Modes

### Mode A: IP-Based Polling (Command Center Connects to ESP32 IP)
When the operator clicks `[ Connect ESP32 ]` and enters the ESP32 local IP address (e.g., `192.168.1.100`):

```
React (Browser)
  │ POST /api/devices/connect { "host": "192.168.1.100", "port": 80 }
  ▼
MineGuard Backend (Node.js)
  │ GET http://192.168.1.100:80/api/telemetry (timeout 2500ms)
  ▼
ESP32 (Wi-Fi Web Server)
  │ Returns HTTP 200 with JSON Telemetry
  ▼
MineGuard Backend
  │ Ingests sensors → Normalizes data → Computes Risk → Broadcasts WebSocket
  ▼
React (Live Monitoring)
```

#### ESP32 Firmware Requirements for Mode A:
1. Connect ESP32 to the local facility Wi-Fi network.
2. Run an HTTP web server on port 80 (e.g., using `ESPAsyncWebServer` or `WebServer.h`).
3. Handle endpoint:
   - **`GET /api/telemetry`**: Return `application/json` containing the telemetry JSON schema above.
   - **`GET /status`** (optional health probe): Return `{"status": "ok", "deviceId": "ESP32-01"}`.
4. If reachable, the backend polls `GET /api/telemetry` every 2000ms and streams readings via WebSocket `/ws` to the UI.
5. If unreachable, the backend marks `ESP32 OFFLINE` with error `Unable to reach ESP32 at the supplied address.`

---

### Mode B: Autonomous Push (ESP32 POSTs to Backend)
The ESP32 can also autonomously push packets to the MineGuard backend:
- **Endpoint**: `POST http://<MINEGUARD_BACKEND_IP>:3001/api/telemetry`
- **Content-Type**: `application/json`
- **Body**: Either Nested or Flat telemetry schema.

---

## 5. Hardware vs Simulator Priority

1. **Source Tracking**: Telemetry packets containing `source: 'hardware'` or real device IDs lock the station into **Hardware Mode**.
2. **Precedence**: Real physical hardware packets lock out simulated ticks, preventing simulated values from overwriting verified physical telemetry.
3. **Decoupled Connection States**:
   - **Backend**: `CONNECTED` / `OFFLINE`
   - **ESP32**: `CONNECTED` / `OFFLINE` / `STALE`
   - **Telemetry**: `LIVE` / `WAITING`

