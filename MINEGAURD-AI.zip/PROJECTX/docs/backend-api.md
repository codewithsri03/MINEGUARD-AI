# MineGuard AI — Backend API Reference

Comprehensive guide to MineGuard AI's REST endpoints and WebSocket stream.

Base URL: `http://localhost:3001`  
WebSocket: `ws://localhost:3001/ws`

---

## 1. System & Health

### `GET /api/health`
- **Purpose**: Verify backend process liveness and runtime environment.
- **Request**: None
- **Response** (`200 OK`):
  ```json
  {
    "status": "ok",
    "service": "mineguard-backend",
    "environment": "development",
    "timestamp": "2026-09-21T17:44:44.169Z"
  }
  ```

---

## 2. Hardware Devices & Fleet Management

### `GET /api/devices/status`
- **Purpose**: Return real ESP32 gateway state, online/stale/offline counts, and list of all known fleet stations.
- **Request**: None
- **Response** (`200 OK`):
  ```json
  {
    "connected": true,
    "gateway": "ESP32-GATEWAY-01",
    "nodesOnline": 1,
    "nodesStale": 0,
    "nodesOffline": 7,
    "totalNodes": 8,
    "lastPacket": "2026-09-21T17:44:28.361Z",
    "signal": 84,
    "status": "connected",
    "nodes": [...]
  }
  ```

### `GET /api/devices/:nodeId`
- **Purpose**: Return full record, metadata, and latest telemetry for a single station.
- **Request**: Path param `nodeId` (e.g. `N-07`)
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "node": {
      "nodeId": "N-07",
      "deviceId": "ESP32-GATEWAY-01",
      "name": "Sub-Level 4 Stope",
      "zoneId": "z3",
      "zoneName": "Zone 03 — Sub-Level 4",
      "depth": -460,
      "status": "ONLINE",
      "source": "hardware",
      "lastSeen": 1790010478406,
      "latestTelemetry": { ... }
    }
  }
  ```

### `POST /api/devices/connect`
- **Purpose**: Connect to physical ESP32 by IP address with active reachability verification and continuous polling.
- **Request**: `{ "host": "192.168.1.100", "port": 80 }`
- **Success Response** (`200 OK`):
  ```json
  {
    "success": true,
    "statusCode": 200,
    "message": "ESP32 connected successfully.",
    "state": {
      "connected": true,
      "gateway": "ESP32-01",
      "targetHost": "192.168.1.100",
      "targetPort": 80,
      "nodesOnline": 1,
      "status": "connected"
    }
  }
  ```
- **Error Response — Unreachable** (`502 Bad Gateway`):
  ```json
  {
    "success": false,
    "statusCode": 502,
    "error": "Unable to reach ESP32 at the supplied address.",
    "state": {
      "connected": false,
      "status": "disconnected"
    }
  }
  ```
- **Error Response — Invalid IP** (`400 Bad Request`):
  ```json
  {
    "success": false,
    "statusCode": 400,
    "error": "Invalid IP address format. Expected format: 192.168.1.100",
    "state": { ... }
  }
  ```

### `POST /api/devices/disconnect`
- **Purpose**: Terminate connection state and mark fleet nodes offline.
- **Request**: None
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "message": "Disconnected from ESP32 gateway.",
    "state": { ... }
  }
  ```

---

## 3. Telemetry Processing & Persistence

### `POST /api/telemetry`
- **Purpose**: Ingest sensor readings from ESP32 or simulator over Wi-Fi.
- **Request Body**:
  ```json
  {
    "nodeId": "N-07",
    "timestamp": "2026-09-21T15:30:00Z",
    "temperature": 27.2,
    "humidity": 78.9,
    "pressure": 1010.3,
    "gasAdc": 2321,
    "rainAdc": 208,
    "distance": 14.0,
    "imu": { "x": 0.01, "y": 0.02, "z": 0.98 },
    "signal": 84,
    "source": "hardware"
  }
  ```
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "nodeId": "N-07",
    "receivedAt": "2026-09-21T17:44:28.383Z",
    "isSimulated": false,
    "source": "hardware"
  }
  ```

### `GET /api/telemetry/latest?nodeId=N-07`
- **Purpose**: Retrieve latest cached telemetry packet for all or a specific station.
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "telemetry": {
      "nodeId": "N-07",
      "timestamp": "2026-09-21T15:30:00.000Z",
      "temperature": 27.2,
      "humidity": 78.9,
      "pressure": 1010.3,
      "distance": 14.0,
      "tilt": 1.31,
      "gasAdc": 2321,
      "risk": { "score": 78, "level": "CRITICAL", "factors": [...] }
    }
  }
  ```

### `GET /api/telemetry/history/:nodeId?limit=100&since=...&until=...`
- **Purpose**: Retrieve historical time-series data from SQLite storage.
- **Query Params**:
  - `limit` (number, default: 100, max: 1000)
  - `since` (ISO date or timestamp ms)
  - `until` (ISO date or timestamp ms)
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "nodeId": "N-07",
    "count": 42,
    "history": [
      {
        "id": 1,
        "timestamp": "2026-09-21T15:30:00Z",
        "temperature": 27.2,
        "distance": 14.0,
        "tilt": 1.31,
        "gasAdc": 2321,
        "raw": { ... },
        "derived": { ... }
      }
    ]
  }
  ```

---

## 4. Risk Analysis Engine

### `GET /api/risk`
- **Purpose**: Return overall mine geotechnical risk overview and all evaluated station risk cards.
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "mineRisk": {
      "overallStatus": "CRITICAL",
      "overallRiskScore": 78,
      "criticalNodes": ["N-07"],
      "warningNodes": [],
      "totalEvaluated": 8
    },
    "nodes": [
      {
        "nodeId": "N-07",
        "name": "Sub-Level 4 Stope",
        "status": "CRITICAL",
        "riskScore": 78,
        "factors": [...]
      }
    ]
  }
  ```

### `GET /api/risk/:nodeId`
- **Purpose**: Return detailed geotechnical breakdown and breached factors for a single node.

---

## 5. Alerts & Events

### `GET /api/alerts?nodeId=N-07&severity=CRITICAL&acknowledged=false`
- **Purpose**: Query stored alerts with optional filtering.
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "count": 1,
    "alerts": [
      {
        "id": "alt-1790010478406-993",
        "nodeId": "N-07",
        "severity": "CRITICAL",
        "type": "ROOF_CONVERGENCE_BREACH",
        "message": "Excessive roof convergence detected on N-07 (14 cm < 15 cm)",
        "acknowledged": false,
        "timestamp": "2026-09-21T15:30:00.000Z",
        "factors": [...]
      }
    ]
  }
  ```

### `PATCH /api/alerts/:alertId/acknowledge`
- **Purpose**: Mark an active alert as acknowledged by an operator.
- **Request Body**: `{ "actor": "Supervisor Vance" }`
- **Response** (`200 OK`):
  ```json
  {
    "success": true,
    "alert": {
      "id": "alt-1790010478406-993",
      "acknowledged": true,
      "acknowledgedAt": "2026-09-21T17:50:00.000Z",
      "acknowledgedBy": "Supervisor Vance"
    }
  }
  ```

---

## 6. Dashboard & Digital Twin

### `GET /api/dashboard/summary`
- **Purpose**: Consolidated telemetry, fleet online count, active alerts, and mine status for the main command dashboard.

### `GET /api/digital-twin/nodes`
- **Purpose**: Geotechnical depth, sector coordinates, and live telemetry summary formatted for the 2D interactive mine map.

---

## 7. WebSocket Live Streaming

- **URL**: `ws://localhost:3001/ws` (also accepts `/ws/` and `/`)

### Event Types
1. `telemetry`: Ingested sensor packet (raw + derived metrics).
2. `risk`: Live updated geotechnical risk evaluation for reporting station.
3. `alert`: Newly triggered hazard alert.
4. `device_status`: Real-time gateway connectivity and online station counts.
